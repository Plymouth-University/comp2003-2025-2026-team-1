---Move mod

local Log = require('Log')
local log = Log.new()

local DirectionUtils = require('DirectionUtils')

---@type Game
local game = LoadFacility('Game')['game']

---@type AchievementsHelper
local AchievementsHelper = require('AchievementsHelper')
---@type MessageHelpers
local MessageHelpers = require('MessageHelpers')
---@type NarrativeSaveDataKeys
local NarrativeSaveDataKeys = require('NarrativeSaveDataKeys')
---@type KnockbackHelper
local KnockbackHelper = require('KnockbackHelper')
---@type SoundUtils
local SoundUtils = require('SoundUtils')

---@type MapMobile
local owner = owner or error('No owner')

local carrier = owner.getFirstComponentTagged('carrier');
assert(nil ~= carrier and 'Carrier' == carrier.typeName, 'Player lacks carrier component')

owner.bus.send({['state.player'] = (carrier.isCarrying and 'IdleCarry' or 'Idle')}, nil, false)

---@param direction Direction
local function shouldMoveBeValid(direction)
    owner.setFacing(direction)
    local notBlocked = owner.getFirstFacingObjectTagged('blocksMove') == nil
    local hasFloor = owner.getFirstFacingObjectTagged('floor') ~= nil
    return notBlocked and hasFloor
end

local function checkStepCountAchievement()
    local numTilesWalked = game.saveData.getNumber('stat_numTilesWalked')
    numTilesWalked = numTilesWalked + 1
    if numTilesWalked > 200 then
        -- Unlock achievement! Walk over 200 tiles in total
        AchievementsHelper.unlockWalkOver200TilesAchievement()
    end
    game.saveData.setNumber('stat_numTilesWalked', numTilesWalked)
end

-- Called from framework with text from the controller
function move(direction)
    log:log('Modding moving ', direction, ' with owner ', owner)

    if nil == direction or not DirectionUtils.isDirection(direction) then
        log:error('Invalid direction supplied: ', direction)
        return false
    end

    owner.bus.send({['state.player'] = (carrier.isCarrying and 'RunCarry' or 'Run')}, nil, false)

    -- Play footsteep sound(s) as soon as we start trying to move, only playing multiple steps if we don't expect to be blocked
    local fullWalkExpected = shouldMoveBeValid(direction)
    SoundUtils.playWalkingSound(fullWalkExpected)

    -- Cannot do own movement by checking target space because resolution is more complex
    local result = owner.move1SpaceIfPossible(direction)

    owner.bus.send({['state.player'] = (carrier.isCarrying and 'IdleCarry' or 'Idle')}, nil, false)

    -- only return a value if we succeeded (so other things can be tried otherwise)
    if result then
        log:log('Modding moved direction ', direction, ' with owner ', owner, ' SUCCEEDED')
        checkStepCountAchievement()
        return true
    else
        log:log('Modding moved direction ', direction, ' with owner ', owner, ' FAILED')
        return false
    end
end

--- Move obstructed e.g. by another object, or edge of map
---@param message Message
local function onMoveObstructed(message)
    local playerComponent = owner.getFirstComponentTagged('Player')
    assert(playerComponent ~= nil)

    owner.bus.send({['state.player'] = (carrier.isCarrying and 'IdleCarry' or 'Idle')}, nil, false)
    owner.bus.send({['state.player'] = (carrier.isCarrying and 'BumpCarry' or 'Bump')}, nil, false)

    -- Tell all objects tagged as 'wobble' in the tile the player is facing (but could not move into) to wobble
    -- (Shrunk things don't wobble here, since they don't block movement)
    local mapObjsToWobble = owner.getFacingObjectsTagged('wobbleWhenBumped')
    for wobbleObject in mapObjsToWobble do
        if not wobbleObject.tags.hasTag('shrunk') then
            wobbleObject.bus.send({ 'wobble' }, nil, false)
            SoundUtils.playPatientHitWallSound()
        end
    end

    -- Facing object(s) tagged as 'knockbackTarget' get hit and potentially pushed into the next tile
    local mapObjsToKnockback = owner.getFacingObjectsTagged('knockbackTarget')
    for knockbackObject in mapObjsToKnockback do
        if knockbackObject.typeName == 'MapMobile' then
            KnockbackHelper.hitObject(knockbackObject--[[@as MapMobile]], owner.facing, SoundUtils, AchievementsHelper)
        end
    end

    -- Unlock achievement! Bump into something
    AchievementsHelper.unlockBumpIntoSomethingAchievement()

    local obstructionId = message.data.obstructionId
    if obstructionId == nil or obstructionId == -1 then
        -- No obstruction object, e.g. edge of map
        log:debug('onMoveObstructed with no obstruction object')
        return
    end
    local obstructionObj = MessageHelpers.getMapObjectViaIdFromMessage(message, 'obstructionId')
    local objNameKey = NarrativeSaveDataKeys.getStringTableKeyForNameOfObject(obstructionObj)

    -- Save data - used for conditional narrative text
    game.saveData.setNumber(NarrativeSaveDataKeys.thisRound_didPlayerBump() , 1)
    game.saveData.setString(NarrativeSaveDataKeys.global_mostRecentBumpPlayer(), playerComponent.playerName)
    game.saveData.setString(NarrativeSaveDataKeys.global_mostRecentBumpedObject(), objNameKey)
    -- +1 player bumped!
    local playerBumpCount = game.saveData.getNumber(NarrativeSaveDataKeys.global_playerBumpCount())
    game.saveData.setNumber(NarrativeSaveDataKeys.global_playerBumpCount(), (playerBumpCount + 1))
    game.saveData.save()
end

--- Player was knocked (i.e. another player bumped into them)
---@param _ Message
local function onKnocked(_)
    if owner == nil then
        return
    end
    -- Enter idle state first, to ensure player returns to idle animation after knocked instead of e.g. wait
    owner.bus.send({['state.player'] = (carrier.isCarrying and 'IdleCarry' or 'Idle')}, nil, false)
    -- Knocked/KnockedCarry state triggers the associated character animation
    owner.bus.send({['state.player'] = (carrier.isCarrying and 'KnockedCarry' or 'Knocked')}, nil, false)
end

--- Player was knocked, and will be pushed into an adjacent tile
---@param message Message
local function onKnockedIntoNextTile(message)
    if owner == nil then
        return
    end
    onKnocked(message)

    if not carrier.isCarrying then
        return
    end
    -- If carrying something, also send knockedIntoNextTile message to that object,
    --  causing it to do a knockback tween in-sync with this player
    local carryables = owner.map.getAllTagged(owner.gridPosition, 'carryable')
    for carryable in carryables do
        -- Have to check all carryables, since there could be a shrunk carryable
        --  in the tile in addition to the object actually being carried
        if not carryable.tags.hasTag('shrunk') then
            carryable.bus.send(message, nil, false)
            break
        end
    end
end

owner.bus.subscribe('mapMobile.moveObstructed', onMoveObstructed)
owner.bus.subscribe('knockback.knockedChained', onKnocked)
owner.bus.subscribe('knockback.knockedAndBlocked', onKnocked)
owner.bus.subscribe('knockback.knockedIntoNextTile', onKnockedIntoNextTile)
