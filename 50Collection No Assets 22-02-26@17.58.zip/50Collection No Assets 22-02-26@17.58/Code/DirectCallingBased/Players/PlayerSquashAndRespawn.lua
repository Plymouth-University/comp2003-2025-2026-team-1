--- Logic for players squashing, being squashed, and respawning
local Log = require('Log')
local log = Log.new()

---@type AchievementsHelper
local AchievementsHelper = require('AchievementsHelper')
---@type SquashHelper
local SquashHelper = require('SquashHelper')
---@type SpawnsInGrid
local SpawnsInGrid = require('SpawnsInGrid')
---@type CameraTargetHelper
local CameraTargetHelper = require('CameraTargetHelper')
---@type SoundUtils
local SoundUtils = require('SoundUtils')

---@type MapMobile
local owner = owner or error('No owner')

---@type boolean
local launchedSinceRespawning

log:debug('PlayerSquashAndRespawn lua started')

---@return boolean
local function respawnConditions()
    local spawnPos = SpawnsInGrid.getSpawnPosition()

    -- Try to set spawn position to an unblocked tile, first trying our initial spawn pos,
    -- then adjacent tiles, and then, if all else fails, any unblocked floor
    return SpawnsInGrid.trySetSpawnToValidPositionNearTarget(spawnPos, SpawnsInGrid.bypassSquashableBlocker, false)
end

---@param event string
local function notifyCarriedIfCarrying(event)
    local carrier = owner.getFirstComponentTagged('carrier');
    if carrier ~= nil and carrier.isCarrying then
        local carried = carrier.getCurrentlyCarried()
        carried.owner.bus.send({event}, nil, false)
    end
end

local function onActive()
    CameraTargetHelper.addPlaceholderCameraTarget(owner.gridPosition)

    owner.tags.addTag('blocksMove')
    owner.tags.addTag('blocksThrow')
    launchedSinceRespawning = false

    SquashHelper.squashSquashablesAtOwnerPosition(owner, SoundUtils)
end

local function onVisibleFromRespawn()
    notifyCarriedIfCarrying('carrier.respawned')
    owner.bus.send({visible = true}, nil, false)
    notifyCarriedIfCarrying('carrier.respawnedAndVisible')

    -- Ensure player is a camera target when becoming visible after (re)spawning
    CameraTargetHelper.tryRemovePlaceholderCameraTarget(owner.gridPosition)
    CameraTargetHelper.enableCameraTargetFor(owner)

    SquashHelper.respawnSquashedAtOwnerPosition(owner)

    -- We don't become squashable again until anything that we squashed
    -- has respawned, to prevent potential infinite loops of squashing
    owner.tags.addTag('squashable')
end

---Called externally when squashed
function squash()
    log:log('Player squashed! ', owner)

    -- Camera shouldn't focus on player when squashed/falling
    CameraTargetHelper.disableCameraTargetFor(owner)

    -- Remove squashable tag, will become squashable again after respawning
    owner.tags.removeTag('squashable')
    -- Have been squashed
    owner.tags.addTag('squashed')

    notifyCarriedIfCarrying('carrier.squashed')
    owner.bus.send({'squashed'}, nil, false)
end

---Called externally when told to respawn
function respawnFromSquashed()
    -- No longer squashed
    owner.tags.removeTag('squashed')

    if SpawnsInGrid.trySetActive(respawnConditions, onActive, onVisibleFromRespawn) == false then
        log:error('Failed to respawn player/set active - this should never be allowed to happen')
        return
    end

    -- Unlock achievement! Squashed by patient
    AchievementsHelper.unlockSquashedByPatientAchievement()
end

---@param _ Message
local function onSiblingGrew(_)
    if launchedSinceRespawning then
        -- Protection against launching multiple times in cases where sibling.grew is received multiple times,
        --  due to there being more than one growing sibling on the same tile
        return
    end
    -- Camera shouldn't focus on player when launched
    CameraTargetHelper.disableCameraTargetFor(owner)
    launchedSinceRespawning = true
    -- Sibling object grew - player is launched into the air & respawns
    notifyCarriedIfCarrying('carrier.launched')
    owner.bus.send({ 'player.launched' }, nil, false)
    if SpawnsInGrid.trySetActive(respawnConditions, onActive, onVisibleFromRespawn) == false then
        error('Failed to respawn player/set active - this should never be allowed to happen')
    end
end

-- Squashable at start
owner.tags.addTag('squashable')

owner.bus.subscribe('sibling.grew', onSiblingGrew)
