---CoOperation Act mod.
---Handles the `act` verb to handle picking-up and placing-down carryable items in a direction.
---This initially includes patients and medicine.

local Log = require('Log')
local log = Log.new()

local DirectionUtils = require('DirectionUtils')

---@type MapMobile
local owner = owner or error('No owner')

-- Bring in the ability to subscribe to the GameManager's message bus for game phase changes
---@type Game
local game = LoadFacility('Game')['game']

---@type AchievementsHelper
local AchievementsHelper = require('AchievementsHelper')
---@type CarryHelper
local CarryHelper = require('CarryHelper')
---@type NarrativeSaveDataKeys
local NarrativeSaveDataKeys = require('NarrativeSaveDataKeys')
---@type MoneyUtils
local MoneyUtils = require('MoneyUtils')
---@type WaitActionHelper
local WaitActionHelper = require('WaitActionHelper')
---@type SoundUtils
local SoundUtils = require('SoundUtils')

-- Check whether carrying
local carrier = owner.getFirstComponentTagged('carrier');
assert(nil ~= carrier and 'Carrier' == carrier.typeName, 'Player lacks carrier component')

---@type Turn[] | nil
local mostRecentTurns

--- 0 = never do special wait, 1 = do at every opportunity (max. once per rounnd)
local specialWaitRandomChance = specialWaitRandomChance or 0

--- Number representing the most recent wait variation that was performed
---@type number
local mostRecentWaitNum = -1
--- Numbers for wait animations that have not yet been played (see: doNormalWaitRandomly())
---@type number[]
local randomWaitNumbers = {}

---@type string
local mostRecentCarriedPatientName = ''

---@type boolean
local destroyed = false

---@param carryable Carryable
local function startCarrying(carryable)
    -- Make sure the carryable can definitely be carried before going any further
    if not carrier.canCarry(carryable) then
        log:log('Cannot carry ', carryable.owner, ' (canCarry() returned false)')
        return false
    end

    -- For certain objects, the MapObject to be carried is replaced with a
    -- version that had its art3d position set to (0, 0, 0) to remove any visual offset.
    -- For many objects such as patients, simply returns the given carryable.
    local targetCarryable = CarryHelper.cloneAndPositionForCarryingIfRequired(carryable)

    if targetCarryable.owner.tags.hasTag('patient') then
        if targetCarryable.owner.hasFunc('getCharacterName') then
            mostRecentCarriedPatientName = targetCarryable.owner.callFunc('getCharacterName')
        end
    end

    -- Play sound, depending on which object is being carried and which player character this is
    local characterName = ''
    if owner.hasFunc('getCharacterName') then
        characterName = owner.callFunc('getCharacterName')
    end
    SoundUtils.playCarryingSound(characterName, targetCarryable)

    -- Carry!
    local carrySuccess = carrier.carry(targetCarryable)
    targetCarryable.owner.bus.send({ 'carried' }, nil, false)
    if not carrySuccess then
        error('carrier ' .. tostring(carrier) .. ' unable to carry ' .. tostring(targetCarryable.owner) .. ' despite canCarry() returning true on the original object')
    end
    log:log('Carrying ', targetCarryable.owner)
    return true
end

---Attempt to carry in the direction facing.
local function tryCarryInDirectionFacing()
    local mapObject = owner.getFirstFacingObjectTagged('carryable')
    if nil == mapObject then
        return false
    end

    local resultantCarryable = mapObject.getFirstComponentTagged('carryable')
    if nil == resultantCarryable then
        return false
    end

    -- carry it!
    return startCarrying(resultantCarryable)
end

---Check tile in-front for an `Interact`-tagged object and
---attempt to call an `interact()` method on it.
---Result of that function is either `false`/`nil` (for failure) or `true`/a `MapObject` to carry on success.
---When a `MapObject` is returned, it's checked for `carryable` flag and carried if present.
---@param actDirection Direction
---@return boolean @ Whether successfully interacted.
local function interactInDirection(actDirection)
    log:log('Trying to interact in ', actDirection)
    local interactable = owner.getFirstFacingObjectTagged('Interact')
    if nil == interactable then
        log:log('No interactable')
        return false
    end

    if not interactable.hasFunc('interact') then
        log:log('No interact function on ', interactable)
        return false
    end

    -- Interact with the target.
    -- false = failure, nil = fine, mapObject = do something with it (carry it)
    local result = interactable.callFunc('interact')
    log:debug('Interacted with', interactable, 'result:', result, 'type:', type(result))
    if false == result then
        -- false result means failure
        log:log('Interacted with ', interactable, ' but failed')
        return false
    end
    if nil == result or true == result then
        -- nil result is fine, just means all done (as does true)
        log:log('Successfully interacted with ', interactable)
        return true
    end

    -- Cast result to remove boolean and nil types
    local resultMapObject = (--[[---@not boolean|nil]] result)

    local resultantCarryable = resultMapObject.getFirstComponentTagged('carryable')
    if nil ~= resultantCarryable then
        -- carry it!
        return startCarrying(resultantCarryable)
    end

    -- not a carryable result = TODO
    return true
end

---Act for the doctor.
---Called externally (from framework).
---If not carrying, tries to pick something up.
---If carrying patient, tries to place in bed (or another acceptable place if not).
---If carrying medicine, calls 'administer' on the medicine lua script
function act(actDirection)
    log:log('acting in direction:', actDirection)

    if nil == actDirection or not DirectionUtils.isDirection(actDirection) then
        log:error('Invalid direction supplied: ', actDirection)
        return false
    end

    -- Face in direction of action
    owner.setFacing(actDirection)

    local isCarrying = carrier.isCarrying
    log:log('Lua isCarrying:', isCarrying)

    local success = false

    if isCarrying then
        local carried = carrier.getCurrentlyCarried() -- gives us a Carryable component
        log:log('current carried:', carried)

        ---Ask what we're carrying to act for us (medicine, patient etc)
        if carried.owner.hasFunc('actWhenCarried') then
            log:log('Calling actWhenCarried on carried object')
            success = carried.owner.callFunc('actWhenCarried', owner, carrier, actDirection)
        else
            log:log("No 'actWhenCarried' on ", carried.owner, " so cannot act with it!")
            success = false
        end
    else
        if interactInDirection(actDirection) then
            success = true
        else
            -- Not carrying, look for something to pick up
            success = tryCarryInDirectionFacing()
        end
    end

    if not success then
        -- Acting failed/we did nothing
        log:log('Failed to act in direction ', actDirection)
        game.bus.send({ metadata = { 'player.actionFailed' }, data = { position = owner.gridPosition, direction = actDirection } }, false)
        SoundUtils.playInvalidActionSound()
        owner.bus.send({ 'player.actionFailed' }, false)

        local sofaInteractedWith = owner.getFirstFacingObjectTagged('sofa')
        if sofaInteractedWith ~= nil then
            local playerComponent = owner.getFirstComponentTagged('Player')
            assert(playerComponent ~= nil)
            -- Save data - used for conditional narrative text
            game.saveData.setNumber(NarrativeSaveDataKeys.thisRound_playerActedAtSofa(), 1)
            game.saveData.setString(NarrativeSaveDataKeys.global_mostRecentActedAtSofaPlayer(), playerComponent.playerName)
            game.saveData.save()
        end
    end

    return success
end

---@param message Message
local function onMapObjectStateChanged(message)
	if message.data['state.MapObject'] == 'Destroyed' then
        destroyed = true
	end
end

--- This player threw something, but it was not caught and landed/smashed
---@param message Message
local function onThrewToUncaught(message)
    local throwableTags = message.data.threwToUncaught;
    if throwableTags == nil then
        error('onThrewToUncaught with no tags data')
    end

    local playerComponent = owner.getFirstComponentTagged('Player')
    assert(playerComponent ~= nil)

    -- Save data - used for conditional narrative text
    -- Handled here rather than ThrowMod as it relates to dropping the carried object
    if throwableTags.hasTag('pills') then
        -- Smashed pills!
        game.saveData.setNumber(NarrativeSaveDataKeys.thisRound_didPlayerDropPills(), 1)
        game.saveData.setString(NarrativeSaveDataKeys.global_mostRecentPillDropPlayer(), playerComponent.playerName)
    elseif throwableTags.hasTag('patient') then
        -- Threw patient to uncaught!
        game.saveData.setNumber(NarrativeSaveDataKeys.thisRound_didPlayerDropPatient(), 1)
        game.saveData.setString(NarrativeSaveDataKeys.global_mostRecentPatientDropPlayer(), playerComponent.playerName)
        game.saveData.setString(NarrativeSaveDataKeys.global_mostRecentDroppedPatient(), mostRecentCarriedPatientName)
    end
    game.saveData.setNumber(NarrativeSaveDataKeys.thisRound_didPlayerThrowToUncaught(), 1)
    game.saveData.save()
end

local function doSpecialWaitAndEarnCoin()
    game.saveData.setNumber(NarrativeSaveDataKeys.thisRound_didPlayerDoSpecialWait(), 1)

    owner.bus.send({['state.player'] = (carrier.isCarrying and 'IdleCarry' or 'Idle')}, nil, false)

    setAutoAwait(false)
    local specialWaitTasks = {}
    table.insert(specialWaitTasks,
        owner.bus.send({['state.player'] = 'WaitSpecial'}, nil, false)
    )
    -- +1 coin for special wait!
    -- Update coin scoreboard with animation, then actually pay in
    local coinScoreboard = owner.map.getFirstObjectTagged('coinScoreboard')
    if coinScoreboard ~= nil then
        local credit = game.saveData.getNumber('credit')
        table.insert(specialWaitTasks,
            coinScoreboard.bus.send({
                metadata = { 'coinScoreboard.updateDisplayedBalance' },
                data = {
                    balance = credit + 1,
                    moneyEarnedSequence = { 1 },
                    originPos = owner.gridPosition,
                    delay = 1.4
                }
            })
        )
    end

    for task in specialWaitTasks do
        task.await()
    end
    setAutoAwait(true)
    MoneyUtils:payIn(1)

    -- Unlock achievement! Perform special wait
    AchievementsHelper.unlockSpecialWaitAchievement()
end

local function doRandomNormalWait()
    if #randomWaitNumbers == 0 then
        -- All wait variations have already been seen (or first time),
        --  so reset the randomWaitNumbers array, allowing all to be chosen again
        randomWaitNumbers = { 1, 2, 3, 4, 5 }
    end
    local chosenWaitNum = mostRecentWaitNum
    local chosenWaitNumIndex = 1
    -- Choose a random number for the wait state,
    --  ensuring the same one is never chosen twice
    while chosenWaitNum == mostRecentWaitNum do
        chosenWaitNumIndex = math.random(#randomWaitNumbers)
        chosenWaitNum = randomWaitNumbers[chosenWaitNumIndex]
    end
    table.remove(randomWaitNumbers, chosenWaitNumIndex)
    mostRecentWaitNum = chosenWaitNum

    -- Enter idle state first, to ensure player returns to idle animation after waiting
    owner.bus.send({['state.player'] = (carrier.isCarrying and 'IdleCarry' or 'Idle')}, nil, false)
    -- Send { state.player = WaitNormal[number] } message, which will trigger the corresponsing wait animation
    owner.bus.send({['state.player'] = ('WaitNormal' .. tostring(chosenWaitNum))}, nil, false)
end

---@param playerComponent table
---@param turnNumber1Based number
local function onPlayerWaiting(playerComponent, turnNumber1Based)
    game.saveData.setNumber(NarrativeSaveDataKeys.thisRound_didPlayerWait(), 1)

    if carrier.isCarrying then
        -- Can't do wait animation when carrying
        return
    end

    if not WaitActionHelper.doesTurnHaveNonWaitAction(turnNumber1Based) then
        -- Everyone is waiting on the current turn, so skip playing any kind of wait animation
        return
    end

    local inShop = game.levelNumber == game.totalNumberOfLevels
    local specialWaitPlayerNum = WaitActionHelper.getSpecialWaitPlayerNumber()
    local specialWaitTurnNum = WaitActionHelper.getSpecialWaitTurnNumber()

    -- Player will do a 'special' wait instead of a normal wait if:
    --  - Not in the shop/results level (because earning money from a special wait can throw off the balance for a pending purchase), AND
    --  - This player & turn number were chosen as a possible special wait by WaitActionManager, AND
    --  - Random chance (based on the specialWaitRandomChance value), to prevent it happening at every possible opportunity
    local shouldDoSpecialWait = false
    if (not inShop) and (specialWaitPlayerNum == playerComponent.playerNumber) and (specialWaitTurnNum == turnNumber1Based) then
        if math.random() <= specialWaitRandomChance then
            shouldDoSpecialWait = true
        end
    end

    if shouldDoSpecialWait then
        doSpecialWaitAndEarnCoin()
    else
        doRandomNormalWait()
    end
end

local function onPlayerActionStart(message)
    if destroyed then
        return
    end
    if message.data.turnNumber == nil then
        error('No turnNumber data in playerActionStart message')
    end
    if message.data.playerNumber == nil then
        error('No playerNumber data in playerActionStart message')
    end
    if mostRecentTurns == nil then
        -- No turns set (e.g. testing or in level design)
        return
    end

    local playerComponent = owner.getFirstComponentTagged('Player')
    if playerComponent == nil or playerComponent.playerNumber ~= message.data.playerNumber then
        -- nil playerComponent = e.g. player permanently disconnencted while turns were taking place
        -- Different playerNumber = not this player's action
        return
    end

    -- 1-based index for lua arrays, i.e. first turn = 1
    local turnNumberAdjusted = message.data.turnNumber + 1

    ---@type Turn
    local turnData = mostRecentTurns[turnNumberAdjusted]
    if turnData.action == nil or turnData.action == '' then
        onPlayerWaiting(playerComponent, turnNumberAdjusted)
    end
end

---@param message Message
local function onSetTurns(message)
    if destroyed then
        return
    end
    ---@type Turn[]|nil
    local turns = message.data['MultiTurn.setTurns']
    if turns == nil or #turns == 0 then
        error('No turns data in MultiTurn.setTurns message')
    end
    mostRecentTurns = turns
end

owner.bus.subscribe('state.MapObject', onMapObjectStateChanged)
owner.bus.subscribe('threwToUncaught', onThrewToUncaught)
owner.bus.subscribe('MultiTurn.setTurns', onSetTurns)
game.bus.subscribe('playerActionStart', onPlayerActionStart)

log:debug('Act mod ready')
