--- Throw mod
local Log = require('Log')
local log = Log.new()

local SearchType = require('SearchType')

---@type AchievementsHelper
local AchievementsHelper = require('AchievementsHelper')
---@type DirectionUtils
local DirectionUtils = require('DirectionUtils')
---@type KnockbackHelper
local KnockbackHelper = require('KnockbackHelper')
---@type NarrativeSaveDataKeys
local NarrativeSaveDataKeys = require('NarrativeSaveDataKeys')
---@type MessageHelpers
local MessageHelpers = require('MessageHelpers')
---@type Vector
local V2 = require('Vector')
---@type SoundUtils
local SoundUtils = require('SoundUtils')

local adjacentOffsets = {
	{  0, -1 }, -- North,
	{  1,  0 }, -- East,
	{  0,  1 }, -- South,
	{ -1,  0 }, -- West
}

---@type MapMobile
local owner = owner or error('No owner')

-- Bring in the ability to subscribe to the GameManager's message bus for game phase changes
local game = LoadFacility('Game')['game']

---@type boolean
local levelFinished

---@param blockerObject MapObject
---@param landingPosition V2
---@param throwableTags Tags
---@param playerName string
local function notifyAdjacentBlockingObjectOfThrowableHit(blockerObject, landingPosition, throwableTags, playerName)
    -- Check if the object that blocked the throw is adjacent to the landing position
    local isBlockerAdjacentToLandingPos = false
    for offset in adjacentOffsets do
        local adjacentPos = V2.new(landingPosition[1] + offset[1], landingPosition[2] + offset[2])
        if blockerObject.gridPosition[1] == adjacentPos[1] and blockerObject.gridPosition[2] == adjacentPos[2] then
            isBlockerAdjacentToLandingPos = true
            break
        end
    end
    if not isBlockerAdjacentToLandingPos then
        -- Blocking object is not adjacent to landing position
        return
    end

    if blockerObject.tags.hasTag('wobbleWhenBumped') then
        blockerObject.bus.send({ 'wobble' }, nil, false)
    end

    if blockerObject.tags.hasTag('knockbackTarget') and blockerObject.typeName == 'MapMobile' then
        KnockbackHelper.hitObject(blockerObject--[[@as MapMobile]], owner.facing, SoundUtils, AchievementsHelper)
    end

    -- Tell the adjacent blocking object that it was hit
    if blockerObject.hasFunc('onHitByThrowable') then
        blockerObject.callFunc('onHitByThrowable', throwableTags, playerName)
    end
end

-- Action called by the 'throw' action from the 'phone' controller
---@return boolean
function throw(throwDirection)
    log:debug('Throwing getting actor from owner:', owner)
    ---@type CoOpActor
    local coOpActor = owner.getFirstComponentTagged('CoOpActor', SearchType.SelfOnly)
    log:log('Modding throwing ', throwDirection, ' for owner:', owner, ' with actor:', coOpActor)

    if nil == throwDirection or not DirectionUtils.isDirection(throwDirection) then
        log:error('Invalid direction supplied: ', throwDirection)
        return false
    end

    -- Check if we're carrying something before playing sound
    local carrier = owner.getFirstComponentTagged('carrier')
    if carrier and carrier.isCarrying then
        SoundUtils.playThrowSound()
    end

    local shrunkSibling = owner.map.getFirstTagged(owner.gridPosition, 'shrunk')
    local throwingShrunkObject = (shrunkSibling ~= nil)
    local throwingShrunkBed = throwingShrunkObject and (shrunkSibling.tags.hasTag('bed'))

    local result = coOpActor.throwInDirection(throwDirection)

    if result then
        if throwingShrunkObject then
            -- Unlock achievement! Throw a shrunken item
            AchievementsHelper.unlockThrowShrunkenItemAchievement()
        end
        if throwingShrunkBed then
            -- Unlock achievement! Throw a shrunken bed
            AchievementsHelper.unlockThrowShrunkenBedAchievement()
        end
    else
        game.bus.send({ metadata = { 'player.actionFailed' }, data = { position = owner.gridPosition, direction = throwDirection } }, false)
        SoundUtils.playInvalidActionSound()
        owner.bus.send({ 'player.actionFailed' }, false)
    end
    return result
end

--- This player is about to throw something to another player
---@param message Message
local function onThrowingToCaught(message)
    local throwableTags = message.data.throwingToCaught;
    if throwableTags == nil then
        error('onThrowingToCaught with no tags data')
    end

    if throwableTags.hasTag('syringe') then
        SoundUtils.playPickUpSyringeSound(0.4)
    elseif throwableTags.hasTag('pills') then
        SoundUtils.playPickUpPillsSound(0.4)
    elseif throwableTags.hasTag('apple') then
        SoundUtils.playPickUpAppleSound(0.3)
    elseif throwableTags.hasTag('coin') then
        SoundUtils.playCoinSound(0.3)
    end
end

--- This player is about to throw something, but it won't be caught (i.e. will be dropped/smash)
---@param message Message
local function onThrowingToUncaught(message)
    local throwableTags = message.data.throwingToUncaught;
    if throwableTags == nil then
        error('onThrowingToCaught with no tags data')
    end
end

--- This player caught something that was thrown to them
---@param _ Message
local function onCaughtObject(_)
    if levelFinished then
        return
    end

    local playerComponent = owner.getFirstComponentTagged('Player')
    assert(playerComponent ~= nil)
    game.saveData.setString(NarrativeSaveDataKeys.global_mostRecentCatchingPlayer(), playerComponent.playerName)
end

--- This player threw something, and it was caught by another player
---@param message Message
local function onThrewToCaught(message)
    if levelFinished then
        return
    end

    local throwableTags = message.data.threwToCaught;
    if throwableTags == nil then
        error('onThrewToCaught with no tags data')
    end

    local playerComponent = owner.getFirstComponentTagged('Player')
    assert(playerComponent ~= nil)

    -- Save data - used for conditional narrative text
    local thrownObjNameKey = NarrativeSaveDataKeys.getStringTableKeyForNameOfObjectFromTags(throwableTags)
    game.saveData.setNumber(NarrativeSaveDataKeys.thisRound_didPlayerCatch(), 1)
    game.saveData.setString(NarrativeSaveDataKeys.global_mostRecentCaughtObject(), thrownObjNameKey)
    game.saveData.setString(NarrativeSaveDataKeys.global_mostRecentThrowToTeammatePlayer(), playerComponent.playerName)
    if throwableTags.hasTag('Patient') then
        game.saveData.setNumber(NarrativeSaveDataKeys.thisRound_didPlayerThrowPatient(), 1)
    end
    -- +1 successful catch!
    local playerCatchCount = game.saveData.getNumber(NarrativeSaveDataKeys.global_playerCatchCount())
    playerCatchCount = playerCatchCount + 1
    if playerCatchCount >= 50 then
        -- Unlock achievement! 50 successful catches
        AchievementsHelper.unlockCatch50TimesAchievement()
    elseif playerCatchCount >= 25 then
        -- Unlock achievement! 25 successful catches
        AchievementsHelper.unlockCatch25TimesAchievement()
    elseif playerCatchCount >= 5 then
        -- Unlock achievement! 5 successful catches
        AchievementsHelper.unlockCatch5TimesAchievement()
    end
    game.saveData.setNumber(NarrativeSaveDataKeys.global_playerCatchCount(), playerCatchCount)
    game.saveData.save()
end

--- This player threw something, but it was not caught and landed/smashed
---@param message Message
local function onThrewToUncaught(message)
    if levelFinished then
        return
    end

    local throwableTags = message.data.threwToUncaught;
    if throwableTags == nil then
        error('onThrewToUncaught with no tags data')
    end
    local landingPosition = message.data.landingPosition
    if landingPosition == nil then
        error('onThrewToUncaught with no landingPosition data')
    end

    local springAtLandingPos = owner.map.getFirstTagged(landingPosition, 'spring')
    if springAtLandingPos ~= nil and springAtLandingPos.hasFunc('hitWithoutSpringing') then
        springAtLandingPos.callAction('hitWithoutSpringing')
    end

    if throwableTags.hasTag('syringe') then
        -- Play sound for dropped syringes
        SoundUtils.playDropSyringeSound()
    elseif throwableTags.hasTag('pills') then
        -- Play sound for dropped pills
         SoundUtils.playDropPillsSound()
    elseif throwableTags.hasTag('apple') then
        -- Play sound for dropped apples
         SoundUtils.playDropAppleSound()
    elseif throwableTags.hasTag('coin') then
        -- Play sound for dropped coins
        SoundUtils.playCoinSound()
    elseif throwableTags.hasTag('patient') then
        -- Play sound for patient hitting wall
        SoundUtils.playPatientHitWallSound()
    end

    local playerComponent = owner.getFirstComponentTagged('Player')
    assert(playerComponent ~= nil)

    local blockerObjectId = message.data.blockerObject
    if blockerObjectId == nil or blockerObjectId < 0 then
        return
    end
    local blockerObject = MessageHelpers.getMapObjectViaIdFromMessage(message, 'blockerObject')
    notifyAdjacentBlockingObjectOfThrowableHit(blockerObject, landingPosition, throwableTags, playerComponent.playerName)
end

---@param carryableOwner MapObject
---@param travelDistance number
---@param blockerObj MapObject
local function reboundFromBlocker(carryableOwner, travelDistance, blockerObj)
    setAutoAwait(false)
    local reboundTasks = {}

    table.insert(
        reboundTasks,
        carryableOwner.bus.send({
            metadata = { 'throwToObjectRebound' },
            data = {
                direction = owner.facing,
                scaleVectors = { x = travelDistance + 0.25, y = (1 + travelDistance * 0.5) }
            }
        }, false)
    )

    -- The blocker object that was hit will wobble or do a bouncy tween animation
    if blockerObj.tags.hasTag('wobbleWhenBumped') then
        blockerObj.bus.send({ 'wobbleOnRebound' }, nil, false)
    else
        table.insert(
            reboundTasks,
            blockerObj.bus.send({
                metadata = { 'objectCollided' },
                data = {
                    direction = owner.facing,
                    animDelaySecs = 0.55
                }
            }, false)
        )
    end

    -- Any animations will play simultaneously
    for task in reboundTasks do
        task.await()
    end
    setAutoAwait(true)
end

---@param carryableOwner MapObject
---@param travelDistance number
local function reboundFromGround(carryableOwner, travelDistance)
    carryableOwner.bus.send({
        metadata = { 'throwToGroundRebound' },
        data = {
            direction = owner.facing,
            scaleVectors = { x = travelDistance, y = (1 + travelDistance * 0.5) }
        }
    }, false)
end

--- Called when a throw fails because it's blocked/there's nowhere to land
---@param message Message
local function onThrowRebound(message)
    if levelFinished then
        return
    end

    local reboundPos = message.data['reboundPosition']
    if reboundPos == nil then
        error('no reboundPosition data in throwRebound message')
    end

    local carryableOwner = owner.map.getFirstTagged(owner.gridPosition, 'carryable')
    if carryableOwner == nil then
        return
    end

    local reboundX = reboundPos[1]
    local reboundY = reboundPos[2]
    local changeX = math.abs(reboundX - owner.gridPosition[1])
    local changeY = math.abs(reboundY - owner.gridPosition[2])
    local travelDistance = math.max(changeX, changeY)

    carryableOwner.bus.send({
        metadata = { 'throwStart' },
        data = {
            direction = owner.facing,
        }
    }, false)

    -- Get the object that the throwable should hit/bounce off before rebounding (if any)
    local blockerAtPos = nil
    if (reboundX >= 0 and reboundX < owner.map.size[1] and reboundY >= 0 and reboundY < owner.map.size[2]) then
        blockerAtPos = owner.map.getFirstTagged(reboundPos, 'blocksMove or blocksThrow')
    end

    if blockerAtPos ~= nil then
        -- Throwable will hit blocker and rebound back to us
        reboundFromBlocker(carryableOwner, travelDistance, blockerAtPos)
    else
        -- Throwable will hit ground and rebound back to us
        reboundFromGround(carryableOwner, travelDistance)
    end
end

local function onGamePhase(msg)
	local phase = msg.data.gamePhase;
	if phase == 'finished' then
		levelFinished = true
	end
end

log:debug('Throw mod ready')

owner.bus.subscribe('throwingToCaught', onThrowingToCaught)
owner.bus.subscribe('throwingToUncaught', onThrowingToUncaught)
owner.bus.subscribe('threwToCaught', onThrewToCaught)
owner.bus.subscribe('threwToUncaught', onThrewToUncaught)
owner.bus.subscribe('throwRebound', onThrowRebound)
owner.bus.subscribe('caught', onCaughtObject)
game.bus.subscribe('gamePhase', onGamePhase)
