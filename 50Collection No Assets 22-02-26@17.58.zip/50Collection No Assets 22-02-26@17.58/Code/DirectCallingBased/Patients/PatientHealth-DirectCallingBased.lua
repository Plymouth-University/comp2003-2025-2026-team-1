---Patient health and ailment.
---Sends 'state.patient' messages when changing state (things like 'IdleWaitingForDoctor' and 'Cured').

-- Bring in the ability to subscribe to the GameManager's message bus for game phase changes
---@type Game
local game = LoadFacility('Game')['game']

---@type AchievementsHelper
local AchievementsHelper = require('AchievementsHelper')
---@type CarryHelper
local CarryHelper = require('CarryHelper')
---@type SquashHelper
local SquashHelper = require('SquashHelper')
---@type SpawnsInGrid
local SpawnsInGrid = require('SpawnsInGrid')
---@type NarrativeSaveDataKeys
local NarrativeSaveDataKeys = require('NarrativeSaveDataKeys')
---@type MoneyModifierApplier
local moneyModifierApplier = require('MoneyModifierApplier')
---@type SaveDataHelper
local SaveDataHelper = require('SaveDataHelper')
---@type Vector
local V2 = require('Vector')
---@type MoneyUtils
local MoneyUtils = require('MoneyUtils')
---@type CameraTargetHelper
local CameraTargetHelper = require('CameraTargetHelper')
---@type SoundUtils
local SoundUtils = require('SoundUtils')

local Log = require('Log')
local log = Log.new()

--local allNeeds = allNeeds or { 'pill', 'syringe' }

---@type string
local need = need or 'pill'
-- Or assign from random selection with:
-- need = allNeeds[math.random(#allNeeds)]

---@type MapMobile
local owner = owner or error('No owner')

---Health of patient.  Explicitly *NOT* a local so tests can retrieve the value!
---@type number
health = health or 5
---@type number
local healthOnStart
---@type number
local healthToCure

---@type number
local healthLostWhenDropped = healthLostWhenDropped or 1
---@type number
local healthLostWhenSprungFromOutside = healthLostWhenSprungFromOutside or 2
---@type number
local healthLostWhenGivenWrongMedicine = healthLostWhenGivenWrongMedicine or 1
---@type number
local healthLostWhenHitByMedicine = healthLostWhenHitByMedicine or 1
---@type number
local healthLostWhenHitByPatient = healthLostWhenHitByPatient or 1
---@type number
local healthLostWhenSquashed = healthLostWhenSquashed or 1
---@type number
local healthLostOnNewRound = healthLostOnNewRound or 1

---@type number
local healthDisplayOffset = healthDisplayOffset or 0.7
---@type number
local healthDisplayCarryOffset = healthDisplayCarryOffset or 1.25

---@type boolean
local showingHealthIndicator = false

---@type number @ Round to appear on (counted from 1)
local appearOnTurn = appearOnTurn or 0
log:log('appearOnTurn:', appearOnTurn)

---@type number
local displaySpawnTimerRounds = displaySpawnTimerRounds or 2

---@type number
local turnsPerRound

---@type number
local blocksThrowWhenStanding = blocksThrowWhenStanding or 1

---Number of rounds until active
---@type number
local numRoundsTillActive = -1
---@type number
local numTurnsTillActive = -1

---@type boolean
local spawnedFirstTime = false
---@type boolean
local visibleFirstTime = false

---@type boolean
local inPlanningPhase = false

---@type boolean
local beingSquashed = false

---Whether this has been destroyed.
---@type boolean
local destroyed = false

---@type number
local healthToLoseOnActive = 0

--- Whether the patient has been picked up in the current level
---@type boolean
local everCarried = false

--- Whether the patient appeared for the first time in the most recent planning phase
---@type boolean
local spawnedThisRound = false

---@type MapObject|nil
local spawnDecalObject

---Called externally
---@return number
function getHealth()
    return health
end
---Called externally
---@return number
function getStartingHealth()
    return healthOnStart
end

---Called externally
---@return string
function getNeed()
    return need
end

---Called externally
---@return boolean
function isActive()
    return SpawnsInGrid.getActive()
end

---Called externally
---@return boolean
function hasEverBeenCarried()
    return everCarried
end

---Called externally
---@return boolean
function didSpawnThisRound()
    return spawnedThisRound
end

local function sendState(newState)
    if newState == nil then
        log:warn('Skipping sending patient state because newState is nil')
        return
    end
    log:log('Setting state:', newState)
    owner.bus.send({['state.patient'] = newState})
end

---@param withDelay boolean
local function showHealthIndicator(withDelay)
    if destroyed or beingSquashed or health <= 0 then
        return
    end
    local carryable = owner.getFirstComponentTagged('carryable')
    local posYOffset = carryable.isAvailableToBeCarried and healthDisplayOffset or healthDisplayCarryOffset
    showingHealthIndicator = true
    owner.bus.send({
        metadata = { 'objectCountdown.show' },
        data = {
            displayType = "health",
            value = health,
            maxValue = healthToCure,
            positionOffset = { y = posYOffset },
            delay = (withDelay and 2 or 0)
        }
    }, nil, false)
end

local function hideHealthIndicator()
    if destroyed then
        return
    end
    if not showingHealthIndicator then
        return
    end
    owner.bus.send({ 'objectCountdown.hide' }, nil, false)
end

local function loseHealth(delta, alertPlayers)
    if 0 < health then
        log:log('Active so reducing health by '.. delta .. ' from ' .. health .. ' to ' .. health - delta)
        health = health - delta

        -- Play hurt sound when patient loses health, but only during action phase
        if not inPlanningPhase then
            SoundUtils.playPatientHurtSound()
        end

        if alertPlayers then
            local alertHealthLossMsg = { metadata = { 'healthAlert.show' }, data = { value = -delta, position = owner.gridPosition } }
            game.bus.send(alertHealthLossMsg, nil, false)
        end

        if inPlanningPhase then
            showHealthIndicator(true)
        end

        if 0 >= health then
            -- Save data - patient left the ward this round! Used for conditional narrative text
            game.saveData.setNumber(NarrativeSaveDataKeys.thisRound_didPatientLeave(), 1)

            SoundUtils.playPatientExitSound()

            -- Set patient state to 'Dead', triggering a fade out animation
            sendState('Dead')
            owner.destroyObject()
            destroyed = true

            -- Notify the scoreboard that a patient died (sent as a separate message on the Scoreboard MapObject's bus before sending
            --  'patient.died' on the main bus to ensure the scoreboard animation starts & completes before checking if the game was won/lost).
            --  We also supply the patient's gridPosition in this message which the Scoreboard requires for its animation.
            local scoreboard = owner.map.getFirstObjectTagged('scoreboard')
            if nil ~= scoreboard then
                scoreboard.bus.send({ metadata = { 'patientDied' }, data = { position = owner.gridPosition } })
            end

            -- Notify GameManager lua that a patient died
            game.bus.send({ 'patient.died' })
        end
    else
        log:log('Health 0 = the patient has passed out but keep playing')
    end
end

local function patientCanBecomeActive()
    local readyToSpawn = numRoundsTillActive <= 0

    -- Get the position where, if not blocked or invalid, the patient wants to spawn
    local spawnPos = SpawnsInGrid.getSpawnPosition()

    local bed = owner.map.getFirstTagged(spawnPos, 'Bed')
    if nil ~= bed and (bed.hasFunc('canAccept') and bed.callFunc('canAccept', owner)) then
        -- Patient is in same tile as a bed type that could accept them (e.g. normal bed if human, pet bed if animal)
        -- So, we assume this patient should start in a bed

        if not readyToSpawn then
            -- Patient is not ready to try and spawn in the bed yet
            return false
        end

        -- Patient is ready to spawn, check if the bed will accept them right now (i.e. not occupied)
        if bed.accept(owner) then
            -- Hide patient until they are set as active (so they don't appear in bed before 'falling into bed' animation)
            owner.bus.send({visible = false}, nil, false)
            -- Patient was accepted by the bed, can become active
            return true
        else
            -- Patient was not accepted by the bed
            -- When trying to spawn for the first time in a bed, the patient must wait for the bed to be available
            if not spawnedFirstTime then
                return false
            end
            -- Otherwise, also try the below other methods of spawning (adjacent tiles)
        end
    end

    -- Non-bed spawn checks:

    local canSpawnResult
    if readyToSpawn then
        -- Ready to spawn (not in a bed)
        -- Try to set spawn position to an unblocked tile at or adjacent to our initial spawn pos
        canSpawnResult = SpawnsInGrid.trySetSpawnToValidPositionNearTarget(spawnPos, SpawnsInGrid.bypassSquashableBlocker, true)
    else
        -- Not ready to spawn, but still try to find to a valid spawn position, so this patient can be moved there (see below)
        SpawnsInGrid.trySetSpawnToValidPositionNearTarget(spawnPos, SpawnsInGrid.bypassSquashableBlocker, true)
        canSpawnResult = false
    end

    local targetSpawnPos = SpawnsInGrid.getSpawnPosition()
    if not canSpawnResult then
        -- Don't spawn yet, but get the position we currently expect this patient will spawn at, and move them there
        -- (In combination with the spawn countdown, this will give players a clearer idea of where this patient will likely appear)
        if targetSpawnPos[1] ~= owner.gridPosition[1] or targetSpawnPos[2] ~= owner.gridPosition[2] then
            log:log('Expected patient spawn position differs from current pos, moving to (' .. tostring(targetSpawnPos[1]) .. ', ' .. tostring(targetSpawnPos[2]) .. ')')
            owner.repositionTo(targetSpawnPos)
        end
    end
    -- Also reposition spawn decal (if not already at correct position) to match current/planned spawn position
    if (spawnDecalObject ~= nil) and (targetSpawnPos[1] ~= spawnDecalObject.gridPosition[1] or targetSpawnPos[2] ~= spawnDecalObject.gridPosition[2]) then
        spawnDecalObject.repositionTo(targetSpawnPos)
    end

    return canSpawnResult
end

local function onActive()
    CameraTargetHelper.addPlaceholderCameraTarget(owner.gridPosition)

    if not spawnedFirstTime then
        spawnedThisRound = true
        spawnedFirstTime = true
    end

    -- Hide spawn countdown timer
    owner.bus.send({ 'objectCountdown.hide' }, nil, false)

    -- Ensure position of spawn decal matches patient position
    if spawnDecalObject ~= nil then
        if spawnDecalObject.gridPosition[0] ~= owner.gridPosition[0] or spawnDecalObject.gridPosition[1] ~= owner.gridPosition[1] then
            spawnDecalObject.repositionTo(owner.gridPosition)
        end
    end

    owner.tags.addTag('blocksMove')
    owner.tags.addTag('carryable')
    owner.tags.addTag('knockbackTarget')

    local bed = owner.map.getFirstTagged(owner.gridPosition, 'Bed')
    if (bed == nil) and (blocksThrowWhenStanding ~= 0) then
        -- Patients block throws only when not in bed
        owner.tags.addTag('blocksThrow')
    else
        -- Patient is in bed or should never block throws, so ensure tag is not present
        owner.tags.removeTag('blocksThrow')
    end

    SquashHelper.squashSquashablesAtOwnerPosition(owner, SoundUtils)

    if bed ~= nil then
        -- Active in bed, tell bed to show clipboard for new patient
        bed.bus.send({ 'updateClipboards' }, nil, false)
    end

    local newState = bed and 'InBed' or 'IdleWaitingForDoctor'
    sendState(newState)
end

local function onVisibleFromActive()
    -- 2024-06-18 - Extra null checks to help us spot/diagnose bug B0035
    -- (Error seen after sending 'patient.falling', but checking here too just in case)
    if owner == nil then
        error('onVisibleFromActive with nil owner (See: B0035)')
    end
    if owner.bus == nil then
        error('onVisibleFromActive with nil owner.bus (See: B0035)')
    end
    if owner.bus.send == nil then
        error('onVisibleFromActive with nil owner.bus.send (See: B0035)')
    end

    -- Play patient spawn sound when they first appear, and only if spawning after the start of the level
    if appearOnTurn > 1 and not visibleFirstTime then
        SoundUtils.playPatientSpawnSound()
    end

    -- Trigger falling animation only if this patient already spawned in, or is spawning in after level start
    if visibleFirstTime or appearOnTurn > 1 then
        owner.bus.send({'patient.falling'}, nil, false)
    end

    visibleFirstTime = true

    -- 2024-06-18 - Extra null checks to help us spot/diagnose bug B0035
    -- (Based on previous reports, seen 'attempt to call a nil value' here when sending {visible = true})
    if owner == nil then
        error('onVisibleFromActive, nil owner after sending \'patient.falling\' (See: B0035)')
    end
    if owner.bus == nil then
        error('onVisibleFromActive, nil owner.bus after sending \'patient.falling\' (See: B0035)')
    end
    if owner.bus.send == nil then
        error('onVisibleFromActive, nil owner.bus.send after sending \'patient.falling\' (See: B0035)')
    end

    owner.bus.send({visible = true}, nil, false)

    CameraTargetHelper.tryRemovePlaceholderCameraTarget(owner.gridPosition)
    CameraTargetHelper.enableCameraTargetFor(owner)

    SquashHelper.respawnSquashedAtOwnerPosition(owner)

    -- We don't become squashable again until anything that we squashed
    -- has respawned, to prevent potential infinite loops of squashing
    owner.tags.addTag('squashable')

    -- Lose some health if previously set, then reset value
    if healthToLoseOnActive > 0 then
        loseHealth(healthToLoseOnActive, true)
    end
    healthToLoseOnActive = 0

    if inPlanningPhase then
        showHealthIndicator(false)
    end

    game.bus.send({ 'patient.appeared' }, nil, false)
end

local function onInactive()
    -- Camera shouldn't focus on patient when inactive
    CameraTargetHelper.disableCameraTargetFor(owner)

    owner.tags.removeTag('blocksMove')
    owner.tags.removeTag('blocksThrow')
    owner.tags.removeTag('carryable')
    owner.tags.removeTag('knockbackTarget')

    sendState('OffScreen')

    -- Record how long until appearance (if appropriate).
    -- Measured from 1, i.e. a value of 2 means appear on the 2'nd turn!
    numRoundsTillActive = appearOnTurn
end

---Called externally when squashed
---@type fun()
function squash()
    -- Camera shouldn't focus on patient when squashed/falling
    CameraTargetHelper.disableCameraTargetFor(owner)

    local carryable = owner.getFirstComponentTagged('carryable')
    if not carryable.isAvailableToBeCarried then
        -- Don't squash if being carried, the carrier (player) will be squashed
        -- and we'll stay in sync with their position (currently done in C# model code)
        return
    end

    beingSquashed = true

    hideHealthIndicator()

    -- Remove squashable tag, will become squashable again after respawning
    owner.tags.removeTag('squashable')
    -- Have been squashed
    owner.tags.addTag('squashed')

    log:log('Squashed! ' .. tostring(owner))
    owner.bus.send({'squashed'}, nil, false)
end

---Called externally when told to respawn
---@type fun()
function respawnFromSquashed()
    -- No longer squashed
    owner.tags.removeTag('squashed')

    beingSquashed = false

    if SpawnsInGrid.trySetActive(patientCanBecomeActive, onActive, onVisibleFromActive) then
        log:log('Returning back to original spawn pos and losing health after being squashed')
        loseHealth(healthLostWhenSquashed, true)
    else
        -- Nowhere to respawn after being squashed, become inactive and try again each round
        SpawnsInGrid.setInactive(onInactive, nil, false)
        healthToLoseOnActive = healthLostWhenSquashed
    end
end

-- Called externally by NarrativeCharacter
---@return boolean
function canShowNarrativeText()
    if not SpawnsInGrid.getActive() then
        -- Don't show dialogue when inactive
        return false
    end
    if health <= healthLostOnNewRound then
        -- Skip showing dialogue if about to die
        return false
    end
    if beingSquashed then
        return false
    end
    return true
end

---Called externally
function canAdministerRemedy(remedy)
    local isActive = SpawnsInGrid.getActive()
    if not isActive then
        log:log('Not yet active')
        return {result='not yet active'}
    end

    local bed = owner.map.getFirstTagged(owner.gridPosition, 'Bed')
    if nil == bed then
        log:log('Must be in bed to be cured!')
        return {result='not in bed'}
    end

    log:log('Need remedy ' .. remedy)
    if remedy == need then
        log:log('Correct remedy!')
        return {result='success'}
    else
        log:log('Wrong remedy!')
        return {result='wrong'}
    end
end

---@return table
local function getMoneyToEarnWhenCured()
    local moneyBaseAmount = health

    -- For <4 turns per round, money is adjusted to ensure the reward is (close enough to) consistent regardless of game mode
    if turnsPerRound > 0 and turnsPerRound < 4 then
        local turnsMoneyModifier = turnsPerRound / 4
        local adjustedMoney = math.ceil(moneyBaseAmount * turnsMoneyModifier)
        log:log('Multiplying money from cure for '.. tostring(turnsPerRound) .. ' turn(s) per round: ' .. tostring(moneyBaseAmount) .. ' * ' .. tostring(turnsMoneyModifier) .. ' = ' .. tostring(adjustedMoney) .. ' (rounds up to nearest whole num if needed)')
        moneyBaseAmount = adjustedMoney
    end

    local moneyToEarn = moneyBaseAmount
    local moneyEarnedSequence = {}
    table.insert(moneyEarnedSequence, moneyBaseAmount)

    local moneyWithAppliedModifiers = moneyModifierApplier.applyAllModifiers(owner.gridPosition, moneyToEarn)
    if moneyWithAppliedModifiers ~= moneyToEarn then
        log:log('Money from cure had modifier(s) applied: '.. tostring(moneyToEarn) .. ' becomes ' .. tostring(moneyWithAppliedModifiers))
        table.insert(moneyEarnedSequence, moneyWithAppliedModifiers)
        moneyToEarn = moneyWithAppliedModifiers
    end

    -- Upgraded beds multiply the amount of money earned when cured
    local bed = owner.map.getFirstTagged(owner.gridPosition, 'Bed')
    if nil == bed then
        error('No bed on tile of cured patient')
    end
    if not bed.hasFunc('getRewardMultiplier') then
        error('No getRewardMultiplier() on bed')
    end
    local rewardMultiplierFromBed = bed.callFunc('getRewardMultiplier')
    if rewardMultiplierFromBed > 1 then
        local adjustedMoney = moneyToEarn * rewardMultiplierFromBed
        log:log('Multiplying money from cure by rewardMultiplier from bed: ' .. tostring(moneyToEarn) .. ' * ' .. tostring(rewardMultiplierFromBed) .. ' = ' .. tostring(adjustedMoney))
        table.insert(moneyEarnedSequence, 'x' .. tostring(rewardMultiplierFromBed))
        table.insert(moneyEarnedSequence, adjustedMoney)
        moneyToEarn = adjustedMoney
    end

    return {
        moneyToEarn = moneyToEarn,
        moneyEarnedSequence = moneyEarnedSequence
    }
end

local function setCuredSaveDataAndAchievements()
    -- Patient was cured this round! Used for conditional narrative text
    game.saveData.setNumber(NarrativeSaveDataKeys.thisRound_wasPatientCured(), 1)
    if not owner.hasFunc('getCharacterName') then
        return
    end
    -- +1 times cured!
    local characterName = owner.callFunc('getCharacterName')
    local timesCured = game.saveData.getNumber(NarrativeSaveDataKeys.global_patientCureCount(characterName))
    timesCured = timesCured + 1
    game.saveData.setNumber(NarrativeSaveDataKeys.global_patientCureCount(characterName), timesCured)

    if characterName == 'edBanger' then
        local lastCuredWardNum = game.saveData.getNumber('stat_edBangerLastCuredWardNumber')
        if (timesCured >= 2) and (lastCuredWardNum ~= game.levelNumber) then
            -- Unlock achievement! Ed was cured in at least 2 different wards
            AchievementsHelper.unlockHealEdIn2WardsAchievement()
        end
        game.saveData.setNumber('stat_edBangerLastCuredWardNumber', game.levelNumber)
    elseif characterName == 'cammy' then
        local lastCuredWardNum = game.saveData.getNumber('stat_cammyLastCuredWardNumber')
        if (timesCured >= 2) and (lastCuredWardNum ~= game.levelNumber) then
            -- Unlock achievement! Cammy was cured in at least 2 different wards
            AchievementsHelper.unlockHealCammyIn2WardsAchievement()
        end
        game.saveData.setNumber('stat_cammyLastCuredWardNumber', game.levelNumber)
    elseif characterName == 'oliviaAndAvo' then
        local lastCuredWardNum = game.saveData.getNumber('stat_oliviaAndAvoLastCuredWardNumber')
        if (timesCured >= 2) and (lastCuredWardNum ~= game.levelNumber) then
            -- Unlock achievement! Olivia was cured in at least 2 different wards
            AchievementsHelper.unlockHealOliviaIn2WardsAchievement()
        end
        game.saveData.setNumber('stat_oliviaAndAvoLastCuredWardNumber', game.levelNumber)
    end

    if need == 'pill' then
        -- Unlock achievement! Healed with pills
        AchievementsHelper.unlockHealWithPillsAchievement()
    elseif need == 'syringe' then
        -- Unlock achievement! Healed with syringe
        AchievementsHelper.unlockHealWithSyringeAchievement()
    elseif need == 'apple' then
        -- Unlock achievement! Healed with apple
        AchievementsHelper.unlockHealWithAppleAchievement()
    end
end

local function getHealthAlertGainMsg(healthIncrease)
    return {
        metadata = { 'healthAlert.show' },
        data = {
            value = healthIncrease,
            position = owner.gridPosition,
            awaitAnimation = true
        }
    }
end

local function sendGamePatientCuringMessage()
    local patientName = owner.name
    if owner.hasFunc('getCharacterName') then
        -- Character name from narrative conditions script
        patientName = owner.callFunc('getCharacterName')
    end
    game.bus.send({ metadata = { 'patient.curing' }, data = { patientName = patientName } }, nil, false)
end

local function cure(positionOfCurer, healthIncrease)
    log:log('Cured me with '.. health .. ' health')
    local moneyData = getMoneyToEarnWhenCured()
    local moneyToEarn = moneyData.moneyToEarn
    local moneyEarnedSequence = moneyData.moneyEarnedSequence

    setCuredSaveDataAndAchievements()
    sendGamePatientCuringMessage()

    -- Notify bed so it can hide clipboards when curing starts
    local bed = owner.map.getFirstTagged(owner.gridPosition, 'Bed')
    if bed ~= nil then
        bed.bus.send({ 'patientCureStart' }, nil, false)
    end

    -- Play curtain sound when curing starts
    SoundUtils.playCurtainsSound()

    setAutoAwait(false)
    local cureTasks = {}

    -- Set state to CuringInProgress - triggers bed curtain & patient idle/standing animation
    -- add curtain sound here
    -- (positionOfCurer should never be nil here, but was seen in B0038-Patient-onStateChangeAsync-no-curerPos)
    if positionOfCurer == nil then
        error('B0038: positionOfCurer is nil when about to send [\'state.patient\'] = \'Cured\' message')
    end

    table.insert(cureTasks,
        owner.bus.send({['state.patient'] = 'CuringInProgress', curerPos = positionOfCurer})
    )
    table.insert(cureTasks,
        game.bus.send(getHealthAlertGainMsg(healthIncrease), nil, false)
    )

    for task in cureTasks do
        task.await()
    end
    setAutoAwait(true)

    SoundUtils.playMoneySound()

    setAutoAwait(false)
    cureTasks = {}

    -- Display final health value, & hide with bounce
    table.insert(cureTasks,
        owner.bus.send({
            metadata = { 'objectCountdown.show' },
            data = { displayType = "health", value = health, colour = "#788B07", awaitAnimation = true }
        }, nil, false)
    )
    table.insert(cureTasks,
        owner.bus.send({
            metadata = { 'objectCountdown.hide' },
            data = { bounce = true, delay = 0.5, awaitAnimation = true }
        }, nil, false)
    )

    -- Update coin scoreboard with animation
    local credit = game.saveData.getNumber('credit')
    local coinScoreboard = owner.map.getFirstObjectTagged('coinScoreboard')

    if coinScoreboard ~= nil then
        table.insert(cureTasks,
            coinScoreboard.bus.send({
                metadata = { 'coinScoreboard.updateDisplayedBalance' },
                data = {
                    balance = credit + moneyToEarn,
                    moneyEarnedSequence = moneyEarnedSequence,
                    originPos = owner.gridPosition,
                    delay = 1.07,
                    squash = true
                }
            })
        )
    end

    -- Notify the smiley scoreboard that a patient was cured
    -- We also supply the patient's gridPosition in this message which the Scoreboard requires for its animation
    local patientScoreboard = owner.map.getFirstObjectTagged('patientScoreboard')
    if patientScoreboard ~= nil then
        patientScoreboard.bus.send({
            metadata = { 'patientCured' },
            data = {
                position = owner.gridPosition,
                moneyWasMultiplied = (#moneyEarnedSequence > 1)
            }
        })
    end

    -- All of the above actions/animations happen simultaneously
    for task in cureTasks do
        task.await()
    end
    setAutoAwait(true)

    -- Set patient state to 'Cured', triggering their 'thanks' animation, then destroy
    -- (positionOfCurer should never be nil here, but was seen in B0038-Patient-onStateChangeAsync-no-curerPos)
    if positionOfCurer == nil then
        error('B0038: positionOfCurer is nil when about to send [\'state.patient\'] = \'Cured\' message')
    end
    owner.bus.send({['state.patient'] = 'Cured', curerPos = positionOfCurer})
    owner.destroyObject()
    destroyed = true

    -- Actually pay in money
    log:log('Earned '.. moneyToEarn .. ' money from cure!')
    MoneyUtils:payIn(moneyToEarn)

    -- Notify bed that the patient is gone so it can reappear, ready for more patients
    bed = owner.map.getFirstTagged(owner.gridPosition, 'Bed')
    if bed ~= nil then
        bed.bus.send({ 'patientDestroyedAfterCure' }, nil, false)
    end

    game.saveData.save()
    -- Notify GameManager Lua that a patient was cured
    game.bus.send({ 'patient.cured' })
end

---Called externally when correct medicine is given
---@param positionOfCurer table
---@param healthIncrease number
function administerRemedy(positionOfCurer, healthIncrease)
    log:log('Patient had remedy administered with '.. health .. ' health - increasing by ' .. healthIncrease)
    health = health + healthIncrease

    if health >= healthToCure then
        cure(positionOfCurer, healthIncrease)
    else
        game.bus.send(getHealthAlertGainMsg(healthIncrease), nil, false)
        showHealthIndicator(false)
        owner.bus.send({
            metadata = { 'objectCountdown.hide' },
            data = { delay = 1.5, awaitAnimation = true }
        }, nil, false)
    end
end

---Called externally when wrong medicine is given
function givenWrongRemedy()
    log:log('Given wrong remedy, losing ' .. healthLostWhenGivenWrongMedicine .. ' health')
    loseHealth(healthLostWhenGivenWrongMedicine, true);
end

--- Called externally by GridThrowMod
---@param throwableTags Tags
---@param throwingPlayerName string
function onHitByThrowable(throwableTags, throwingPlayerName)
    if throwableTags == nil then
        error('onHitByThrowable with nil throwableTags')
    end
    log:log('Hit by throwable with tags: ' .. tostring(throwableTags))

    if owner.map.getFirstTagged(owner.gridPosition, 'Player') ~= nil then
        -- Hit but being carried by player, so the player was the main thing blocking the throw
        return
    end

    -- Save data - used for conditional narrative text
    local thrownObjNameKey = NarrativeSaveDataKeys.getStringTableKeyForNameOfObjectFromTags(throwableTags)
    game.saveData.setNumber(NarrativeSaveDataKeys.thisRound_didPlayerThrowHitPatient(), 1)
    game.saveData.setString(NarrativeSaveDataKeys.global_mostRecentThrowAndHitPlayer(), throwingPlayerName)
    game.saveData.setString(NarrativeSaveDataKeys.global_mostRecentPatientHittingObject(), thrownObjNameKey)
    if owner.hasFunc('getCharacterName') then
        local characterName = owner.callFunc('getCharacterName')
        game.saveData.setString(NarrativeSaveDataKeys.global_mostRecentHitPatient(), characterName)
    end

    if throwableTags.hasTag('medicine') then
        log:log('Hit by thrown medicine so losing ' .. healthLostWhenHitByMedicine .. ' health')
        loseHealth(healthLostWhenHitByMedicine, true)
    elseif throwableTags.hasTag('patient') then
        log:log('Hit by thrown patient so losing ' .. healthLostWhenHitByPatient .. ' health')
        loseHealth(healthLostWhenHitByPatient, true)
    end

    -- Triggers collision tween animation
    owner.bus.send({
        metadata = { 'objectCollided' },
        data = {
            direction = owner.facing,
        }
    }, false)
end

---@param message Message
local function onMapObjectStateChanged(message)
	if message.data['state.MapObject'] ~= 'Destroyed' then
		return
	end

    if spawnDecalObject ~= nil then
        -- Also destroy related spawn decal when destroying self
        spawnDecalObject.destroyObject()
    end

	destroyed = true
    hideHealthIndicator()
end

local function onGamePhaseChanged(message)
    if destroyed then
        return
    end

    local phase = message.data.gamePhase
    log:log('Game phase: "'.. phase ..'"')

    if phase == 'acting' then
        spawnedThisRound = false
    end

    inPlanningPhase = (phase == 'planning')
    if not inPlanningPhase then
        hideHealthIndicator()
        log:log('acting phase so doing nothing more')
        return
    end

    local isActive = SpawnsInGrid.getActive()
    log:log('isActive:', isActive)
    if not isActive then
        -- countdown
        log:log('numRoundsTillActive: ('.. numRoundsTillActive ..'->'.. numRoundsTillActive - 1 ..')')
        numRoundsTillActive = numRoundsTillActive - 1

        if (numRoundsTillActive <= displaySpawnTimerRounds) and (numRoundsTillActive >= 0) then
            numTurnsTillActive = numRoundsTillActive * turnsPerRound
            -- Display countdown timer
            owner.bus.send({
                metadata = { 'objectCountdown.show' },
                data = {
                    value = numTurnsTillActive,
                    maxValue = displaySpawnTimerRounds * turnsPerRound,
                    positionOffset = { x = 0.0, y = 0.7, z = 0.0 },
                    colour = '#9F5800',
                    icon = 'Icon_Falling',
                    bounce = true,
                    bounceRepeat = 3.75
                }
            }, nil, false)
        end

        if SpawnsInGrid.trySetActive(patientCanBecomeActive, onActive, onVisibleFromActive) then
            log:log('Became active so doing nothing more')
            return
        end

        log:log('Not yet active so doing nothing more')
        return
    end

    -- Only show health loss alert if health is not greater than its starting value
    -- This prevents the alert from showing on patients present at level start (as patients that appear on start get 1 heath added)
    local notifyHealthLoss = health <= healthOnStart
    loseHealth(healthLostOnNewRound, notifyHealthLoss)
end

---@param _ Message
local function onTurnStart(_)
    if destroyed then
        return
    end
    if isActive() then
        return
    end

    numTurnsTillActive = numTurnsTillActive - 1
    if numTurnsTillActive < 0 then
        -- Either this patient spawned, or numTurnsTillActive has not been initialised because
        --  we're not close enough to spawning for the 'turns till active' countdown to be shown
        return
    end
    -- Update 'turns till active' countdown each turn
    owner.bus.send({
        metadata = { 'objectCountdown.show' },
        data = { value = numTurnsTillActive }
    }, nil, false)
end

---@param message Message
local function onThrownButDropped(message)
    local throwingPlayerName = message.data.playerName
    if throwingPlayerName == nil then
        error('No playerName data in landed message')
    end

    local spring = owner.map.getFirstTagged(owner.gridPosition, 'spring')
    if spring ~= nil then
        -- Camera shouldn't follow springing patient
        CameraTargetHelper.disableCameraTargetFor(owner)

        -- Thrown to spring, i.e. thrown out of window!
        -- Try to call springing() on spring object
        if spring.hasFunc('springing') then
            spring.callAction('springing')
        end

        -- Save data - used for conditional narrative text
        game.saveData.setNumber(NarrativeSaveDataKeys.thisRound_didPlayerDefenestratePatient(), 1)
        game.saveData.setString(NarrativeSaveDataKeys.global_mostRecentWindowThrowPlayer(), throwingPlayerName)
        if owner.hasFunc('getCharacterName') then
            local characterName = owner.callFunc('getCharacterName')
            game.saveData.setString(NarrativeSaveDataKeys.global_mostRecentDefenestratedPatient(), characterName)
        end

        -- Dropped on the same tile as a spring, health loss will be handled in onHitSpring instead
        return
    end

    loseHealth(healthLostWhenDropped, true)
end

local function onHitSpring(_)
    SpawnsInGrid.setInactive(onInactive, nil, true)

    -- Reset ready to spawn back at initial position
    numRoundsTillActive = 0

    if SpawnsInGrid.trySetActive(patientCanBecomeActive, onActive, onVisibleFromActive) then
        log:log('Returning back to original spawn pos and losing health after being sprung into the air')
        loseHealth(healthLostWhenSprungFromOutside, true)
    else
        healthToLoseOnActive = healthLostWhenSprungFromOutside
    end
end

---@param _ Message
local function onCarrierSquashed(_)
    beingSquashed = true
    hideHealthIndicator()
end

---@param _ Message
local function onCarrierRespawned(_)
    beingSquashed = false
    if inPlanningPhase then
        showHealthIndicator(true)
    end
end

---@param _ Message
local function onCarrierRespawnedAndVisible(_)
    CameraTargetHelper.enableCameraTargetFor(owner)
end

---@param _ Message
local function onCarrierLaunched(_)
    CameraTargetHelper.disableCameraTargetFor(owner)
end

---@param _ Message
local function onCarried(_)
    everCarried = true
    if blocksThrowWhenStanding ~= 0 then
        -- Might be being picked up from bed, so make sure this patient blocks throws again
        owner.tags.addTag('blocksThrow')
    end

    -- Save data - used for conditional narrative text
    game.saveData.setNumber(NarrativeSaveDataKeys.thisRound_wasPatientPickedUp(), 1)

    -- Unlock achievement! Carry patient
    AchievementsHelper.unlockCarryPatientAchievement()

    local patientCarryCount = game.saveData.getNumber('stat_patientCarryCount')
    patientCarryCount = patientCarryCount + 1
    if patientCarryCount >= 20 then
        -- Unlock achievement! Carry patients 20 times
        AchievementsHelper.unlockCarryPatient20TimesAchievement()
    end
    game.saveData.setNumber('stat_patientCarryCount', patientCarryCount)
end

local function onPlayerActionFailed(message)
    if not SpawnsInGrid.getActive() then
        return
    end
    if message.data.position == nil then
        error('No position data in player.actionFailed message')
    end
    if message.data.direction == nil then
        error('No direction data in player.actionFailed message')
    end
    local actPosition = V2.new(message.data.position) + V2.directionNameToVector(message.data.direction)
    if actPosition ~= V2.new(owner.gridPosition) then
        return
    end

    -- A player had an invalid interaction with this patient!
    local actingPlayer = owner.map.getFirstTagged(message.data.position, 'Player').getFirstComponentTagged('Player')
    local actingPlayerName = actingPlayer.playerName

    log:log('Player ' .. actingPlayerName .. ' had invalid interaction with ' .. tostring(owner))
    owner.bus.send({ metadata = { 'patient.hadInvalidInteraction' }, data = { playerName = actingPlayerName } }, false)
end

---External function called when acting with carried item
function actWhenCarried(carrierOwner, carrier, actDirection)
    assert(nil ~= carrierOwner, 'No carrierOwner')
    assert(nil ~= carrier, 'No carrier')
    assert(nil ~= actDirection, 'No actDirection')

    -- If there is empty floor with nothing blocking us, place the patient down
    if CarryHelper.isSpaceClearInFront(carrierOwner) then
        SoundUtils.playDropPatientSound()

        if CarryHelper.placeDownIfClearInFront(carrierOwner, carrier, actDirection) then
            return true
        end
    end

    -- If carrying and no empty floor, look for a bed or player in the direction the player is facing
    -- Priority goes to beds then players
    local bestAcceptorMapObject
    for acceptorMapObject in carrierOwner.getFacingObjectsTagged('bed or player') do
        log:log('Acceptor:', acceptorMapObject)
        if acceptorMapObject.tags.hasTag('bed') then
            if not acceptorMapObject.hasFunc('getIsVisible') then
                error('No getIsVisible() on bed, so cannot check if patient can be placed there')
            end
            if not acceptorMapObject.hasFunc('canAccept') then
                error('No canAccept() on bed, so cannot check if patient can be placed there')
            end
            if acceptorMapObject.callFunc('getIsVisible') and acceptorMapObject.callFunc('canAccept', owner) then
                -- Bed is visible and will accept us
                -- Play curtain & clipboard sounds before bed transfer
                SoundUtils.playCurtainsSound(1.5)
                SoundUtils.playClipboardSound()

                -- Play sound for patient placed in bed
                SoundUtils.playInBedSound()

                local dropSuccess = CarryHelper.endIntoAcceptorMapObject(carrier, acceptorMapObject)
                if dropSuccess then
                    log:log('Plopped', owner, 'into bed')
                    -- Patients don't block throws when in bed
                    owner.tags.removeTag('blocksThrow')
                    return true
                end
            end
        elseif nil == bestAcceptorMapObject then -- it's a player
            bestAcceptorMapObject = acceptorMapObject
        end
    end

    if nil ~= bestAcceptorMapObject then
        return CarryHelper.endIntoAcceptorMapObject(carrier, bestAcceptorMapObject)
    end

    -- No return value since we're a subscriber
    return false
end

-- MAIN

-- make sure we're tagged 'patient' so Medicine knows to heal us!
-- Tag the MapObject
owner.tags.addTag('patient')

-- Tagging self (component) too.  This allows Medicine Lua to find us later
tags.addTag('patient')

-- Disable as camera target on start, so camera doesn't focus on yet-to-spawn patients
CameraTargetHelper.disableCameraTargetFor(owner)

-- health and appearOnTurn values are based on 4 turns per round, so need to be adjusted for different numbers of turns
turnsPerRound = SaveDataHelper.getSavedTurnsPerRoundOrDefault()
if turnsPerRound > 0 and turnsPerRound < 4 then
    local turnMultiplier = 4 / turnsPerRound
    -- e.g. 2 turns = double the health, and patient spawns after twice as many rounds
    health = health * turnMultiplier
    displaySpawnTimerRounds = displaySpawnTimerRounds * turnMultiplier
    if appearOnTurn > 0 then
        -- appearOnTurn = 0 and appearOnTurn = 1 both mean 'appear on the first turn'
        -- for values >0, convert from 1-based index to 0-based before doubling, then back to 1-based
        appearOnTurn = appearOnTurn - 1
        appearOnTurn = appearOnTurn * turnMultiplier
        appearOnTurn = appearOnTurn + 1
    end
end
healthOnStart = health
healthToCure = healthOnStart + 1

-- If `appearOnTurn` is 0, we are active at start (else we go inactive)
if (0 >= appearOnTurn) then
    -- active at start
    SpawnsInGrid.trySetActive(patientCanBecomeActive, onActive, onVisibleFromActive)
    -- 1 extra health so initial reduction doesn't start us one too few!
    health = health + 1
else
    -- Disabled at start
    log:log('Disabled at start since '.. appearOnTurn ..' turns until active')
    SpawnsInGrid.setInactive(onInactive, nil, true)
end

spawnDecalObject = owner.map.getFirstTagged(owner.gridPosition, 'patientSpawnDecal')

log:log('Patient ' ..tostring(owner).. ' has ' ..health.. ' health and needs ' ..need.. ' and '.. (SpawnsInGrid.getActive() and 'is active' or 'is not yet active'))

-- subscribe to get informed when game rounds start
game.bus.subscribe('gamePhase', onGamePhaseChanged)
game.bus.subscribe('turnStart', onTurnStart)
game.bus.subscribe('player.actionFailed', onPlayerActionFailed)
owner.bus.subscribe('landed', onThrownButDropped)
owner.bus.subscribe('spring', onHitSpring)
owner.bus.subscribe('state.MapObject', onMapObjectStateChanged)
owner.bus.subscribe('carrier.squashed', onCarrierSquashed)
owner.bus.subscribe('carrier.respawned', onCarrierRespawned)
owner.bus.subscribe('carrier.respawnedAndVisible', onCarrierRespawnedAndVisible)
owner.bus.subscribe('carrier.launched', onCarrierLaunched)
owner.bus.subscribe('carried', onCarried)
