---@type AchievementsHelper
local AchievementsHelper = require('AchievementsHelper')
---@type SoundUtils
local SoundUtils = require('SoundUtils')

---Called externally when springing a patient into the air
---Externally called.
function springing()
    -- View plays bounce animation on receiving springing msg
    owner.bus.send({'springing'}, nil, false)
    SoundUtils.playSpringSound()

    -- Unlock achievement! Something was thrown through a window to trigger the spring
    AchievementsHelper.unlockDefenestrateAchievement()
end

function hitWithoutSpringing()
    -- Unlock achievement! Something was thrown through a window to hit the spring
    AchievementsHelper.unlockDefenestrateAchievement()
end