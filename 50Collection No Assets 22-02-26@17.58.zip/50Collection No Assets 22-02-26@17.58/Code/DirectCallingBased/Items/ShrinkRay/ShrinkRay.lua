-- Shrinks things tagged as 'shrinkable' in adjacent tiles when acted with

---@type Game
local game = LoadFacility('Game')['game']
---@type MapMobile
local owner = owner or error('No owner')

---@type AchievementsHelper
local AchievementsHelper = require('AchievementsHelper')
---@type CarryHelper
local CarryHelper = require('CarryHelper')
---@type ShrinkUtils
local ShrinkUtils = require('ShrinkUtils')
---@type NarrativeSaveDataKeys
local NarrativeSaveDataKeys = require('NarrativeSaveDataKeys')
---@type SoundUtils
local SoundUtils = require('SoundUtils')

--- Number of uses before the device is destroyed
---@type number
local charge = charge or 1

---@return MapObject[]
local function getValidShrinkableObjectsInFront()
    local validShrinkables = {}
    local shrinkableObjsInFront = owner.getFacingObjectsTagged('shrinkable')
    for shrinkable in shrinkableObjsInFront do
        if ShrinkUtils.objectCanBeShrunk(shrinkable) then
            table.insert(validShrinkables, shrinkable)
        end
    end
    return validShrinkables
end

---@param shrinkables MapObject[]
local function shrinkValidShrinkableObjects(shrinkables)
    for shrinkableObj in shrinkables do
        if not shrinkableObj.callFunc('shrink') then
            error('Expected shrink() to return true but got false on ' .. tostring(shrinkableObj))
        end
    end
end

---External function called when acting with carried item
function actWhenCarried(carrierOwner, carrier, actDirection)
    assert(nil ~= carrierOwner, 'No carrierOwner')
    assert(nil ~= carrier, 'No carrier')
    assert(nil ~= actDirection, 'No actDirection')

    -- If there is empty floor with nothing blocking us, drop the device
    if CarryHelper.placeDownIfClearInFront(carrierOwner, carrier, actDirection) then
        -- Destroyed when dropped on the ground
        owner.destroyObject()
        return true
    end

    -- Get all objects that can currently be shrunk
    local validShrinkables = getValidShrinkableObjectsInFront()
    local shrinkSuccess = false
    if #validShrinkables > 0 then
        -- One or more things can be shrunk in front of the owner
        -- Play sound effect
        SoundUtils.playShrinkProdZapSound()
        -- Show the shrinking 'zap' visual effect
        owner.bus.send({ 'shrinkRay.zap' }, nil, false)
        -- Actually do the shrinking by calling shrink() on all valid shrinkables
        shrinkValidShrinkableObjects(validShrinkables)

        -- Save data - used for conditional narrative text
        game.saveData.setNumber(NarrativeSaveDataKeys.thisRound_wasAnyObjectShrunk(), 1)

        -- Unlock achievement! Shrink something
        AchievementsHelper.unlockShrinkSomethingAchievement()

        shrinkSuccess = true
    end

    charge = charge - 1
    if charge <= 0 then
        -- Destroy if all charges were used
        owner.bus.send({ 'shrinkRay.chargeDead' }, nil, false)
        owner.destroyObject()
    end

    -- True if at least one object was shrunk
    return shrinkSuccess
end

---Sibling (dispenser) shrunk
---@param _ Message
local function onSiblingShrunk(_)
    owner.bus.send({ 'shrinkRay.destroyedWithSibling' }, nil, false)
    owner.destroyObject()
end

owner.tags.addTag('shrinkRay')

owner.bus.subscribe('sibling.shrunk', onSiblingShrunk)
