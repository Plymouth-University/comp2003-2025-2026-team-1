---Automatically restocks to the expected number of items.
---Set `items` to the list of items (objectDefinition entries) to create.

local Log = require('Log')
---Default to normal 'log' level unless
local logLevel = --[[---@type number]] (logLevel or Log.LevelLog)
local log = Log.new(logLevel)
log:debug("Dispenser loaded")

---@type MapMobile
local owner = owner or error('No owner')

---@type Game
local game = LoadFacility('Game')['game'] or error('No game')

---@type Loader
local loader = game.loader or error('No loader')

---Names of items to dispense (e.g. 'pill1_e', 'pill2_e', 'pill3_e')
---Dispenses more than one type to position correctly.
---The values supplied should be names of items as defined in the Level Map's `objectDefinitions` section.
---@type string[]
local items = items or {'pill1_e', 'pill2_e', 'pill3_e'}

---@type number
local spawnItemsOnStart = spawnItemsOnStart or 1

---@type number
local displayHealthIndicator = displayHealthIndicator or 0
---@type Vector3
local healthIndicatorOffset = healthIndicatorOffset or { x = 0, y = 0, z = 0 }
---@type boolean
local displayingHealthIndicator = false

---Map of prefab id (instance number) instantiated to item name requested.
---Built as items are first created.
---Used to determine which items are removed (thus need replacing) after sibling removal.
---@type table<number, string>
local prefabToNameMap = {}

---@type boolean
local shouldDispense = true

---Create a new item at own position as described by an entry in the `objectDefinitions`.
---@param item string
---@param growItem boolean|nil
---@param awaitGrow boolean|nil
---@return MapMobile @ The `MapMobile` created or nil if problems.
local function dispenseItem(item, growItem, awaitGrow)
	log:debug('Attempting to create ', item, ' at ', owner.gridPosition)
	local newInstance = --[[---@type MapMobile]] loader.instantiate(item, owner.gridPosition)
	-- Record the instance id so we can map it back to the item name when removed.
	prefabToNameMap[newInstance.id] = item
	if growItem then
		newInstance.bus.send({ visible = false }, nil, false)
		newInstance.bus.send({ visible = true }, nil, false)
		newInstance.bus.send({ (awaitGrow and 'growFromNothing' or 'growFromNothingNoAwait') }, nil, false)
	end
	log:debug('Created ', newInstance, ' (mapped "', newInstance.id, '" to "', item, '")')
	return newInstance
end

---If this dispenser gives medicine, displays the amount of health that medicine will restore
local function tryDisplayHealthIndicator()
	if displayingHealthIndicator then
		return
	end
	local dispensedMedicine = owner.map.getFirstTagged(owner.gridPosition, 'medicine')
	if dispensedMedicine == nil then
		return
	end
	if not dispensedMedicine.hasFunc('getHealthIncrease') then
		error('No getHealthIncrease() on medicine')
	end
	local healthIncreaseVal = dispensedMedicine.callFunc('getHealthIncrease')

	displayingHealthIndicator = true
	owner.bus.send({
		metadata = { 'objectCountdown.show' },
		data = {
			displayType = "health",
			colour = "#788B07",
			value = '+' .. tostring(healthIncreaseVal),
			positionOffset = {
				x = healthIndicatorOffset.x,
				y = healthIndicatorOffset.y,
				z = healthIndicatorOffset.z
			},
		}
	}, nil, false)
end

local function tryHideHealthIndicator()
	if not displayingHealthIndicator then
		return
	end
	displayingHealthIndicator = false
	owner.bus.send({ 'objectCountdown.hide' }, nil, false)
end

---@param growItems boolean|nil
local function addAllItems(growItems)
	log:debug('Adding all items:', items)
	---@type number
	local i = 0
	for itemNum, name in ipairs(items) do
		i = i + 1
		log:debug('Creating #', i, ': ', name)
		dispenseItem(name, growItems, (itemNum >= #items))
	end
	log:debug('Created ', i, ' items')

	if displayHealthIndicator ~= 0 then
		tryDisplayHealthIndicator()
	end
end

---@param id number
local function addMissingItem(id)
	log:debug('Trying to dispense replacement for removed item id:', id)
	local missingItem = prefabToNameMap[id]
	if not missingItem then
		log:warn('No item found for missing id:', id, ' amongst:', prefabToNameMap, ', items:', items, '.\n<color=red>Could there have been other carryable items in same square?</color>')
		return
	end
	log:log('Dispensing replacement for removed item id:', id, ' = ', missingItem)
	local dispensed = dispenseItem(missingItem, true, false)
	log:debug('Created:', dispensed)
end

local function onGamePhase(msg)
	local phase = msg.data.gamePhase;
	log:debug('Game phase: "', phase, '"')

	if displayHealthIndicator ~= 0 then
		if phase == 'management' or phase == 'managementResults' then
			tryHideHealthIndicator()
		elseif shouldDispense and not displayingHealthIndicator then
			tryDisplayHealthIndicator()
		end
	end

	if phase == 'finished' then
		---Record when level finished to know not to respawn things any longer.
		log:debug('Level finished:', json.serialize(msg))
		shouldDispense = false
	end
end

---When a sibling is removed, instantiate a new one.
---@param msg Message
local function onSiblingRemoved(msg)
	if not shouldDispense then
		log:debug('Not presently dispensing so ignoring sibling removal.')
		return
	end

	log:debug('Sibling removed:', json.serialize(msg))
	local removedId = msg.data['siblingRemoved']
	-- TODO: Consider stashing the id and *actually* adding at turn end (and animate them in)
	addMissingItem(removedId)
end


---Record when destroyed to know not to respawn things any longer.
local function onDestroyed(msg)
	log:debug('Dispenser destroyed:', json.serialize(msg))
	shouldDispense = false
end

--- Shrunk by a Shrink Ray
---@param _ Message
---@return void
local function onShrunk(_)
	-- Don't dispense anything when shrunk
	shouldDispense = false
	if displayHealthIndicator ~= 0 then
		tryHideHealthIndicator()
	end
end

---@param _ Message
---@return void
local function onGrownFromShrunk(_)
	-- Back to normal unshrunk state, restore items
	shouldDispense = true
	addAllItems(true)
end

---@param _ Message
local function onSpawnedAsBoughtItem(_)
	if spawnItemsOnStart == 0 then
		addAllItems(true)
	end
end

owner.tags.addTag('dispenser')

game.bus.subscribe('gamePhase', onGamePhase)
owner.bus.subscribe('siblingRemoved', onSiblingRemoved)
owner.bus.subscribe('state.MapObject', onDestroyed)
owner.bus.subscribe('shrinkable.shrink', onShrunk)
owner.bus.subscribe('shrinkable.growDone', onGrownFromShrunk)
owner.bus.subscribe('spawnedAsBoughtItem', onSpawnedAsBoughtItem)

if spawnItemsOnStart > 0 then
	addAllItems()
end
