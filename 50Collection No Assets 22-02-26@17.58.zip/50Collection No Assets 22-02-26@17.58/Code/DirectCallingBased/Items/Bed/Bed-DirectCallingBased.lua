-- CoOperation Bed mod
-- Bring in the ability to subscribe to the GameManager's message bus for game phase changes
---@type Game
local game = LoadFacility('Game')['game']
---@type MapObject
local owner = owner or error('No owner')

local Log = require('Log')
local log = Log.new()

---@type Loader
local loader = game.loader or error('No loader')

---@type MessageHelpers
local MessageHelpers = require('MessageHelpers')
---@type CameraTargetHelper
local CameraTargetHelper = require('CameraTargetHelper')
---@type SoundUtils
local SoundUtils = require('SoundUtils')

---@type number
local spawnClipboards = spawnClipboards or 1

---@type string
local acceptsPatientTagged = acceptsPatientTagged or "adultPatient"

---@type number
local rewardMultiplier = rewardMultiplier or 1

---@type boolean
local clipboardShowing = false

---@type boolean
local isVisible = true

-- Called externally to check if the bed is visible
---@return boolean
function getIsVisible()
    return isVisible
end

---@return number
function getRewardMultiplier()
    return rewardMultiplier
end

---@return MapObject|nil
local function getPatientInBed()
    -- Returns first active patient in the same tile as this bed (or nil)
    local patients = owner.map.getAllTagged(owner.gridPosition, 'Patient')
    for patient in patients do
        if patient['isActive']() then --TODO: Switch to patient.callFunc('isActive')
            return patient
        end
    end
    return nil
end

--- Called externally by CarryHelper.endIntoAcceptorMapObject
--- to check if a MapObject can be placed into this bed
---@return boolean
---@param mapObject MapObject
function canAccept(mapObject)
    local patientInBed = getPatientInBed()
    if patientInBed ~= nil and patientInBed ~= mapObject then
        -- Already another active patient in this bed
        return false
    end
    if not mapObject.tags.hasTag('patient') then
        -- Beds only accept patients
        return false
    end
    return mapObject.tags.hasTag(acceptsPatientTagged)
end

local function destroyAllClipboards()
    local clipboards = owner.map.getAllTagged(owner.gridPosition, 'Clipboard')
    for clipboard in clipboards do
        clipboard.destroyObject()
    end
end

---@param patientAdded boolean
local function updateClipboards(patientAdded)
    if patientAdded and clipboardShowing then
        -- Clipboard already being shown for patient
        return
    end

    clipboardShowing = false

    -- Destroy any existing clipboards before adding new one
    destroyAllClipboards()

    if spawnClipboards == 0 then
        -- Clipboards disabled for this bed
        return
    end

    if not patientAdded then
        -- No patient, no clipboard needed
        return
    end

    local patientInBed = getPatientInBed()
    if patientInBed ~= nil then
        -- Patient in bed, add a clipboard showing their needed medicine type
        local patientNeed = patientInBed['getNeed']()
        local clipboardObjName = 'ui_' .. patientNeed;
        if loader.hasObject(clipboardObjName) then
            local newClipboard = loader.instantiate(clipboardObjName, owner.gridPosition)
            newClipboard['setVisible'](true)
            clipboardShowing = true
        end
        --TODO: Switch above 3 lines to:
        --local patientNeed = patientInBed.callFunc('getNeed')
        --local newClipboard = loader.instantiate('ui_' .. patientNeed, owner.gridPosition)
        --newClipboard.callAction('setVisible', true)
    end
end

---@param _ Message
local function onUpdateClipboards(_)
    updateClipboards(true)
end

---@param newVisible boolean
local function setVisible(newVisible)
    if not newVisible then
        CameraTargetHelper.disableCameraTargetFor(owner)
    end

    log:debug('Bed set visible:', newVisible)
    owner.bus.send({visible = newVisible}, nil, false)
    isVisible = newVisible

    if newVisible then
        CameraTargetHelper.enableCameraTargetFor(owner)
    end
end

-- Called externally by Shrinkable to check if this object can be shrunk
---@return boolean
function canBeShrunk()
    -- Beds can only be shrunk when not occupied
    return getPatientInBed() == nil
end

---@param message Message
local function onSiblingAdded(message)
    local addedObj = MessageHelpers.getMapObjectViaIdFromMessage(message, 'siblingAdded')
    if addedObj.tags.hasTag('patient') then
        if not addedObj.hasFunc('isActive') then
            error('No isActive() on MapObject tagged as \'patient\'')
        end
        if not addedObj.callFunc('isActive') then
            -- Don't care about inactive patients
            return
        end
        -- Patient added to the same tile as this bed
        local player = owner.map.getFirstTagged(owner.gridPosition, 'player')
        if player ~= nil then
            -- Patient is with player, not in bed
            return
        end
        log:debug('Bed patient added - updating clipboards')
        updateClipboards(true)
    end
end

---@param message Message
local function onSiblingRemoved(message)
    local patientInBed = getPatientInBed()
    if patientInBed ~= nil then
        -- The object that was removed wasn't the patient in this bed, so we're not interested
        return
    end
    -- Patient was removed from bed, also destroy clipboard
    if clipboardShowing then
        log:debug('Bed sibling removed - updating clipboards')
        updateClipboards(false)
    end
end

---@param _ Message
local function onPatientInBedCureStart(_)
    updateClipboards(false)
end

---@param _ Message
local function onPatientDestroyedAfterCure(_)
    setVisible(false)
    SoundUtils.playBedSpawnSound()
    setVisible(true)
end

owner.bus.subscribe('patientCureStart', onPatientInBedCureStart)
owner.bus.subscribe('patientDestroyedAfterCure', onPatientDestroyedAfterCure)
owner.bus.subscribe('siblingAdded', onSiblingAdded)
owner.bus.subscribe('siblingRemoved', onSiblingRemoved)
owner.bus.subscribe('updateClipboards', onUpdateClipboards)
