-- CoOperation Clipboard mod

local Log = require('Log')
local log = Log.new()

---@type MapObject
local owner = owner or error('No owner')
---@type Game
local game = LoadFacility('Game')['game']

---@type boolean
local isVisible = true

---@type boolean
local isBouncing = false
---@type boolean
local registeredBounceEvent = false

---Set the visibility of this clipboard.
---Externally called.
---@param newVisible boolean
function setVisible(newVisible)
    if isVisible == newVisible then
        return
    end

    isVisible = newVisible
    log:debug('Clipboard set visible: ', newVisible)
    owner.bus.send({visible = newVisible}, nil, false)
end

---Externally called.
function wrongMedicineAdministered()
    if isVisible then
        owner.bus.send({'highlightWrongMedicine'}, false) -- Do not require receiver since not present without View
    end
end

local function onRelatedMedicineBouncing(_)
    if isBouncing then
        return
    end
    isBouncing = true
    owner.bus.send({ 'clipboard.bounce' }, nil, false)
    isBouncing = false
end

local function onGamePhaseChanged(message)
    local gamePhase = message.data.gamePhase
    if gamePhase ~= 'planning' then
        owner.bus.send({ 'clipboard.idle' }, nil, false)
    end

    if not registeredBounceEvent then
        -- Get the medicine type displayed on this billboard from the patient on the same tile
        local patientInTile = owner.map.getFirstTagged(owner.gridPosition, 'patient')
        if patientInTile == nil then
           return
        end
        local medicineType = patientInTile.callFunc('getNeed')

        -- Listen for when medicine that matches the type displayed on
        -- this clipboard is bouncing, so we can bounce at the same time
        game.bus.subscribe('medicine_' .. medicineType .. '.bouncing', onRelatedMedicineBouncing)
        registeredBounceEvent = true
    end
end

owner.tags.addTag('Clipboard')

setVisible(false)

game.bus.subscribe('gamePhase', onGamePhaseChanged)
