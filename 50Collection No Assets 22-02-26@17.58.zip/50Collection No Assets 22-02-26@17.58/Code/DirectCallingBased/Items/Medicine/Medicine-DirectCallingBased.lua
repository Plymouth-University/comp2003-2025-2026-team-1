---Medicine mod.
---Handles administering medicine to a patient in the direction that the player is facing

local Log = require('Log')
local log = Log.new()

-- Bring in the ability to use the GameManager's message bus
---@type MapMobile
local owner = owner or error('No owner')
---@type Game
local game = LoadFacility('Game')['game']

---@type CarryHelper
local CarryHelper = require('CarryHelper')
---@type NarrativeSaveDataKeys
local NarrativeSaveDataKeys = require('NarrativeSaveDataKeys')
---@type SaveDataHelper
local SaveDataHelper = require('SaveDataHelper')
---@type CameraTargetHelper
local CameraTargetHelper = require('CameraTargetHelper')
---@type SoundUtils
local SoundUtils = require('SoundUtils')

-- Set-up the remedy if not supplied by JSON data
---@type string
local remedy = remedy or 'pill'

---@type boolean
local sentBounceSinceIdle = false

--- How much (base) health a patient gains when cured with this medicine
---@type number
local healthIncrease = healthIncrease or 4

---@type boolean
local cameraTargetEnabledFirstTime = false

---@type boolean
local destroyed = false

--- Called externally by DispenseAutomatically when displaying medicine power
---@return number
function getHealthIncrease()
    return healthIncrease
end

---@param administeringPlayerObj MapObject
---@param administeringPlayerComponent CoOpActor
---@param patientMapObject MapMobile | MapObject
---@return boolean
local function applyRemedyTo(administeringPlayerObj, administeringPlayerComponent, patientMapObject)
    -- Call directly or get the component tagged 'patient' then directly call 'canAdministerRemedy'
    local patient = --[[---@type Mod]] patientMapObject.getFirstComponentTagged('patient')
    if nil == patient then
        log:log('No patient on patient')
        return false
    end

    -- Don't try administering if the patient isn't in bed
    local bedAtPatientPos = owner.map.getFirstTagged(patientMapObject.gridPosition, 'Bed')
    if nil == bedAtPatientPos then
        log:debug('Applying remedy, but patient is not in bed')
        return false
    end

    -- 1. IDEAL but DOES NOT _YET_ WORK (might with future Lua runtime modifications)
    -- local result = patient.canAdministerRemedy(remedy)

    -- 2. What we started with = works but leaks abstractions like a sieve
    local canAdminister = patient.callFunc('canAdministerRemedy', remedy)

    -- 3. works and looks a little wonky -- disabled 2023/11
    --local canAdminister = patient['canAdministerRemedy'](remedy)

    -- 4. Also works which is quite nice. N.b. MapObject rather than Component
    -- local result = patientMapObject['canAdministerRemedy'](remedy)

    log:log('trying to administer ' .. remedy .. ' resulted in', json.serialize(canAdminister))
    if canAdminister and canAdminister.result == 'success' then
        -- TODO: Be consumed! (or could have multiple uses by keeping local count)
        local ownerPos = owner.gridPosition;
        if ownerPos == nil then
            error('B0038: nil ownerPos when about to call cure() on patient: ' .. tostring(patient))
        end

        -- Play sound for successful medicine administration
        SoundUtils.playHealingSound(remedy)

        setAutoAwait(false)
        -- Shrink to nothing animation happens during the administering, hence not destroying first
        owner.bus.send({
            metadata = { 'applyItemWithJump' },
            data = { direction = owner.facing }
        }, nil, false)
        if administeringPlayerObj ~= nil then
            administeringPlayerObj.bus.send({ 'player.stopCarryingWhileActing' }, nil, false)
        end
        setAutoAwait(true)

        -- Actually adminiter to patient!
        patient.callAction('administerRemedy', ownerPos, healthIncrease)
        -- Destroy unless already destroyed due to e.g. next level loading on cure
        if (not destroyed) and (owner ~= nil) then
            owner.destroyObject()
            log:log('I was successfully applied and was consumed')
        end
        return true
    else
        log:log('I was not the right thing to apply here')

        SoundUtils.playInvalidActionSound()

        owner.bus.send({ 'shrinkToNothing' }, nil, false)
        setAutoAwait(false)
        if administeringPlayerObj ~= nil then
            administeringPlayerObj.bus.send({ 'player.stopCarryingWhileActing' }, nil, false)
        end
        setAutoAwait(true)

        -- Notify clipboards on the same tile as the patient that wrong medicine was given
        local clipboards = owner.map.getAllTagged(patientMapObject.gridPosition, 'Clipboard')
        for clipboard in clipboards do
            clipboard.callAction('wrongMedicineAdministered')
        end

        patient.callAction('givenWrongRemedy')

        -- Save data - used for conditional narrative text
        game.saveData.setNumber(NarrativeSaveDataKeys.thisRound_didPlayerAdministerWrong(), 1)
        if administeringPlayerComponent ~= nil then
            game.saveData.setString(NarrativeSaveDataKeys.global_mostRecentAdministerWrongPlayer(), administeringPlayerComponent.playerName)
        end
        if patientMapObject ~= nil and patientMapObject.hasFunc('getCharacterName') then
            local patientCharacterName = patientMapObject.callFunc('getCharacterName')
            game.saveData.setString(NarrativeSaveDataKeys.global_mostRecentAdministerWrongPatient(), patientCharacterName)
        end

        -- Administered wrongly, but the medicine was still used! So destroy
        owner.destroyObject()

        return false
    end
end

---@param administeringPlayerObj MapObject
---@param administeringPlayerComponent CoOpActor
local function administer(administeringPlayerObj, administeringPlayerComponent)
    -- Try administering to first active patient in facing tile
    local patientsInFacingDir = owner.getFacingObjectsTagged('patient')
    for patient in patientsInFacingDir do
        if patient ~= nil and patient.hasFunc('isActive') and patient.callFunc('isActive') then
            applyRemedyTo(administeringPlayerObj, administeringPlayerComponent, patient)
            -- It may or may not have been the correct remedy,
            --  but we return true because something was administered
            return true
        end
    end
    return false
end

---External function called when acting with carried item
function actWhenCarried(carrierOwner, carrier, actDirection)
    assert(nil ~= carrierOwner, 'No carrierOwner')
    assert(nil ~= carrier, 'No carrier')
    assert(nil ~= actDirection, 'No actDirection')

    local playerComponent = carrierOwner.getFirstComponentTagged('Player')
    assert(playerComponent ~= nil, 'No Player component on player owner MapObject')

    -- First check if space is clear
    if CarryHelper.isSpaceClearInFront(carrierOwner) then
        -- Play sound for dropped medicine based on type
        if remedy == 'pill' then
            SoundUtils.playDropPillsSound()
            -- Smashed pills!
            -- Save data - used for conditional narrative text
            game.saveData.setNumber(NarrativeSaveDataKeys.thisRound_didPlayerDropPills(), 1)
            game.saveData.setString(NarrativeSaveDataKeys.global_mostRecentPillDropPlayer(), playerComponent.playerName)
            game.saveData.save()
        elseif remedy == 'syringe' then
            SoundUtils.playDropSyringeSound()
        elseif remedy == 'apple' then
            SoundUtils.playDropAppleSound()
        end

        -- Now actually place the medicine
        if CarryHelper.placeDownIfClearInFront(carrierOwner, carrier, actDirection) then
            -- Medicine is destroyed when dropped on the ground
            owner.destroyObject()
            return true
        end
    end

    -- If carrying and no empty floor, look for a player to pass this medicine to
    local possibleReceivingPlayer = carrierOwner.getFirstFacingObjectTagged('player')
    if possibleReceivingPlayer ~= nil then
        return CarryHelper.endIntoAcceptorMapObject(carrier, possibleReceivingPlayer)
    end

    -- No empty floor or could not put down, and no player to pass to - try administering this medicine
    return administer(carrierOwner, playerComponent)
end

local function ensureEnabledAsCameraTarget()
    if not cameraTargetEnabledFirstTime then
        CameraTargetHelper.enableCameraTargetFor(owner)
        cameraTargetEnabledFirstTime = true
    end
end

---@param message Message
local function onRequiredMedicineForRound(message)
    -- We've received a message with all of the medicine types that are needed by patients in bed this round.
    -- If this medicine type is required, start bouncing to let players know!
    if message.data.requiredMedicineForRound[remedy] then
        if sentBounceSinceIdle then
            -- Don't send multiple bounce messages per round
            return
        end
        sentBounceSinceIdle = true
        owner.bus.send({ 'medicine.bounce' }, nil, false)
    else
        owner.bus.send({ 'medicine.idle' }, nil, false)
    end
end

---@param message Message
local function onGamePhaseChanged(message)
    if destroyed then
        return
    end
    local gamePhase = message.data.gamePhase

    if gamePhase == 'finished' then
        -- Consider medicine destroyed once level is finished,
        -- to ensure it doesn't try to destroy self when next level loads after curing
        destroyed = true
        return
	end

    if gamePhase ~= 'planning' then
        -- Reset to idle animation in all phases other than planning
        owner.bus.send({ 'medicine.idle' }, nil, false)
        sentBounceSinceIdle = false
    end
    ensureEnabledAsCameraTarget()
end

---@param _ Message
local function onTurnStart(_)
    if destroyed then
        return
    end
    ensureEnabledAsCameraTarget()
end

---@param message Message
local function onMapObjectStateChanged(message)
	if message.data['state.MapObject'] == 'Destroyed' then
        destroyed = true
	end
end

---Shrunk by a Shrink Ray
---@param _ Message
local function onSiblingShrunk(_)
    -- Medicine breaks/is destroyed when a sibling (dispenser) shrinks
    owner.bus.send({ 'medicine.smashed' }, nil, false)
    owner.destroyObject()
end

---@param _ Message
local function onBouncing(_)
    -- I'm bouncing! Send msg on game bus (including our remedy type) so related clipboards can listen and start bouncing too
    game.bus.send({ 'medicine_' .. remedy .. '.bouncing' }, nil, false)
end

owner.bus.send({ 'medicine.idle' }, nil, false)

local turnsPerRound = SaveDataHelper.getSavedTurnsPerRoundOrDefault()
if turnsPerRound > 0 and turnsPerRound < 4 then
    -- Fewer than 4 turns per round = patients have a higher starting health, so medicine needs greater healing power
    -- e.g. for 1 turn per round, medicine increases health by 4x its default amount
    local turnMultiplier = 4 / turnsPerRound
    healthIncrease = healthIncrease * turnMultiplier
end

-- MAIN

owner.tags.addTag('medicine')

-- Disable this object as a camera target on start, so that falling medicine doesn't get camera focus
CameraTargetHelper.disableCameraTargetFor(owner)

-- subscribe to get informed when game rounds start
game.bus.subscribe('gamePhase', onGamePhaseChanged)
game.bus.subscribe('turnStart', onTurnStart)
game.bus.subscribe('requiredMedicineForRound', onRequiredMedicineForRound)
owner.bus.subscribe('state.MapObject', onMapObjectStateChanged)
owner.bus.subscribe('sibling.shrunk', onSiblingShrunk)
owner.bus.subscribe('medicine.bouncing', onBouncing)
