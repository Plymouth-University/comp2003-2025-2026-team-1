---@type Game
local game = LoadFacility('Game')['game']

---@type string
local tickerText
if game.levelNumber == 1 then
    tickerText = 'levelTicker_level1'
elseif game.levelNumber == 2 then
    tickerText = 'levelTicker_level2'
elseif game.levelNumber == 3 then
    tickerText = 'levelTicker_level3'
elseif game.levelNumber == 4 then
    tickerText = 'levelTicker_level4'
elseif game.levelNumber == 5 then
    tickerText = 'levelTicker_level5'
elseif game.levelNumber == 6 then
    tickerText = 'levelTicker_level6'
elseif game.levelNumber == 7 then
    tickerText = 'levelTicker_level7'
elseif game.levelNumber == 8 then
    tickerText = 'levelTicker_level8'
elseif game.levelNumber == 9 then
    tickerText = 'levelTicker_level9'
elseif game.levelNumber == 10 then
    tickerText = 'levelTicker_level10'
elseif game.levelNumber == 11 then
    tickerText = 'levelTicker_level11'
elseif game.levelNumber == 12 then
    tickerText = 'levelTicker_level12'
elseif game.levelNumber == 13 then
    tickerText = 'levelTicker_level13'
elseif game.levelNumber == 14 then
    tickerText = 'levelTicker_level14'
elseif game.levelNumber == 15 then
    tickerText = 'levelTicker_level15'
elseif game.levelNumber == game.totalNumberOfLevels then
    -- Shop/results level
    tickerText = 'levelTicker_shop'
else
    tickerText = ''
end

game.bus.send({
    displayText = tickerText,
    displayType = 'ticker'
}, nil, false)
