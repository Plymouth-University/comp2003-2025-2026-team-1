﻿---A coin in a shop with a denomination that, when applied to a ShopItem pays some of its value.

local FieldHelper = require('FieldHelper')
local CarryHelper = require('CarryHelper')

local Log = require('Log')
local log = Log.new()

---@type Game
local game = LoadFacility('Game')['game']
---@type MapMobile
local owner = owner or error('No owner')

---@type SoundUtils
local SoundUtils = require('SoundUtils')

---@type number
local value = value or 5
log:debug('Coin of value:', value, ' created')

---Whether the coin has been used (paid with).
---@type boolean
local used = false

---Tries to pay a 'payable' ShopItem via its `pay()` using own value
---@param carrierOwner MapObject @ MapObject (player) holding this coin when paying.
---@return boolean @ Whether successfully paid (not whether thing fully bought).
local function tryPay(carrierOwner)
	local payableObjects = owner.getFacingObjectsTagged('payable')
	if nil == payableObjects then
		log:log('No payable(s) in-front of us')
		return false
	end

	for payableObject in payableObjects do
		if nil ~= payableObject then
			if not payableObject.hasFunc('pay') then
				error('Payable object has no `pay` function exposed! ' .. tostring(payableObject))
			end

			if payableObject.hasFunc('isDisplaying') and (payableObject.callFunc('isDisplaying')) then
				-- (so we don't return the money when destroyed)
				used = true

				setAutoAwait(false)
				carrierOwner.bus.send({ 'player.stopCarryingWhileActing' }, nil, false)
				setAutoAwait(true)

				log:debug('Paying ', value, ' money to ', payableObject)
				-- Success here indicates whether fully bought (true) or not (false)
				local success = payableObject.callFunc('pay', value, owner)
				log:log('Paying result:', success)

				-- Destroy once used
				owner.destroyObject()
				-- Coin was used to pay! So return true regardless of whether the thing was fully bought
				return true
			else
				log:log('payable is not being displayed: ' .. tostring(payableObject))
			end
		end
	end

	return false
end

---@param msg Message
local function onStateChange(msg)
	if used then
		-- Money already paid with so don't return it to the balance
		return
	end

	local newState = msg.data['state.MapObject']
	log:debug('new state:', newState)
	if 2 == newState or 'Destroyed' == newState then
		log:debug('destroyed so returning ', value, ' money')
		-- Return without persisting change so money only exists in-world (doesn't get lost if level/game quit).
		-- ATM dispensing behaviour same.  Only persisted when purchases complete.
		FieldHelper.callFuncOnFirstMapObjectTagged('ShopMoneyManager', 'payIn', value, false)
	end
end

-- When a coin is picked up, CarryHelper destroys the original coin before creating a clone with an adjusted art3d position
---@param _ Message
local function onDestroyingBeforeCloning(_)
	-- Mark as used, so the value of this coin won't be paid in when cloning
	used = true
end

---External function called when acting with carried item
function actWhenCarried(carrierOwner, carrier, actDirection)
	assert(nil ~= carrierOwner, 'No carrierOwner')
	assert(nil ~= carrier, 'No carrier')
	assert(nil ~= actDirection, 'No actDirection')

	-- If there is empty floor with nothing blocking us, drop the coin
	if CarryHelper.isSpaceClearInFront(carrierOwner) then
		-- Play sound for dropped coin
		SoundUtils.playCoinSound()

		if CarryHelper.placeDownIfClearInFront(carrierOwner, carrier, actDirection) then
			-- Coins return to balance when dropped on the ground
			log:debug('Placed down = money will be returned by onStateChange (not returning ', value, ' to balance now)')
			-- No need to destroy since tagged "destroyIfPutDown"
			-- No need to return money to balance since we'll do it in state change event handler
			return true -- TODO-20230701 will this also disappear on drop and how do we return money?
		end
	end

	-- There's no empty floor or could not put down, try administering the medicine instead
	return tryPay(carrierOwner)
end

---External function called to assign new value to the coin.
---Temporary until API allows providing variables during instantiation. = TODO-20230724
function setValue(newValue)
	value = newValue
	log:debug('value set to ', value)
end

owner.bus.subscribe('state.MapObject', onStateChange)
owner.bus.subscribe('destroyingBeforeCloning', onDestroyingBeforeCloning)
