﻿---Something that either has been bought or could yet be bought in the shop.
---This code is responsible for:
---* knowing whether this item has been bought,
---* hiding/showing itself in the levels where it is present,
---* answering others' queries as to whether it has been bought.
---@type Game
local game = LoadFacility('Game')['game']

local Log = require('Log')
local log = Log.new()

---@type TableUtils
local TableUtils = require('TableUtils')
---@type SoundUtils
local SoundUtils = require('SoundUtils')

---@type MapMobile
local owner = owner or error('No owner?!')
---@type Pos
local spawnPosition = spawnPosition or owner.gridPosition
---@type boolean
local isActive = false
---@type string
local boughtItem = boughtItem or error("Buyable MUST HAVE a 'boughtItem' supplied as data")

---@type string
local linkObjectsTagged = linkObjectsTagged or ''

---@type number
local displayPriority = displayPriority or 0

---Whether to toggle the visibility on purchase so they might bounce in.
local toggleVisibilityOnActivation = true
---Whether to look for all other items in the same square as the bought item and toggle their visibility (to have them bounce in).
local toggleOtherItemsInSquare = true

---@type boolean
local checkedDisplayFirstTime = false

---@type MapObject | nil
local boughtItemInstance = nil

---@type boolean
local boughtObjectShouldBeShrinkable = false

---Called externally if there are other Buyables on the same tile to check which should be displayed
---@return number
function getDisplayPriority()
	local bought = (0 ~= game.saveData.getNumber(owner.name)) or false
	if not bought then
		return -100
	end
	return displayPriority
end

---Send 'visible' message to show/hide certain view elements (does not require listeners in case no view is present)
---@param target MapObjectType
---@param visible boolean
---@return void
local function setVisibilityOf(target, visible)
	target.bus.send({ visible = visible }, nil, false)

	if target == boughtItemInstance then
		if visible and boughtObjectShouldBeShrinkable then
			target.tags.addTag('shrinkable')
		else
			target.tags.removeTag('shrinkable')
		end
	end
end

---@param target MapObjectType
---@return void
local function toggleVisibilityOf(target)
	setVisibilityOf(target, false)
	setVisibilityOf(target, true)
end

local function setLinkedObjectsVisible(beActive)
	if linkObjectsTagged == nil or linkObjectsTagged == '' then
		return
	end
	local linkedObjects = owner.map.getAllObjectsTagged(linkObjectsTagged)
	local linkedObjectsArray = TableUtils.iteratorToArray(linkedObjects)
	for _, linkedObj in ipairs(linkedObjectsArray) do
		if beActive then
			toggleVisibilityOf(linkedObj)
		else
			setVisibilityOf(linkedObj, false)
		end
	end
end

--TODO-20230801 Switch this to using SpawnsInGrid (once finished)
---@param beActive boolean
---@param allowSound boolean|nil -- True if nil
local function setActive(beActive, allowSound)
	if isActive == beActive then
		log:debug('already ', (isActive and "active" or "inactive"))
		return
	end
	log:debug('setActive:', beActive)

	-- record new state
	isActive = beActive

	if beActive and (allowSound == nil or allowSound) then
		-- Play ItemSpawn sound when becoming active
		SoundUtils.playItemSpawnSound()
	end

	--Spawn the boughtItem

	--Let's try getting the loader only when we know we need it
	---@type Game
	local game = LoadFacility('Game')['game'] or error('No game')
	---@type Loader
	local loader = game.loader or error('No loader')

	if boughtItemInstance == nil then
		log:debug('Attempting to create ', boughtItem, ' at ', spawnPosition)
		boughtItemInstance = --[[---@type MapMobile]] loader.instantiate(boughtItem, spawnPosition)
		boughtObjectShouldBeShrinkable = boughtItemInstance.tags.hasTag('shrinkable')
		log:debug('Created ', boughtItemInstance, ' at ', spawnPosition)
	end

	-- Prompt bounce in and/or make things visible (bounceIn prompted when things go from invisible to visible)
	if beActive and toggleOtherItemsInSquare then
		-- Go through all and set invisible
		setVisibilityOf(boughtItemInstance, false)
		local bounceItems = TableUtils.iteratorToArray(owner.map.getAllTagged(spawnPosition, 'bounceIn'))
		for item in bounceItems do
			setVisibilityOf(item, false)
		end

		-- Now make original object visible
		setVisibilityOf(boughtItemInstance, true)

		-- Dispensers subscribe to this message to add items once spawned
		boughtItemInstance.bus.send({ 'spawnedAsBoughtItem' }, nil, false)

		-- Then make all others visible simultaneously
		-- (calling local function caused await to not work as expected here)
		setAutoAwait(false)
		local setVisibleTasks = {}
		for item in bounceItems do
			if item.id ~= boughtItemInstance.id then
				table.insert(
					setVisibleTasks,
					item.bus.send({ visible = true }, nil, false)
				)
			end
		end
		for task in setVisibleTasks do
			task.await()
		end
		setAutoAwait(true)
	elseif beActive and toggleVisibilityOnActivation then
		toggleVisibilityOf(boughtItemInstance)
	else
		log:debug('sending visible:', beActive)
		setVisibilityOf(boughtItemInstance, beActive)
	end

	setLinkedObjectsVisible(beActive)

	log:debug('setActive:', beActive, ': DONE')
end

local function displayIfBoughtAndHighestPriority()
	-- Only allow spawn sound when not spawning on initial check/first game phase on level start
	local allowSpawnSound = checkedDisplayFirstTime
	checkedDisplayFirstTime = true

	---@type boolean
	local bought = (0 ~= game.saveData.getNumber(owner.name)) or false
	log:debug('item:', owner.name, '@', owner.gridPosition, ' = bought:', bought)

	if not bought then
		log:debug(owner.name .. ' not bought, so not displaying')
		setActive(false)
		return
	end

	local otherBuyablesOnTile = owner.map.getAllTagged(owner.gridPosition, 'Buyable')
	for otherBuyable in otherBuyablesOnTile do
		if otherBuyable ~= nil then
			if not otherBuyable.hasFunc('getDisplayPriority') then
				error('No getDisplayPriority() on object ' .. otherBuyable.name .. ' tagged as Buyable')
			end
			local otherDisplayPriority = otherBuyable.callFunc('getDisplayPriority')
			if otherDisplayPriority > displayPriority then
				log:debug(owner.name .. ' is not the highest priority buyable to display at its position')
				setActive(false)
				return
			end
		end
	end

	log:debug(owner.name .. ' was bought and has display priority, so displaying!')
	setActive(true, allowSpawnSound)
end

local function onPurchase(_)
	displayIfBoughtAndHighestPriority()
end

local function onSpawnedFromVote(_)
	-- This item won the management phase vote, so should always appear in the level
	setActive(true)
end

local function onGamePhaseChanged()
	if not checkedDisplayFirstTime then
		displayIfBoughtAndHighestPriority()
	end
end

setLinkedObjectsVisible(false)

owner.bus.subscribe('purchase', onPurchase)
owner.bus.subscribe('spawnedFromVote', onSpawnedFromVote)
game.bus.subscribe('gamePhase', onGamePhaseChanged)
