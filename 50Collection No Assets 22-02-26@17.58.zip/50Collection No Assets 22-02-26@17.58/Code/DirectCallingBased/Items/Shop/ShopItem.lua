---Item in the shop, yet to be bought.

---@type MapObject
local owner = owner or error('No owner')
---@type Game
local game = LoadFacility('Game')['game']

---@type AchievementsHelper
local AchievementsHelper = require('AchievementsHelper')
---@type FieldHelper
local FieldHelper = require('FieldHelper')
---@type NarrativeSaveDataKeys
local SaveDataKeys = require('NarrativeSaveDataKeys')
---@type Vector
local V2 = require('Vector')
---@type SoundUtils
local SoundUtils = require('SoundUtils')

---@type string
local buyableName = buyableName or error("ShopItem MUST HAVE a 'buyableName' supplied as data")
---@type number
local cost = cost or 5

--- Array of buyable item names that must have already been bought for this shop item to be displayed
---@type string[]
local requirePurchased = requirePurchased or {}

--- Level number that must have been played through for this shop item to be displayed (-1 = no requirement)
---@type number
local requireLevelCompleted = requireLevelCompleted or -1

---@type boolean
local displaying = false

local CoinDisplay = require('DisplayCostByCoinsLogic')
local V3 = require('Vector3')

local Log = require('Log')
local log = Log.new()

---@type boolean
local bought = (0 ~= game.saveData.getNumber(buyableName)) or false

---@type MapObject|nil
local itemLabelObject
---@type MapObject|nil
local footprintObject

-- Get display name & info for this item from ItemVoteManagement
local itemManager = owner.map.getFirstObjectTagged('ItemVoteManagement') or error('ShopItem expects ItemVoteManagement object to be present')
if not itemManager.hasFunc('getDisplayNameAndInfoForBuyable') then
    error('No getDisplayNameAndInfoForBuyable() on ItemVoteManagement object')
end
local buyableNameAndInfo = itemManager.callFunc('getDisplayNameAndInfoForBuyable', buyableName)
local buyableDisplayName = buyableNameAndInfo.displayName
local buyableDisplayInfo = buyableNameAndInfo.displayInfo

local function announce(txt)
    log:debug('announce:"', txt, '"')
    game.bus.send({
        displayText = '       '.. txt ..'                   ... ',
        displayType = 'ticker'
    }, nil, false)
end

local function notifyAllBuyables()
    log:debug('notifying')

    -- First, pull all into an array since modifying enumerable will cause exception
    local array = {}
    for o in owner.map.getAllObjectsTagged('buyable') do
        table.insert(array, o)
    end

    -- Now notify everything
    for o in array do
        o.bus.send({'purchase'})
    end
end

---Coins previously displayed (which need tidying before redisplaying)
---@type MapObject?
local coinsDisplayed

---@param orig table
---@return table
local function cloneCoin(orig)
    ---@type table
    local clone = {}
    for k, v in pairs(orig) do
        clone[k] = v
    end
    return clone
end

---@return void
local function updateCoinDisplay()
    --Remove any previously displayed coins
    if nil ~= coinsDisplayed then
        log:debug('Destroying old coins: ', coinsDisplayed)
        coinsDisplayed.destroyObject()
    end
    coinsDisplayed = nil

    if 0 >= cost then
        return
    end

    --Determine new coins to display
    local coinIndices = CoinDisplay:getIndicesFromCost(cost)
    log:debug('coin indices required:', coinIndices)

    ---Get the definitions and extract the art parts.
    ---Each entry is an array of models.
    ---@type any[][]
    local arts = {}
    for i = 1, #CoinDisplay.numToCoinPrefabMap do
        local prefabName = CoinDisplay:getPrefabByIndex(i)
        local levelObject = game.loader.getDefinition(prefabName)
        table.insert(arts, --[[---@type any[] ]] levelObject.art3d)
    end

    --Add them
    local positions = CoinDisplay:getPositionForNumberOfCoins(#coinIndices)
    local artParts = {}
    for i, prefabNumber in ipairs(coinIndices) do
        -- For each element of the array, we need to add our position
        for _, artPrefab in ipairs(arts[prefabNumber]) do
            local art = cloneCoin(artPrefab)
            local posOrig = V3.new(art.pos);
            -- TODO: Make this work without workaround: art.pos = posOrig + positions[i]
            local pos = posOrig + positions[i]
            art.pos = { x = pos.x, y = pos.y, z = pos.z }
            table.insert(artParts, art)
        end
    end
    local levelObject = {
        mapObject = "Custom",
        art3d = artParts,
        name = 'CoinsDisplay=' .. cost,
        --tags = { 'billboard' },
        --data = { billboardType = 'VerticalOnly' }
        tags = { 'rotate' },
        data = { eulerSpeeds = { y = 45 } }
    }

    log:debug('Creating coins for ', owner.name, ' at ', owner.gridPosition, ' from ', levelObject)
    coinsDisplayed = game.loader.instantiate(levelObject, owner.gridPosition)
    log:debug('Created ', coinsDisplayed)
end

---@return boolean
local function requiredLevelOrGreaterWasCompleted()
    if requireLevelCompleted < 0 then
        -- No level completion requirement
        return true
    end

    local numberOfLevelsInPackage = game.totalNumberOfLevels
    if numberOfLevelsInPackage < 10 then
        -- game.totalNumberOfLevels is lower than should be expected for Co OPERATION (probably playing in Level Design, where the total num. levels is unknown)
        -- So pretend there are enough levels in the package to do this check properly, allowing for easier testing
        -- Note: This will only work for requireLevelCompleted values of <= 10, we may want to update/increase in the future
        numberOfLevelsInPackage = 10
        log:log('game.totalNumberOfLevels is lower than expected (i.e. must be in Level Design), so pretending there are 10 total levels')
    end

    -- Return true if level number requireLevelCompleted, or any subsequent levels, were played through
    for levelNum = requireLevelCompleted, numberOfLevelsInPackage, 1 do
        if game.saveData.getNumber(SaveDataKeys.global_levelXCompleted(levelNum)) ~= 0 then
            return true
        end
    end
    return false
end

---@return boolean
local function readyToDisplay()
    -- If any required items have not been bought, don't display this shop item yet
    if requirePurchased ~= nil and #requirePurchased > 0 then
        for requirePurchasedItem in requirePurchased do
            if (game.saveData.getNumber(requirePurchasedItem) == 0) then
                log:debug('ShopItem ' .. owner.name .. ' is not ready to be displayed, because ' .. requirePurchasedItem .. ' has not been bought')
                return false
            end
        end
    end

    if not requiredLevelOrGreaterWasCompleted() then
        log:debug('ShopItem ' .. owner.name .. ' is not ready to be displayed, because level ' .. tostring(requireLevelCompleted) .. ' or higher has not been played through')
        return false
    end

    return true
end

---@param shouldDisplay boolean
local function setItemLabelDisplaying(shouldDisplay)
    if shouldDisplay then
        if itemLabelObject ~= nil then
            -- Already displaying
            return
        end
        -- Instantiate label
        local labelDefinition = game.loader.getDefinition('shopItemLabel')
        labelDefinition.textMeshes[1].text = '<b>' .. buyableDisplayName .. '</b>'
        labelDefinition.textMeshes[2].text = '<b>' .. buyableDisplayInfo .. '</b>'
        itemLabelObject = game.loader.instantiate(labelDefinition, owner.gridPosition)
    else
        -- Not displaying - destroy if a label was previously created
        if itemLabelObject ~= nil then
            itemLabelObject.destroyObject()
        end
    end
end

---@param shouldDisplay boolean
local function setFootprintDecalDisplaying(shouldDisplay)
    if shouldDisplay then
        if footprintObject ~= nil then
            -- Already displaying
            return
        end
        -- Instantiate footprint decal
        footprintObject = game.loader.instantiate('floordeco4_e', V2.new(owner.gridPosition) + V2.directionNameToVector('west'))
    else
        -- Not displaying - destroy if a footprint was previously created
        if footprintObject ~= nil then
            footprintObject.destroyObject()
        end
    end
end

---@param allowSound boolean|nil -- True if nil
local function displayIfRequirementsMet(allowSound)
     local canDisplay = readyToDisplay()

    if canDisplay then
        if allowSound == nil or allowSound then
            -- Play ItemSpawn sound when becoming visible
            SoundUtils.playItemSpawnSound()
        end
        -- Become visible!
        owner.bus.send({ visible = true }, nil, false)
        updateCoinDisplay()
        displaying = true
    else
        owner.bus.send({ visible = false }, nil, false)
        displaying = false
    end

    setItemLabelDisplaying(displaying)
    setFootprintDecalDisplaying(displaying)
end

---@param message Message
local function onGamePhaseChanged(message)
    local gamePhase = message.data.gamePhase
    if gamePhase == 'planning' and not displaying then
        displayIfRequirementsMet()
    end
end

---@return boolean
function isDisplaying()
    return displaying
end

local function buyItem()
    owner.destroyObject()
    updateCoinDisplay() -- removes coin display
    setItemLabelDisplaying(false)
    setFootprintDecalDisplaying(false)
    game.saveData.setNumber(buyableName, 1)

    SoundUtils.playBuySound()

    -- Finalise payment (done before potentially paying in change & updating coin scoreboard to ensure accurate values there)
    FieldHelper.callFuncOnFirstMapObjectTagged('ShopMoneyManager', 'finalisePayment', true)

    game.bus.send({
        metadata = { 'infoAlert.show' },
        data = {
            text = 'shop_purchased',
            position = owner.gridPosition,
            awaitAnimation = true
        }
    }, nil, false)

    if cost < 0 then
        -- The item was purchased with a coin value greater than its remaining cost
        -- Players are owed some change!
        local change = cost * -1

        local coinScoreboard = owner.map.getFirstObjectTagged('coinScoreboard')
        if coinScoreboard ~= nil then
            local credit = game.saveData.getNumber('credit')
            coinScoreboard.bus.send({
                metadata = { 'coinScoreboard.updateDisplayedBalance' },
                data = {
                    balance = credit + change,
                    moneyEarnedSequence = { 'change', change },
                    originPos = owner.gridPosition,
                }
            })
        end

        log:log('paying in change from purchase: ' .. tostring(change))
        FieldHelper.callFuncOnFirstMapObjectTagged('ShopMoneyManager', 'payIn', change)
    end

    if buyableName == 'buyable_shrinkRay_dispenser' then
        announce('Use the Shrink-Prod to shrink objects in an adjacent tile!')
    end
    notifyAllBuyables()

    -- Unlock achievement! Purchased item
    AchievementsHelper.unlockPurchaseItemAchievement()

    local purchaseCount = game.saveData.getNumber('stat_purchaseCount')
    purchaseCount = purchaseCount + 1
    if purchaseCount >= 5 then
        -- Unlock achievement! Purchased 5 items
        AchievementsHelper.unlockPurchase5TimesAchievement()
    end
    game.saveData.setNumber('stat_purchaseCount', purchaseCount)

    game.saveData.save()
end

---Externally called function, called from ShopCoin.tryPay()
---@param value number
---@return boolean true if fully paid, false if still more to pay.
---@param coinMapObj MapObject|nil
function pay(value, coinMapObj)
    if not displaying then
        log:error('calling pay() on ShopItem that is not currently displaying: ' .. owner.name)
        return false
    end

    if coinMapObj ~= nil then
        coinMapObj.bus.send({ 'applyItemWithJump' }, nil, false)
    end

    local shineEffect = owner.map.getFirstTagged(owner.gridPosition, 'shineParticles')

    log:log('paid ', value,' for ', buyableName)
    cost = cost - value
    if cost <= 0 then
        log:log('all paid!')
        if shineEffect ~= nil then
            shineEffect.bus.send({ 'shineParticles.fire' }, nil, false)
        end
        buyItem()
        return true
    end

    -- paying but not fully buying (some cost remaining)
    if shineEffect ~= nil then
        shineEffect.bus.send({ 'shineParticles.fireShort' }, nil, false)
    end

    -- Sounds for partial payment
    SoundUtils.playCoinSound()
    SoundUtils.playBuyFastSound()

    -- update coins to show the remaining cost
    updateCoinDisplay()
    return false
end

-- MAIN

if bought then
    owner.destroyObject()
else
   displayIfRequirementsMet(false)
   game.bus.subscribe('gamePhase', onGamePhaseChanged)
end
