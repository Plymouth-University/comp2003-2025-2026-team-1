--- Guides the player through shrinking and throwing an object with a step-by-step
--- tutorial, where an object displaying relevant text is instantiated for each step.

---@type Game
local game = LoadFacility('Game')['game']
---@type Loader
local loader = game.loader or error('No loader')
---@type MapObject
local owner = owner or error('No owner')

---@type MessageHelpers
local MessageHelpers = require('MessageHelpers')

local Log = require('Log')
local log = Log.new()

---@type number
local tutorialStep = 0 -- Set to 1 on becoming visible

---@type MapObject
local shrinkableMapObject
---@type V2|nil
local shrinkableStartPos
---@type MapObject|nil
local tutorialTextMapObject = nil
---@type boolean
local shrunkSinceLastStep = false
---@type boolean
local pickedUpShrunkItemSinceLastStep = false
---@type boolean
local threwShrunkItemSinceFirstStep = false
---@type boolean
local placedAtStartPosSinceLastStep = false
---@type boolean
local regrewAtStartPosSinceLastStep = false
---@type boolean
local regrewSinceLastStep = false

--- Destroy any existing tutorial text object,
--- then instantiate a new one based on the current tutorialStep
local function setupTutorialTextForCurrentStep()
    if tutorialTextMapObject ~= nil then
        tutorialTextMapObject.destroyObject()
    end

    if tutorialStep >= 1 and tutorialStep <= 5 then
        tutorialTextMapObject = loader.instantiate('shrinkTutorialStep' .. tutorialStep .. 'Text', owner.gridPosition)
    end
end

local function changeToStep(newStepNumber)
    if tutorialStep == newStepNumber then
        return
    end
    tutorialStep = newStepNumber

    if (newStepNumber == 1) then
        threwShrunkItemSinceFirstStep = false
    end
    shrunkSinceLastStep = false
    pickedUpShrunkItemSinceLastStep = false
    placedAtStartPosSinceLastStep = false
    regrewAtStartPosSinceLastStep = false
    regrewSinceLastStep = false

    setupTutorialTextForCurrentStep()
end

local function previousStep()
    changeToStep(tutorialStep - 1)
end

local function nextStep()
    changeToStep(tutorialStep + 1)
end

local function resetToFirstStep()
    changeToStep(1)
end

--- Step 1: 'Shrink me!'
local function tutorialStep1Update()
    if shrunkSinceLastStep then
        nextStep()
    end
end

--- Step 2: 'Carry me!'
local function tutorialStep2Update()
    if regrewAtStartPosSinceLastStep then
        previousStep()
    elseif pickedUpShrunkItemSinceLastStep then
        nextStep()
    end
end

--- Step 3: 'Throw that thing!'
local function tutorialStep3Update()
    if regrewAtStartPosSinceLastStep then
        changeToStep(1)
    elseif placedAtStartPosSinceLastStep then
        previousStep()
    elseif threwShrunkItemSinceFirstStep then
        nextStep()
    elseif regrewSinceLastStep then
        changeToStep(5)
    end
end

--- Step 4: 'Have fun!'
local function tutorialStep4Update()
    if regrewAtStartPosSinceLastStep then
        changeToStep(1)
    elseif regrewSinceLastStep then
        nextStep()
    end
end

--- Step 5: 'Shrunk objects regrow!'
local function tutorialStep5Update()
    if regrewAtStartPosSinceLastStep then
        changeToStep(1)
    elseif pickedUpShrunkItemSinceLastStep then
        if threwShrunkItemSinceFirstStep then
            previousStep()
        else
            changeToStep(3)
        end
    end
end

local function doUpdateForCurrentStep()
    if tutorialStep == 1 then
        tutorialStep1Update()
    elseif tutorialStep == 2 then
        tutorialStep2Update()
    elseif tutorialStep == 3 then
        tutorialStep3Update()
    elseif tutorialStep == 4 then
        tutorialStep4Update()
    elseif tutorialStep == 5 then
        tutorialStep5Update()
    end
end

---@param _ Message
local function onTargetObjectShrunk(_)
	shrunkSinceLastStep = true
    doUpdateForCurrentStep()
end

---@param _ Message
local function onTargetObjectRegrew(_)
    if shrinkableStartPos == nil then
        log:warn('nil shrinkableStartPos when shrinkable is regrowing')
        return
    end
    if shrinkableMapObject.gridPosition[1] == shrinkableStartPos[1] and shrinkableMapObject.gridPosition[2] == shrinkableStartPos[2] then
       -- Shrinkable regrew at its original position
       regrewAtStartPosSinceLastStep = true
    end
    regrewSinceLastStep = true

    doUpdateForCurrentStep()
end

---@param message Message
local function onVisibilityChanged(message)
    if message.data.visible then
        shrinkableStartPos = shrinkableMapObject.gridPosition
        resetToFirstStep()
    end
end

---@param _ Message
local function onTargetObjectCarried(_)
    pickedUpShrunkItemSinceLastStep = true
    doUpdateForCurrentStep()
end

---@param _ Message
local function onTargetObjectThrownAndCaught(_)
    threwShrunkItemSinceFirstStep = true
    doUpdateForCurrentStep()
end
---@param _ Message
local function onTargetObjectThrownAndLanded(_)
    threwShrunkItemSinceFirstStep = true
    doUpdateForCurrentStep()
end

---@param message Message
local function onSiblingAdded(message)
    local addedObj = MessageHelpers.getMapObjectViaIdFromMessage(message, 'siblingAdded')
    if addedObj ~= nil and addedObj.tags.hasTag('tutorialShrinkable') then
        placedAtStartPosSinceLastStep = true
        doUpdateForCurrentStep()
    end
end

---@param message Message
local function onGamePhaseChanged(message)
	local phase = message.data.gamePhase
	if phase == nil then
		error('No phase data in gamePhase message!')
	end
    if phase == 'finished' then
		return
	end

	doUpdateForCurrentStep()
end

-- MAIN

-- Find the shrinkable object that this tutorial is based around
shrinkableMapObject = owner.map.getFirstObjectTagged('tutorialShrinkable')
if shrinkableMapObject == nil then
    error('ShopShrinkTutorial failed to find any object tagged "tutorialShrinkable"')
end

shrinkableMapObject.bus.subscribe('shrinkable.shrink', onTargetObjectShrunk)
shrinkableMapObject.bus.subscribe('shrinkable.grow', onTargetObjectRegrew)
shrinkableMapObject.bus.subscribe('carried', onTargetObjectCarried)
shrinkableMapObject.bus.subscribe('caught', onTargetObjectThrownAndCaught)
shrinkableMapObject.bus.subscribe('landed', onTargetObjectThrownAndLanded)

owner.bus.subscribe('visible', onVisibilityChanged)
owner.bus.subscribe('siblingAdded', onSiblingAdded)

game.bus.subscribe('gamePhase', onGamePhaseChanged)
