---@type Game
local game = LoadFacility('Game')['game']

local Log = require('Log')
local log = Log.new()

---@type string
local currentGamePhase

---@class ArrowColours
---@field fillColour string
---@field shadowColour string
---@field outlineColour string
---@field labelColour string

---@return ArrowColours
local function getArrowColoursForCurrentLevel()
    if game.levelNumber <= 4 then
        -- Levels 1-4 (Orange/brown levels)
        return {
            fillColour = '#D08956DC',
            shadowColour = '#A45D3BDC',
            outlineColour = '#430901',
            labelColour = '#430901'
        }
    elseif game.levelNumber <= 8 then
        -- Levels 5-8 (Blue levels)
        return {
            fillColour = '#AFBECADC',
            shadowColour = '#4E7690DC',
            outlineColour = '#193446',
            labelColour = '#193446'
        }
    elseif game.levelNumber <= 12 then
        -- Levels 9-12 (Green levels)
        return {
            fillColour = '#B8CF93DC',
            shadowColour = '#718545DC',
            outlineColour = '#20310E',
            labelColour = '#20310E'
        }
    elseif game.levelNumber <= 16 then
        -- Levels 13-16 (Red levels)
        return {
            fillColour = '#F5ABA3DC',
            shadowColour = '#B74248DC',
            outlineColour = '#3F0D10',
            labelColour = '#3F0D10'
        }
    else
        -- Shop/results level
        return {
            fillColour = '#E2D4D2DC',
            shadowColour = '#9B8987DC',
            outlineColour = '#413939',
            labelColour = '#413939'
        }
    end
end

local function updateArrowVisibilityBasedOnCurrentGamePhase()
    if currentGamePhase == 'planning' then
        local arrowColours = getArrowColoursForCurrentLevel()

        -- Note: If directional arrows are disabled by the player in the options
        --  menu, arrows will stay hidden even when sending the 'show' message
		game.bus.send({
            metadata = { 'directionalArrowsUI.show' },
            data = {
                fillColour = arrowColours.fillColour,
                shadowColour = arrowColours.shadowColour,
                outlineColour = arrowColours.outlineColour,
                labelColour = arrowColours.labelColour
            }
        }, nil, false)
	else
		game.bus.send({ 'directionalArrowsUI.hide' }, nil, false)
	end
end

-- ---@param _ Message
-- local function onShowArrowsOptionsToggleSet(_)
--     updateArrowVisibilityBasedOnCurrentGamePhase()
-- end

---@param message Message
local function onGamePhaseChanged(message)
	local phase = message.data.gamePhase
	if phase == nil then
		error('No phase data in gamePhase message!')
	end
	currentGamePhase = phase

	updateArrowVisibilityBasedOnCurrentGamePhase()
end

-- game.bus.subscribe('directionalArrowsUI.optionsToggleSet', onShowArrowsOptionsToggleSet)
game.bus.subscribe('gamePhase', onGamePhaseChanged)
