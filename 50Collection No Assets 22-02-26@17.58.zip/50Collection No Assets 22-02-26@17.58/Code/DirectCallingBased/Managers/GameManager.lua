-- GameManagerLua
-- Monitors for `patient.cured`, counts patients remaining and finishes the level once all done.
-- Finishes the level by sending the `level.won` message.

-- Bring in the ability to subscribe to the GameManager's message bus for game phase changes
-- local gameFacility = LoadFacility('Game')
----print('loading gameFacility via require')
----local gameFacility = require('Game')
--print('gameFacility:', gameFacility)
--print('gameFacility[game]:', gameFacility['game'])
--local game = gameFacility['game']
---@type Game
local game = LoadFacility('Game')['game']

local subscriptionHelper = require('SubscriptionHelper').new(game.bus)

---@type NarrativeSaveDataKeys
local SaveDataKeys = require('NarrativeSaveDataKeys')
---@type SaveDataHelper
local SaveDataHelper = require('SaveDataHelper')
---@type SoundUtils
local SoundUtils = require('SoundUtils')
---@type AchievementsHelper
local AchievementsHelper = require('AchievementsHelper')

local Log = require('Log')
local log = Log.new()

-- Start music
if game.levelNumber <= 4 then
	-- Levels 1-4 ('World 1')
	game.bus.send({ metadata = { 'playMusic' }, data = { soundName = 'CoOperationWorld1Music' } }, false)
elseif game.levelNumber <= 8 then
	-- Levels 5-8 ('World 2')
	game.bus.send({ metadata = { 'playMusic' }, data = { soundName = 'CoOperationWorld2Music' } }, false)
elseif game.levelNumber <= 12 then
	-- Levels 9-12 ('World 3')
	game.bus.send({ metadata = { 'playMusic' }, data = { soundName = 'CoOperationWorld3Music' } }, false)
else
	-- Subsequent levels ('World 4')
	game.bus.send({ metadata = { 'playMusic' }, data = { soundName = 'CoOperationWorld4Music' } }, false)
end

---@type number
local numPatientsAtStart = 0
---@type number
local numPatientsCured = 0
---@type number
local numPatientsDied = 0

---@type boolean
local doingGamePhaseStartDelay = false

---@type boolean
local sentEndingMessage = false

---@type string
local currentGamePhase

---@type boolean
local managementPhaseChecked = false

---@type boolean
local firstPlanningPhase = true

---@type number
local selectedTurnsPerRound

local function getNumPatientsRemaining()
	local iterator = game.map.getAllObjectsTagged('patient')
	-- This gives an iterator so we iterate it and count how many there are
	local count = 0
	for _ in iterator do
		count = count + 1
	end
	return count
end

---@param text string
---@param hexColour string|nil
local function displayLevelEndBanner(text, hexColour)
	game.bus.send({
		metadata = { 'bannerUI.show' },
		data = {
			text = text,
			delay = 0.2,
			duration = 3,
			colour = hexColour and hexColour or ''
		}
	}, nil, false)
end

local function levelCompleted()
	-- Save data that will need to be accessed by lua scripts in the results level
	game.saveData.setNumber('patientsDied', numPatientsDied)
	game.saveData.setNumber('patientsCured', numPatientsCured)
	-- Mark level as completed in save data, used by narrative system to determine whether certain dialogue will be shown
	game.saveData.setNumber(SaveDataKeys.global_levelXCompleted(game.levelNumber), 1)
	if numPatientsDied == 0 then
		-- Level completed with all patients cured!
		game.saveData.setNumber(SaveDataKeys.global_levelXAllCured(game.levelNumber), 1)
		if game.levelNumber == 1 then
			-- Unlock achievement! Heal all patients in ward 1
			AchievementsHelper.unlockHealAllWard1Achievement()
		elseif game.levelNumber == 5 then
			AchievementsHelper.unlockHealAllWard5Achievement()
		elseif game.levelNumber == 9 then
			AchievementsHelper.unlockHealAllWard9Achievement()
		end
	end

	if (game.saveData.getNumber(SaveDataKeys.global_levelXCompleted(1)) ~= 0) and (game.saveData.getNumber(SaveDataKeys.global_levelXCompleted(2)) ~= 0) then
		-- Unlock achievement! Complete wards 1 and 2
		AchievementsHelper.unlockCompleteWards1And2Achievement()
	end
	if game.levelNumber == 4 then
		-- Unlock achievement! Complete ward 4
		AchievementsHelper.unlockCompleteWard4Achievement()
	elseif game.levelNumber == 8 then
		-- Unlock achievement! Complete ward 8
		AchievementsHelper.unlockCompleteWard8Achievement()
	elseif game.levelNumber == 12 then
		-- Unlock achievement! Complete ward 12
		AchievementsHelper.unlockCompleteWard12Achievement()
	end

	if selectedTurnsPerRound == 2 then
		-- Unlock achievement! Complete any ward in chilled (2 turns per round) mode
		AchievementsHelper.unlockCompleteWardChilledAchievement()
	end

	if sentEndingMessage then
		error('GameManager.lua tried to send `level.won` twice!') --This was causing the level end soft hang! Implication is Lua VM is not reentrant under async!
		return
	end
	sentEndingMessage = true

	-- Note: There is no distinction between 'winning' or 'losing' a level.
	--	either way, a results level will be loaded where players can choose whether to replay or continue to the next level

	--Ensure no more messages are received
	subscriptionHelper:unsubscribeAll()

	if numPatientsCured == numPatientsAtStart then
		displayLevelEndBanner('levelBanner_levelEndAllCured', '#00875E')
	elseif numPatientsCured > 0 then
		displayLevelEndBanner('levelBanner_levelEndSomeCured')
	else
		displayLevelEndBanner('levelBanner_levelEndNoneCured', '#7E3500')
	end

	local wonMessage = { metadata = { 'level.won' }, data = { patientsCured = numPatientsCured, patientsTotal = numPatientsAtStart } }
	local lostMessage = { metadata = { 'level.lost' }, data = { patientsCured = numPatientsCured, patientsTotal = numPatientsAtStart } }
	local didWin = numPatientsCured > numPatientsDied;
	local endingMessage = didWin and wonMessage or lostMessage
	log:log('All patients done: ', numPatientsCured, ' cured, ', numPatientsDied, ' died = Finishing the level with ', endingMessage)
	game.bus.send(endingMessage)
	-- Save the number of this level, so it can be reloaded/the next one can be loaded in the results level
	game.saveData.setNumber('lastCompletedLevelNumber', game.levelNumber)
	game.saveData.save()

	if game.levelNumber == game.totalNumberOfLevels - 1 then
		-- The final level was completed! (2nd highest level number, since the shop/results level is listed last)
		-- Show end-of-game/end-of-demo screen (assume that >6 levels = full game, otherwise demo)
		game.bus.send({
			metadata = { 'coOperationEndOfGameScreen.show' },
			data = { demo = (game.totalNumberOfLevels <= 6) }
		}, nil, false)
		return
	end

	-- Trigger loading of the results level after win/loss
	log:log('GameManager.lua sending `level.load` to load levelResults')
	game.bus.send({
		metadata = { 'level.load' },
		data = { levelId = 'levelResults' }
	})
end

local function checkEnding()
	if numPatientsAtStart == 0 then
		return
	end

	local numPatientsRemaining = getNumPatientsRemaining()
	local allPatientsCuredOrDied = ((numPatientsDied + numPatientsCured) >= numPatientsAtStart)

	log:log('Checking for level end: Found ', numPatientsRemaining, ' patients remaining. All were cured/died: ', allPatientsCuredOrDied)
	if 0 >= numPatientsRemaining and allPatientsCuredOrDied then
		levelCompleted()
	else
		log:log('Level still in-progress')
	end
end

local function sendRequiredMedicineForRound()
	local allPatients = owner.map.getAllObjectsTagged('patient')
	if allPatients == nil then
		return
	end
	local requiredMedicine = {}
	for patient in allPatients do
		local patientIsInBedTile = (owner.map.getFirstTagged(patient.gridPosition, 'bed') ~= nil)
		local patientIsActive = patient.callFunc('isActive')
		if patientIsInBedTile and patientIsActive then
			local medicineType = patient.callFunc('getNeed')
			requiredMedicine[medicineType] = true
		end
	end
	game.bus.send({ requiredMedicineForRound = requiredMedicine }, nil, false)
end

local function onPatientCured()
	numPatientsCured = numPatientsCured + 1
	checkEnding()
end

local function onPatientDied()
	numPatientsDied = numPatientsDied + 1
	checkEnding()
	if currentGamePhase == 'planning' then
		sendRequiredMedicineForRound()
	end
end

local function onPatientAppeared()
	if currentGamePhase == 'planning' then
		sendRequiredMedicineForRound()
	end
end

local function onGamePhaseChanged(message)
	local phase = message.data.gamePhase
	if phase == nil then
		error('No phase data in gamePhase message!')
	end
	log:debug('currentGamePhase:(', currentGamePhase, '->', phase, ')')
	currentGamePhase = phase

	if phase == 'planning' then
		-- Only play sound if there are patients in the level and this isn't the first planning phase
		if getNumPatientsRemaining() > 0 and not firstPlanningPhase then
			SoundUtils.playEndOfRoundSound()
		end
		firstPlanningPhase = false

		if (game.saveData.getNumber(SaveDataKeys.thisRound_didPlayerCatch()) ~= 0) and (game.saveData.getNumber(SaveDataKeys.thisRound_wasPatientCured()) ~= 0) then
			-- Unlock achievement! Throw, catch & heal in the same round
            AchievementsHelper.unlockCatchAndHealAchievement()
        end

		sendRequiredMedicineForRound()
	end
end

---@param delayDuration number
local function startGamePhaseChangeDelayTimer(delayDuration)
	if doingGamePhaseStartDelay then
		return
	end

	doingGamePhaseStartDelay = true

	local scoreboards = owner.map.getAllObjectsTagged('scoreboard')
	for scoreboard in scoreboards do
		scoreboard.bus.send({ visible = false }, nil, false)
	end

	owner.bus.send({
		metadata = { 'delayTimer.start' },
		data = {
			duration = delayDuration,
			displayType = 'countdown',
			awaitAnimation = false
		}
	}, nil, false)
end

---@param _ Message
local function onGetNextGamePhase(_)
	-- About to switch to the next game phase, send gamePhaseEnd for any script that's interested
	game.bus.send({ 'gamePhaseEnd' }, nil, false)

	if not managementPhaseChecked then
		managementPhaseChecked = true
		-- Check if we should enter the management phase on level start
		local itemVoteManagement = owner.map.getFirstObjectTagged('ItemVoteManagement')
		if itemVoteManagement and itemVoteManagement.hasFunc('canEnterManagementPhase') and itemVoteManagement.callFunc('canEnterManagementPhase') then
			-- Tell itemVoteManagement to send item vote data to controllers
			if not itemVoteManagement.hasFunc('sendDataToControllers') then
				error('No sendDataToControllers() on itemVoteManagement object when about to enter management phase')
			end
			itemVoteManagement.callAction('sendDataToControllers')

			-- Management (item voting) phase should take place!
			log:log('GameManager lua says: to go management phase!')
			return { gamePhase = 'management' }
		end
	end

	if currentGamePhase == 'management' then
		-- We're in the management phase, so switch to management results next
		log:log('GameManager lua says: to go managementResults phase!')
		return { gamePhase = 'managementResults' }
	elseif currentGamePhase == 'planning' then
		local narrativeManager = owner.map.getFirstObjectTagged('NarrativeManager')
		if (not doingGamePhaseStartDelay) and narrativeManager and narrativeManager.hasFunc('getWriterPlanningDelay') then
			local writerPlanningDelay = narrativeManager.callFunc('getWriterPlanningDelay')
			if writerPlanningDelay > 0 then
				startGamePhaseChangeDelayTimer(writerPlanningDelay)
				return { gamePhase = 'waiting' }
			end
		end
	end

	-- Otherwise, game phases continue with the default planning/acting loop
	log:debug('GameManager lua giving no response to getNextGamePhase (continue with default planning/acting loop)')
end

---@param _ Message
local function onGamePhaseDelayTimerCompleted(_)
	local scoreboards = owner.map.getAllObjectsTagged('scoreboard')
	for scoreboard in scoreboards do
		scoreboard.bus.send({ visible = true }, nil, false)
	end

	game.bus.send({
		metadata = { 'level.nextPhase' }
    })
	doingGamePhaseStartDelay = false
end

-- Set number of turns to the value that was selected during game setup
selectedTurnsPerRound = SaveDataHelper.getSavedTurnsPerRoundOrDefault()
if (selectedTurnsPerRound > 0) then
	game.setTurnCount(selectedTurnsPerRound)
end

game.setTurnExecutionMode('PerformActionsInSequence')

numPatientsAtStart = getNumPatientsRemaining()
log:log('Found ', numPatientsAtStart,' patients at start')

if game.levelNumber < game.totalNumberOfLevels then
	-- This level should be selected when next returning to the level selector
	-- (unless in level with the greatest level number, i.e. results/shop level)
	game.saveData.setNumber('levelSelectionIndex', game.levelNumber)
end

subscriptionHelper:registerSubscription('patient.cured', onPatientCured)
subscriptionHelper:registerSubscription('patient.died', onPatientDied)
subscriptionHelper:registerSubscription('patient.appeared', onPatientAppeared)
subscriptionHelper:registerSubscription('gamePhase', onGamePhaseChanged)
subscriptionHelper:registerSubscription('getNextGamePhase', onGetNextGamePhase)
owner.bus.subscribe('delayTimer.completed', onGamePhaseDelayTimerCompleted)

--Do all the subscriptions
subscriptionHelper:subscribeAll()
