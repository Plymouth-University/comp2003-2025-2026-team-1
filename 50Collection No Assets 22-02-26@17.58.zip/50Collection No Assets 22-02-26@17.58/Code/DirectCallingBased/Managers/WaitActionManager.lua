﻿--- Sets data each round that players can use to check if/how they should wait on each turn.

---@type Game
local game = LoadFacility('Game')['game'] or error('No game')

---@type WaitActionHelper
local WaitActionHelper = require('WaitActionHelper')

-- local Log = require('Log')
-- local log = Log.new()

---@type table<number, Turn[]>
local turnsForAllPlayers = {}

---@type table<number, boolean>
local turnsWithNonWaitActions = {}

local function setTurnsWithNonWaitActionsData()
    turnsWithNonWaitActions = {}
    for i = 1, game.turnCount, 1 do
		WaitActionHelper.setTurnHasNonWaitAction(i, false)
    end
    for playerNum = 0, (game.startingCharacterPlayerCount - 1), 1 do
        local turnsForAPlayer = turnsForAllPlayers[playerNum]
        if turnsForAPlayer ~= nil then
            for turnNumber, turn in ipairs(turnsForAPlayer) do
                if turn ~= nil and turn.action ~= nil and turn.action ~= '' then
                    -- Non-wait turn
                    turnsWithNonWaitActions[turnNumber] = true
					WaitActionHelper.setTurnHasNonWaitAction(turnNumber, true)
                end
            end
        end
    end
end

local function setSpecialWaitPlayerAndTurnData()
    if #turnsWithNonWaitActions == 0 then
        setTurnsWithNonWaitActionsData()
    end
    local availableSpecialWaitTurns = {}
    for playerNum = 0, (game.startingCharacterPlayerCount - 1), 1 do
        local turnsForAPlayer = turnsForAllPlayers[playerNum]
        if turnsForAPlayer ~= nil then
            for turnNumber, turn in ipairs(turnsForAPlayer) do
                if (turn == nil or turn.action == nil or turn.action == '') and (turnsWithNonWaitActions[turnNumber] == true) then
                    -- Wait/blank action on a turn where not all actions are waits
                    table.insert(availableSpecialWaitTurns, { turnNumber = turnNumber, playerNumber = playerNum })
                end
            end
        end
    end
    if #availableSpecialWaitTurns == 0 then
		WaitActionHelper.setSpecialWaitPlayerAndTurnNumber(-1, -1)
        return
    end
    local chosenSpecialWait = availableSpecialWaitTurns[math.random(#availableSpecialWaitTurns)]
	WaitActionHelper.setSpecialWaitPlayerAndTurnNumber(chosenSpecialWait.playerNumber, chosenSpecialWait.turnNumber)
end

---@param message Message
local function onGamePhaseChanged(message)
    local phase = message.data.gamePhase
    if phase == nil then
		error('No phase data in gamePhase message!')
	end

    if phase == 'planning' then
		turnsForAllPlayers = {}
	elseif phase == 'acting' then
		-- When acting phase starts, update data for which turns have any non-wait actions,
		--	and which player can perform a 'special wait' on which turn
		setTurnsWithNonWaitActionsData()
		setSpecialWaitPlayerAndTurnData()
    end
end

---@param message Message
---@param playerNumber number
local function onSetTurns(message, playerNumber)
	---@type Turn[]|nil
    local turns = message.data['MultiTurn.setTurns']
    if turns == nil or #turns == 0 then
        error('No turns data in MultiTurn.setTurns message')
    end
	turnsForAllPlayers[playerNumber] = turns
end

-- MAIN

local players = owner.map.getAllObjectsTagged('player')
for player in players do
	-- Subscribe to 'MultiTurn.setTurns' on each player's bus so we can get all of their actions, and use those actions
	--	to determine which turns are wait-only (and hence can be skipped over), and when special waits can be performed
    local playerComponent = player.getFirstComponentTagged('Player')
    local playerNumber = playerComponent.playerNumber
    player.bus.subscribe('MultiTurn.setTurns', (function(message)onSetTurns(message, playerNumber)end))
end

game.bus.subscribe('gamePhase', onGamePhaseChanged)
