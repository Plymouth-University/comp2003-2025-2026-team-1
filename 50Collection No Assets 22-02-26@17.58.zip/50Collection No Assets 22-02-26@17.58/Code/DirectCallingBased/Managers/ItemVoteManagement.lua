---@type Game
local game = LoadFacility('Game')['game']
---@type Loader
local loader = game.loader or error('No loader')

local Log = require('Log')
local log = Log.new()

---@type MapMobile
local owner = owner or error('No owner')

---@class PlaceableObject
---@field objectDefinition string
---@field displayName string
---@field displayInfo string

---@class VoteForPosition
---@field characterIndex number
---@field item string

---@class WinningVoteInfo
---@field winningItem string
---@field positionIndex number
---@field numberOfVotes number
---@field wonWithMajority boolean

---@type PlaceableObject[]
local allPlaceableObjects = allPlaceableObjects or { }

---@type number
local requirePurchasedItems = requirePurchasedItems or 1 -- (1 = true, 0 or other value = false)

---@type string[]
local alphabet = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' }

--- Every gridPosition where voted items can be placed in the level
---@type number[][]
local placementPositions = {}

--- Definition names for every item in allPlaceableObjects that can be voted on
---  (only purchased items when requirePurchasedItems = true)
---@type string[]
local votableObjectDefinitions = {}
--- Display names for every item in allPlaceableObjects that can be voted on
---@type string[]
local votableDisplayNames = {}

---@type table<string, string>
local objectDisplayNameToDef = {}

---@type table<number, VoteForPosition[]>
local votesForPositions = {}

---@type string
local currentGamePhase

---@type boolean
local destroyed = false

--- Called externally to get the display name & info for a buyable item
---@param buyableDefinitionName string
---@return PlaceableObject
function getDisplayNameAndInfoForBuyable(buyableDefinitionName)
    for _, itemDefAndName in pairs(allPlaceableObjects) do
        if itemDefAndName.objectDefinition == buyableDefinitionName then
            return {
                displayName = itemDefAndName.displayName,
                displayInfo = itemDefAndName.displayInfo
            }
        end
    end
    return {
        displayName = 'Unknown',
        displayInfo = '...'
    }
end

---Send item voting data to controllers (items and positions).
---Called externally by GameManager before entering the management phase
function sendDataToControllers()
    if #votableObjectDefinitions == 0 then
        -- No items to be voted for
        log:error('No items to be voted for in management phase')
        return
    end

    -- Find & add item landing positions
    placementPositions = {}
    for landingPos in owner.map.getAllObjectsTagged('ItemVoteLandingPos') do
        Log:log('Adding item landing position (for voting/management phase): ' .. tostring(landingPos.gridPosition))
        table.insert(placementPositions, landingPos.gridPosition)
    end

    if #placementPositions == 0 then
        -- Nowhere for players to place objects in this level
        log:error('No positions where items can be placed in management phase')
        return
    end

    -- Send item management data on game bus, which will be sent to
    --  controllers along with images (icons/previews) for each item
    game.bus.send({
        metadata = { 'management.dataForControllers' },
        data = {
            placementPositions = placementPositions,
            itemNames = votableDisplayNames,
            itemDefinitionNames = votableObjectDefinitions
        }
    }, nil, false)
end

---@return table<number, number>
local function getPlayerNumbersForCharacters()
    local playerNums = {}
    local players = owner.map.getAllObjectsTagged('Player')
    for player in players do
        local playerComponent = player.getFirstComponentTagged('Player')
        playerNums[playerComponent.characterNumber] = playerComponent.playerNumber
    end
    return playerNums
end

local function onManagementPhase()
    -- Ensure table that will contain voting results is empty
    votesForPositions = {}

    -- UI message to tell players to vote on devices
    game.bus.send({
        displayText = 'Which items should be placed and where? Vote on your devices!',
        displayType = 'messageDisplayUI.top'
    }, nil, false)

    -- UI indicators for each item placement position
    local count = 1
    for _, placementPos in pairs(placementPositions) do
        local labelText = alphabet[count]
        game.bus.send({
            metadata = { 'itemIndicator.show' },
            data = { position = placementPos, label = labelText }
        }, nil, false)
        count = count + 1
    end
end

local function addOrUpdateFloatingResultsUI(targetObject, playerNum, characterNum, votedItem, voteType)
    game.bus.send({
        metadata = { 'floatingUI.createOrUpdate' },
        data = {
            targetObject = targetObject.id,
            displayData = 'playerVote',
            playerNumber = playerNum,
            characterNumber = characterNum,
            voteType = voteType,
            icon = (votedItem ~= '') and ('Icon_LevelItem_' .. votedItem) or 'Icon_LevelItem_None'
        }
    }, nil, false)
end

local function hideAllFloatingResultsUI()
    for posIndex = 1, #placementPositions do
        local landingPosObj = owner.map.getFirstTagged(placementPositions[posIndex], 'ItemVoteLandingPos')
        game.bus.send({
            metadata = { 'floatingUI.destroy' },
            data = {
                targetObject = landingPosObj.id
            }
        }, nil, false)
    end
end

local function getObjectDefinitionNameFromDisplayName(displayName)
    if #objectDisplayNameToDef == 0 then
        for _, itemDefAndName in pairs(allPlaceableObjects) do
            objectDisplayNameToDef[itemDefAndName.displayName] = itemDefAndName.objectDefinition
        end
    end
    return objectDisplayNameToDef[displayName] or ''
end

---@param winningItem string
---@param placementPositionIndex number
local function placeWinningItemOrBackupInLevel(winningItem, placementPositionIndex)
    if winningItem ~= '' then
        -- Spawn object that won the vote for this position!
        local spawnedObj = loader.instantiate(winningItem, placementPositions[placementPositionIndex])
        if spawnedObj ~= nil then
            spawnedObj.bus.send({ 'spawnedFromVote' }, nil, false)
        end
    else
        -- No object was voted for this position, so spawn the backup object
        --  that was set in the ItemVoteLandingPos object's mod data (if any)
        local landingPosObj = owner.map.getFirstTagged(placementPositions[placementPositionIndex], 'ItemVoteLandingPos')
        landingPosObj.bus.send({ 'spawnBackupObject' }, nil, false)
    end
end

---@param votes VoteForPosition[]
---@return [VoteForPosition|nil, number]
local function getMajorityVote(votes)
    ---@type table<string, number>
    local countPerVote = {}
    ---@type number
    local highestCount = 0
    ---@type VoteForPosition|nil
    local voteWithHighestCount = nil

    for _, vote in pairs(votes) do
        local newCount = (countPerVote[vote.item] or 0) + 1
        countPerVote[vote.item] = newCount
        if newCount == highestCount then
            voteWithHighestCount = nil
        elseif newCount > highestCount then
            highestCount = newCount
            voteWithHighestCount = vote
        end
    end
    return { voteWithHighestCount, highestCount }
end

---@param validVotesPerPosition table<number, VoteForPosition[]>
---@param chosenPositionForItem table<string, number>
---@param winnersInDisplayOrder WinningVoteInfo[]
local function processVotesPartOneMajorityVotes(validVotesPerPosition, chosenPositionForItem, winnersInDisplayOrder)
    ---@type table<string, number>
    local maxVotesAtASinglePositionForItem = {}

    for posIndex = 1, #placementPositions do
        -- Find majority vote
        local majorityVoteAndNumVotes = getMajorityVote(votesForPositions[posIndex])
        local majorityVote = majorityVoteAndNumVotes[1]
        if majorityVote ~= nil then
            local numVotesForItem = majorityVoteAndNumVotes[2]
            local previousWinOverrules = false
            -- There was a majority vote for this position!
            -- Check if the majority voted item already won for a different position
            if chosenPositionForItem[majorityVote.item] ~= nil then
                local otherPosHadMoreVotes = maxVotesAtASinglePositionForItem[majorityVote.item] > numVotesForItem
                local otherPosHadSameVotes = maxVotesAtASinglePositionForItem[majorityVote.item] == numVotesForItem
                if otherPosHadMoreVotes or (otherPosHadSameVotes and math.random(0, 1) == 0) then
                    -- This item was already chosen for a previous position, and:
                    --  a: Had more votes there, OR
                    --  b. Had the same number of votes there and won the random coin flip
                    previousWinOverrules = true
                else
                    -- Clear winner at old position
                    local oldWinningPos = chosenPositionForItem[majorityVote.item]
                    validVotesPerPosition[oldWinningPos] = nil
                    for i, alreadyAddedVote in ipairs(winnersInDisplayOrder) do
                        if alreadyAddedVote.winningItem == majorityVote.item then
                            table.remove(winnersInDisplayOrder, i)
                            break
                        end
                    end
                end
            end
            if not previousWinOverrules then
                ---@type WinningVoteInfo
                local winner = {
                    winningItem = majorityVote.item,
                    numberOfVotes = numVotesForItem,
                    positionIndex = posIndex,
                    wonWithMajority = true
                }
                validVotesPerPosition[posIndex] = { majorityVote }
                chosenPositionForItem[majorityVote.item] = posIndex
                maxVotesAtASinglePositionForItem[majorityVote.item] = numVotesForItem
                -- Winning items that had a majority vote are displayed in order from most to fewest votes
                local addedToWinnersArray = false
                for i, alreadyAddedVote in ipairs(winnersInDisplayOrder) do
                    if alreadyAddedVote.numberOfVotes < numVotesForItem then
                        table.insert(winnersInDisplayOrder, i, winner)
                        addedToWinnersArray = true
                        break
                    end
                end
                if not addedToWinnersArray then
                    table.insert(winnersInDisplayOrder, winner)
                end
            end
        end
    end
end

---@param validVotesPerPosition table<number, VoteForPosition[]>
---@param chosenPositionForItem table<string, number>
---@param winnersInDisplayOrder WinningVoteInfo[]
local function processVotesPartTwoRemainingVotes(validVotesPerPosition, chosenPositionForItem, winnersInDisplayOrder)
    ---@type WinningVoteInfo[]
    local noWinnersAddToEnd = {}
    for posIndex = 1, #placementPositions do
        if validVotesPerPosition[posIndex] == nil then
            local votesForThisPosition = votesForPositions[posIndex]
            validVotesPerPosition[posIndex] = {}
            -- Only decide between valid votes, i.e. votes for items that don't already have a winning position
            for _, vote in pairs(votesForThisPosition) do
                if chosenPositionForItem[vote.item] == nil then
                    table.insert(validVotesPerPosition[posIndex], vote)
                end
            end
            if #validVotesPerPosition[posIndex] > 0 then
                local randomWinner = validVotesPerPosition[posIndex][math.random(#validVotesPerPosition[posIndex])]
                chosenPositionForItem[randomWinner.item] = posIndex
                ---@type WinningVoteInfo
                local winner = { winningItem = randomWinner.item, numberOfVotes = 1, positionIndex = posIndex, wonWithMajority = false }
                table.insert(winnersInDisplayOrder, winner)
            else
                ---@type WinningVoteInfo
                local noWinner = { winningItem = '', numberOfVotes = 0, positionIndex = posIndex, wonWithMajority = false }
                if #votesForThisPosition > 0 then
                    table.insert(winnersInDisplayOrder, noWinner)
                else
                    table.insert(noWinnersAddToEnd, noWinner)
                end
            end
        end
    end
    for _, noWinner in pairs(noWinnersAddToEnd) do
        table.insert(winnersInDisplayOrder, noWinner)
    end
end

---@param votes VoteForPosition[]
---@param winningVoteInfo WinningVoteInfo
---@param invalidVoteCount number
---@param losingVoteCount number
---@return [string, (string[]|nil)]
local function getDisplayTextForVotes(votes, winningVoteInfo, invalidVoteCount, losingVoteCount)
    local displayText
    local arguments = nil
    if winningVoteInfo.wonWithMajority then
        if #votes == game.totalPlayerCount and invalidVoteCount == 0 and losingVoteCount == 0 then
            -- All players voted for same thing
            displayText = 'itemVoteResultInfo_allAgreed'
        elseif #votes == 1 then
            -- One person voted, and they got their way
            displayText = 'itemVoteResultInfo_singlePlayerChoice'
            local playerName = game.getPlayerNameForCharacterNumber(votes[1].characterIndex)
            arguments = { playerName }
        else
            -- There was a concensus among the majority of the (2 or more) players who voted
            displayText = 'itemVoteResultInfo_majorityWins'
        end
    elseif winningVoteInfo.winningItem ~= '' then
        if invalidVoteCount >= #votes - 1 or losingVoteCount == 0 then
            -- There was only one valid item
            displayText = 'itemVoteResultInfo_remainingItemWins'
        else
            -- There was a split decision between multiple valid items
            displayText = 'itemVoteResultInfo_splitDecision'
        end
    else
        -- All voted items were placed elsewhere
        displayText = 'itemVoteResultInfo_nothingLeft'
    end
    return { displayText, arguments }
end

---@param winnersInDisplayOrder WinningVoteInfo[]
---@param chosenPositionForItem table<string, number>
local function displayResultsOfProcessedVotes(winnersInDisplayOrder, chosenPositionForItem)
    local charToPlayerNum = getPlayerNumbersForCharacters()
    local displayedPositions = {}

    for _, winningVoteInfo in pairs(winnersInDisplayOrder) do
        local winnerPosition = winningVoteInfo.positionIndex
        local votesForThisPosition = votesForPositions[winnerPosition]
        local landingPosObj = owner.map.getFirstTagged(placementPositions[winnerPosition], 'ItemVoteLandingPos')
        local invalidVoteCount = 0
        local losingVoteCount = 0
        for i, vote in ipairs(votesForThisPosition) do
            local votingPlayer = charToPlayerNum[vote.characterIndex]
            if votingPlayer == nil then
                -- If player num could not be found (player does not exist in level, likely a non-character player)
                --  then default to 100 + index - player num here determines the order the vote is displayed in UI, so
                --  making this a 'big number' will just cause non-character votes to be displayed last
                votingPlayer = 100 + i
            end
            local votedItemDef = getObjectDefinitionNameFromDisplayName(vote.item)
            local itemPosition = chosenPositionForItem[vote.item]
            local itemTaken = itemPosition ~= nil and displayedPositions[itemPosition] ~= nil
            local voteType = 'winner'
            if itemTaken then
                voteType = 'invalid'
                invalidVoteCount = invalidVoteCount + 1
            elseif winningVoteInfo.winningItem ~= vote.item then
                voteType = 'loser'
                losingVoteCount = losingVoteCount + 1
            end
            addOrUpdateFloatingResultsUI(
                landingPosObj,
                votingPlayer,
                vote.characterIndex,
                votedItemDef,
                voteType
            )
        end
        displayedPositions[winnerPosition] = true

        if #votesForThisPosition > 0 then
            local displayTextAndArguments = getDisplayTextForVotes(votesForThisPosition, winningVoteInfo, invalidVoteCount, losingVoteCount)
            -- Floating UI vote results animation
            game.bus.send({
                metadata = { 'floatingUI.createOrUpdate' },
                data = {
                    targetObject = landingPosObj.id,
                    displayData = 'playerVoteResults',
                    resultChosenRandomly = (not winningVoteInfo.wonWithMajority),
                    text = displayTextAndArguments[1],
                    textArguments = displayTextAndArguments[2]
                }
            }, nil, false)
        end

        if destroyed or currentGamePhase ~= 'managementResults' then
            -- Destroyed or phase changed during delay (level probably ended)
            return
        end

        local winningItemDef = getObjectDefinitionNameFromDisplayName(winningVoteInfo.winningItem)
        --Replace object placeent indicator with winning item indicator
        game.bus.send({
            metadata = { 'itemIndicator.hide' }, data = { position = placementPositions[winnerPosition], awaitAnimation = true }
        }, nil, false)
        game.bus.send({
            metadata = { 'itemIndicator.show' },
            data = {
                position = placementPositions[winnerPosition],
                label = alphabet[winnerPosition],
                icon = (winningItemDef ~= '') and ('Icon_LevelItem_' .. winningItemDef) or 'Icon_LevelItem_None',
                awaitAnimation = true
            }
        }, nil, false)

        if destroyed or currentGamePhase ~= 'managementResults' then
            -- Destroyed or phase changed during delay (level probably ended)
            return
        end
        game.bus.send(
            { metadata = { 'itemIndicator.hide' }, data = { position = placementPositions[winnerPosition] }
        }, nil, false)
        placeWinningItemOrBackupInLevel(winningItemDef, winnerPosition)
    end
end

---@return boolean
local function readyToHandleManagementResults()
    if placementPositions == nil then
        log:error('In management results phase, but there is nowhere to place player-voted items')
        return false
    end
    if votesForPositions == nil then
        log:error('In management results phase, but there are no (nil) votesForPositions')
        return false
    end
    if #votesForPositions ~= #placementPositions then
        log:error('In management results phase with unexpected number of votesForPositions (' .. tostring(#votesForPositions) .. ') - does not equal the number of placementPositions (' .. tostring(#placementPositions) .. ')')
        return false
    end
    -- Hide UI from management phase
    game.bus.send({
        displayText = '', displayType = 'messageDisplayUI.top'
    }, nil, false)
    return true
end

local function onManagementResultsPhase()
    if not readyToHandleManagementResults() then
        return
    end

    ---@type table<number, VoteForPosition[]>
    local validVotesPerPosition = {}
    ---@type table<string, number>
    local chosenPositionForItem = {}
    ---@type WinningVoteInfo[]
    local winnersInDisplayOrder = {}

    -- Select winning items based on player votes, and then display the results

    -- Step 1: Majority votes (i.e. votes where there is a clear winner)
    processVotesPartOneMajorityVotes(validVotesPerPosition, chosenPositionForItem, winnersInDisplayOrder)

    -- Step 2: Non-majority/remaining votes (winners are chosen randomly)
    processVotesPartTwoRemainingVotes(validVotesPerPosition, chosenPositionForItem, winnersInDisplayOrder)

    game.bus.send({
		metadata = { 'bannerUI.show' },
		data = {
			text = 'levelBanner_voteResults',
            delay = 0.5,
			duration = 2.5,
		}
	}, nil, false)

    -- Step 3: Display results
    displayResultsOfProcessedVotes(winnersInDisplayOrder, chosenPositionForItem)

    if destroyed or currentGamePhase ~= 'managementResults' then
        -- Destroyed or phase changed during delay (level probably ended)
        return
    end

    -- Hide all results UI and continue to next (planning) phase
    hideAllFloatingResultsUI()
    game.bus.send({
        metadata = { 'level.nextPhase' }
    })
end

local function onItemVoteResults(message)
    log:log('Got item vote results from controller')

    local resultsData = message.data['controller.itemVoteResults']
    if resultsData == nil then
        error('No results data in itemVoteResults message')
    end
    local characterIndex = message.data['characterIndex']
    if characterIndex == nil then
        error('No characterIndex data in itemVoteResults message')
    end

    -- Remove any votes that already exist for the character the new votes have come from
    for posCount = 1, #placementPositions do
        if votesForPositions[posCount] ~= nil then
            for voteIndex, vote in ipairs(votesForPositions[posCount]) do
                if vote.characterIndex ~= nil and vote.characterIndex == characterIndex then
                    table.remove(votesForPositions[posCount], voteIndex)
                    break
                end
            end
        end
    end

    -- Add non-empty votes for this player/character
    for posCount = 1, #placementPositions do
        if votesForPositions[posCount] == nil then
            votesForPositions[posCount] = {}
        end

        local itemAtPos = message.data['placementPos' .. tostring((posCount - 1))] -- 0 indexed!
        if itemAtPos ~= nil and itemAtPos ~= '' then
            table.insert(votesForPositions[posCount], { characterIndex = characterIndex, item = itemAtPos })
        end
    end
end

local function onGamePhaseChanged(message)
    currentGamePhase = message.data.gamePhase
    if currentGamePhase == 'management' then
        onManagementPhase()
    elseif currentGamePhase == 'managementResults' then
        onManagementResultsPhase()
    end
end

---@param message Message
local function onMapObjectStateChanged(message)
	if message.data['state.MapObject'] ~= 'Destroyed' then
		return
	end
	destroyed = true
end

---@return boolean
function canEnterManagementPhase()
    local landingPos = owner.map.getFirstObjectTagged('ItemVoteLandingPos')
    if landingPos == nil then
        -- There are no positions where players can vote for items to be placed,
        --  don't enter the management phase
        return false
    end
    if #votableObjectDefinitions == 0 then
        -- No items to vote on, don't enter the management phase
        return false
    end
    -- There are purchased items and places where they can go, let's enter the management phase!
    return true
end

---MAIN

-- Add all purchased items (i.e. items that can be voted for) to array
votableObjectDefinitions = {}
votableDisplayNames = {}
for _, itemNameAndObjectDef in pairs(allPlaceableObjects) do
    local objectDef = itemNameAndObjectDef.objectDefinition
    local itemPurchased = (0 ~= game.saveData.getNumber(objectDef))
    if itemPurchased or (requirePurchasedItems ~= 1) then
        log:log('Item "' .. objectDef .. '" was purchased OR non-purchased items are valid, so can be placed based on player votes (management phase)')
        table.insert(votableObjectDefinitions, objectDef )
        table.insert(votableDisplayNames, itemNameAndObjectDef.displayName )
    else
        log:log('Item "' .. objectDef .. '" was not purchased, and purchased items are required so it will not be part of management phase')
    end
end

owner.tags.addTag('ItemVoteManagement')
tags.addTag('ItemVoteManagement')

-- subscribe to get informed when game rounds start
game.bus.subscribe('gamePhase', onGamePhaseChanged)
game.bus.subscribe('controller.itemVoteResults', onItemVoteResults)
owner.bus.subscribe('state.MapObject', onMapObjectStateChanged)
