---@type Game
local game = LoadFacility('Game')['game']

local Log = require('Log')
local log = Log.new()

---@param message Message
local function onGamePhaseChanged(message)
    local phase = message.data.gamePhase
    if phase == nil then
		error('No phase data in gamePhase message!')
	end

    if phase == 'planning' or phase == 'acting' then
        -- Planning/acting: display turns
        game.bus.send({
            metadata = { 'connectedCharacterPlayersUI.update' },
            data = {
                displayType = 'turns',
                clearTurns = (phase == 'planning'),
                displayText = 'connectedCharacterPlayersPanel_planning'
            }
        }, nil, false)
    else
        -- All other phases: display nothing
        game.bus.send({
            metadata = { 'connectedCharacterPlayersUI.update' },
            data = {
                displayType = 'none',
            }
        }, nil, false)
    end

end

game.bus.subscribe('gamePhase', onGamePhaseChanged)
