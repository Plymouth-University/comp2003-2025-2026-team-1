-- Bring in the ability to subscribe to the GameManager's message bus for game phase changes
---@type Game
local game = LoadFacility('Game')['game']
---@type MapMobile
local owner = owner or error('No owner')

---@type SoundUtils
local SoundUtils = require('SoundUtils')

---@type number
local valueBeingDisplayed = -1

local addCounterLabelMsg = {
    metadata = { 'addCounterLabel' },
    data = { text = "scoreboard_hospitalFunds" }
}
local addCoinsCounterMsg = {
    metadata = { 'addCounter' },
    data = {
        counterName = 'coins',
        value = 0,
        displayType = 'valueOverlay'
    }
}
owner.bus.send(addCounterLabelMsg, nil, false)
owner.bus.send(addCoinsCounterMsg, nil, false)

---@param newBalance number
---@param delay number
---@param squashCounter boolean|nil
---@param moneySequence? table|nil
---@param originPos? V2|nil
---@param awaitAnimation? boolean|nil
local function updateCoinsDisplay(newBalance, delay, squashCounter, moneySequence, originPos, awaitAnimation)
    if newBalance == valueBeingDisplayed then
        -- Skip updating counter when value has not changed
        return
    end
    valueBeingDisplayed = newBalance

    local setCoinsCounterMsg = {
        metadata = { 'setCounter' },
        data = {
            counterName = 'coins',
            value = newBalance,
            delay = delay,
            originCounterEnterType = squashCounter and 'squash' or 'grow'
        }
    }
    if awaitAnimation ~= nil then
        setCoinsCounterMsg.data.awaitAnimation = awaitAnimation
    end
    if originPos ~= nil then
        -- Updating with an origin pos, i.e. floating counter appears at position before flying up to the scoreboard
        setCoinsCounterMsg.data.originPos = originPos
        -- Set values/icons to be shown on the floating coin
        setCoinsCounterMsg.data.valueSequence = {}
        for moneyVal in moneySequence do
            local iconName = ''
            if type(moneyVal) ~= 'number' then
                if tostring(moneyVal) == 'change' then
                    -- 'change' = just display 'giving change' icon with no text/value
                    iconName = 'givingChange'
                    moneyVal = ''
                else
                    iconName = 'coinsMultiplier'
                end
            end
            table.insert(
                setCoinsCounterMsg.data.valueSequence,
                { value = moneyVal, icon = iconName }
            )
        end
    end
    owner.bus.send(setCoinsCounterMsg, nil, false)

    if originPos ~= nil then
        -- Play coin sound after updating scoreboard with animation
        SoundUtils.playCoinSound()
    end
end

---@param message Message
local function onUpdateDisplayedBalance(message)
    local balance = message.data.balance
    if balance == nil then
        error("No 'balance' data in updateBalance message")
    end
    local delay = message.data.delay
    if delay == nil then
        delay = 0
    end
    updateCoinsDisplay(
        balance,
        delay,
        message.data.squash,
        message.data.moneyEarnedSequence,
        message.data.originPos,
        message.data.awaitAnimation
    )
end

---@param message Message
local function onGamePhaseChanged(message)
    local phase = message.data.gamePhase
	if phase == 'finished' then
		return
	end

	-- Hide coins display in management & management results phase
    if phase == 'management' or phase == 'managementResults' then
		owner.bus.send({ visible = false }, nil, false)
    else
        owner.bus.send({ visible = true }, nil, false)
    end
end

local balanceOnStart = game.saveData.getNumber('credit')
updateCoinsDisplay(balanceOnStart, 0)

owner.bus.subscribe('coinScoreboard.updateDisplayedBalance', onUpdateDisplayedBalance)
game.bus.subscribe('gamePhase', onGamePhaseChanged)
