﻿--- Include a delay per turn/action

---@type Game
local game = LoadFacility('Game')['game'] or error('No game')

---@type WaitActionHelper
local WaitActionHelper = require('WaitActionHelper')

---@type number
local delayPerTurn = delayPerTurn or 1000
---@type number
local delayPerTurnWaitOnly = delayPerTurnWaitOnly or 100

---@type number
local delayPerAction = delayPerAction or 1000
---@type number
local delayPerActionWaitOnly = delayPerActionWaitOnly or 100

local Log = require('Log')
local log = Log.new()

---@param message Message
local function onViewMode(message)
	local mode = message.data.viewMode
	if ("none" == mode) then
		print('Disabling delayPerTurn and delayPerAction when view absent.')
		delayPerTurn = 0
		delayPerTurnWaitOnly = 0
		delayPerAction = 0
		delayPerActionWaitOnly = 0
	end
end

---@param message Message
local function onTurnStart(message)
	local turnNumber = message.data.turnNumber
	local turnHasNonWaitAction = WaitActionHelper.doesTurnHaveNonWaitAction(turnNumber + 1)

	if turnHasNonWaitAction then
		log:log('Turn delay: ' .. delayPerTurn .. 'ms for turn ' .. turnNumber)
		waitMilliSeconds(delayPerTurn)
	else
		log:log('Turn delay (wait-only turn): ' .. delayPerTurnWaitOnly .. 'ms for turn ' .. turnNumber)
		waitMilliSeconds(delayPerTurnWaitOnly)
	end
	log:log('Turn delay: done for turn ' .. turnNumber)
end

---@param message Message
local function onPlayerActionStart(message)
	local turnNumber = message.data.turnNumber
	local playerNumber = message.data.playerNumber
	local turnHasNonWaitAction = WaitActionHelper.doesTurnHaveNonWaitAction(turnNumber + 1)

	if turnHasNonWaitAction then
		log:log('Action delay: ' .. delayPerAction .. 'ms for turn ' .. turnNumber .. ', player ' .. playerNumber)
		waitMilliSeconds(delayPerAction)
	else
		log:log('Action delay (wait-only turn): ' .. delayPerAction .. 'ms for turn ' .. turnNumber .. ', player ' .. playerNumber)
		waitMilliSeconds(delayPerActionWaitOnly)
	end
	log:log('Action delay: done for turn ' .. turnNumber.. ', player ' .. playerNumber)
end

game.bus.subscribe('viewMode', onViewMode)
game.bus.subscribe('turnStart', onTurnStart)
game.bus.subscribe('playerActionStart', onPlayerActionStart)
