---@type Game
local game = LoadFacility('Game')['game']

local Log = require('Log')
local log = Log.new()

---@type LevelStatsHelper
local LevelStatsHelper = require('LevelStatsHelper')

---@type string[]
local uniquePatientsCuredThisLevel = {}

---@param newRank number
local function setRankSaveData(newRank)
    game.saveData.setNumber(LevelStatsHelper.saveDataKey_rank(), newRank)
end

---@param levelNumber number
---@return number
local function getRequiredRankForLevelNumber(levelNumber)
    local requiredRank = game.saveData.getNumber('levelStat_rankRequirement_level' .. levelNumber)
    if requiredRank <= 0 then
        requiredRank = 1
    end
    return requiredRank
end

---@param levelNumber number
---@return boolean
local function doPlayersHaveHighEnoughRankToPlayLevel(levelNumber)
    local currentRank = LevelStatsHelper.getCurrentRank()
    local requiredRank = getRequiredRankForLevelNumber(levelNumber)
    return (currentRank >= requiredRank)
end

local function increaseRankOrProgressFromUniquePatientCure()
    local currentRank = LevelStatsHelper.getCurrentRank()
    local nextRank = currentRank + 1
    local requiredUniqueCuresForNextRank = game.saveData.getNumber(LevelStatsHelper.saveDataKey_uniqueCuresRequiredForRank(nextRank))

    if requiredUniqueCuresForNextRank <= 0 then
        return
    end

    local uniqueCuresSaveDataKey = LevelStatsHelper.saveDataKey_uniqueCuresForCurrentRank()
    local uniqueCuresSoFar = game.saveData.getNumber(uniqueCuresSaveDataKey)
    local newUniqueCures = uniqueCuresSoFar + 1
    if newUniqueCures >= requiredUniqueCuresForNextRank then
        -- Next rank requirement was reached - rank up!
        setRankSaveData(nextRank)
        -- Reset unique cures counter for new rank
        game.saveData.setNumber(uniqueCuresSaveDataKey, 0)
    else
        -- Add to unique patient cures counter
        game.saveData.setNumber(uniqueCuresSaveDataKey, newUniqueCures)
    end
end

local function unlockLevelsBasedOnRank()
    for levelNum = 1, game.totalNumberOfLevels, 1 do
        if doPlayersHaveHighEnoughRankToPlayLevel(levelNum) then
            game.saveData.setNumber(LevelStatsHelper.saveDataKey_levelUnlocked(levelNum), 1)
        else
            -- Reached a level that should remain locked - assume all subsequent levels should also be locked
            break
        end
    end
end

---@param message Message
local function onPatientBeingCured(message)
    local curedPatientName = message.data.patientName
    if curedPatientName == nil then
        error('patient.curing message with no patientName data')
    end

    local uniquePatientCureForLevelKey = LevelStatsHelper.saveDataKey_uniquePatientCureForLevel(curedPatientName)
    if game.saveData.getNumber(uniquePatientCureForLevelKey) <= 0 then
        -- The patient was never cured in the current level before, so it should count towards the next rank upgrade!
        table.insert(uniquePatientsCuredThisLevel, curedPatientName)
    end
end

---@param numPatientsCured number
---@param numPatientsAtStart number
local function setPatientsSeenAndCuredLevelStatSaveData(numPatientsCured, numPatientsAtStart)
	local startingPlayerCount = game.startingCharacterPlayerCount
	local curedPatientScoreKey = LevelStatsHelper.saveDataKey_curedPatientScore(startingPlayerCount)
	local currentBestCureScoreForLevel = game.saveData.getNumber(curedPatientScoreKey)
	if numPatientsCured <= currentBestCureScoreForLevel and currentBestCureScoreForLevel > 0 then
		-- Players already completed the current level with a greater number of patients cured, so no need to update stat
		return
	end

	local patientsSeenKey = LevelStatsHelper.saveDataKey_patientsSeen(startingPlayerCount)

	-- Set save data for num. patients cured, and the number present at start
	game.saveData.setNumber(curedPatientScoreKey, numPatientsCured)
	game.saveData.setNumber(patientsSeenKey, numPatientsAtStart)

	-- Also set save data for the stat text displayed on the level select screen
	local curedPatientStatKey = 'levelStat_curedPatientText_' .. startingPlayerCount .. 'players_level' .. game.levelNumber
	local curedPatientStatText
	if numPatientsCured >= numPatientsAtStart then
		-- All patients cured!
		curedPatientStatText = '<color=#00FDB0>' .. numPatientsAtStart .. '/' .. numPatientsAtStart .. '</color>'
	elseif numPatientsCured > 0 then
		-- At least one, but not all patients cured!
		curedPatientStatText = '<color=#EEAA31>' .. numPatientsCured .. '/' .. numPatientsAtStart .. '</color>'
	else
		-- No patients cured!
		curedPatientStatText = '<color=#FF7456>0/' .. numPatientsAtStart .. '</color>'
	end
	game.saveData.setString(curedPatientStatKey, curedPatientStatText)
end

---@param message Message
local function onLevelCompleted(message)
    local numPatientsCured = message.data.patientsCured
    if numPatientsCured == nil then
        error('No patientsCured data in level.won/level.lost message')
    end
    local numPatientsAtStart = message.data.patientsTotal
    if numPatientsAtStart == nil then
        error('No patientsTotal data in level.won/level.lost message')
    end

    -- Level completed! i.e. all patients cured and/or left
    -- Set save data for 'patients cured' stats displayed in the level selector
    setPatientsSeenAndCuredLevelStatSaveData(numPatientsCured, numPatientsAtStart)

    -- Set 'unique patient cured' save data so we'll know in the future which patient(s) were already cured at least once in this level
    for _, patientName in ipairs(uniquePatientsCuredThisLevel) do
        local uniquePatientCureForLevelKey = LevelStatsHelper.saveDataKey_uniquePatientCureForLevel(patientName)
        game.saveData.setNumber(uniquePatientCureForLevelKey, 1)
        -- For each unique patient that was cured, increase progress towards the next rank
        increaseRankOrProgressFromUniquePatientCure()
        -- Check/set save data for which levels are unlocked
    end
    unlockLevelsBasedOnRank()
    -- (game.saveData.save() will be called by the GameManager script after this)
end

game.bus.subscribe('patient.curing', onPatientBeingCured)
game.bus.subscribe('level.won', onLevelCompleted)
game.bus.subscribe('level.lost', onLevelCompleted)
