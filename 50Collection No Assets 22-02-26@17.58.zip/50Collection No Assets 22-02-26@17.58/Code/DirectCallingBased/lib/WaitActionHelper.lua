---Helper functions for setting and checking if/how players should wait on a turn

-- local Log = require('Log')
-- local log = Log.new()

---@type Game
local game = LoadFacility('Game')['game']

---@class WaitActionHelper
local WaitActionHelper = {}

---@param playerNumber number
---@param turnNumber1Based number
function WaitActionHelper.setSpecialWaitPlayerAndTurnNumber(playerNumber, turnNumber1Based)
    game.saveData.setNumber('specialWait_playerNumber', playerNumber)
    game.saveData.setNumber('specialWait_turnNumber', turnNumber1Based)
end

function WaitActionHelper.getSpecialWaitPlayerNumber()
    return game.saveData.getNumber('specialWait_playerNumber')
end

function WaitActionHelper.getSpecialWaitTurnNumber()
    return game.saveData.getNumber('specialWait_turnNumber')
end

---@param turnNumber1Based number
---@param hasNonWaitAction boolean
function WaitActionHelper.setTurnHasNonWaitAction(turnNumber1Based, hasNonWaitAction)
    game.saveData.setNumber('turnHasNonWaitAction_' .. turnNumber1Based, (hasNonWaitAction and 1 or 0))
end

---@param turnNumber1Based number
---@return boolean
function WaitActionHelper.doesTurnHaveNonWaitAction(turnNumber1Based)
    return (game.saveData.getNumber('turnHasNonWaitAction_' .. turnNumber1Based) > 0)
end

return WaitActionHelper