---Utilities for squashing

---@type Game
local game = LoadFacility('Game')['game']

---@class SquashHelper
local SquashHelper = {}

---@param owner MapObject
---@param tag string
---@param funcName string
---@return boolean
local function callFuncOnAllWithTagAtOwnerPos(owner, tag, funcName)
    local objectsWithTag = owner.map.getAllTagged(owner.gridPosition, tag)
    local anyFunctionCalled = false
    for objectWithTag in objectsWithTag do
        -- Don't call func on self!
        if objectWithTag ~= owner then
            if objectWithTag.hasFunc(funcName) then
                -- 2024-07-30: Using objectWithTag.callAction(funcName) would cause strange behaviour where the
                -- function would also get called on owner. Replaced with below, which causes squashing unit tests to pass.
                objectWithTag[funcName]()
                anyFunctionCalled = true
            else
                print("No '" .. funcName .. "' found on " .. tostring(objectWithTag))
            end
        end
    end
    return anyFunctionCalled
end

---@param owner MapObject
---@param soundUtils SoundUtils
function SquashHelper.squashSquashablesAtOwnerPosition(owner, soundUtils)
    -- Call squash() on all MapObjects tagged as 'squashable' on the same tile as the owner MapObject
    if callFuncOnAllWithTagAtOwnerPos(owner, 'squashable', 'squash') then
        -- Play sound when something is squashed
        soundUtils.playSquashSound()
    end
end

---@param owner MapObject
function SquashHelper.respawnSquashedAtOwnerPosition(owner)
    -- Call respawnFromSquashed() on all MapObjects tagged as 'squashed' on the same tile as the owner MapObject
    callFuncOnAllWithTagAtOwnerPos(owner, 'squashed', 'respawnFromSquashed')
end

return SquashHelper
