---@type Game
local game = LoadFacility('Game')['game']

---@class AchievementsHelper
local AchievementsHelper = {}

--- 'Good Job! | Heal all the patients in Ward 1'
function AchievementsHelper.unlockHealAllWard1Achievement()
    game.bus.send({ 'achievement.healAllWard1' }, nil, false)
end

--- 'Ed's Friend! | Heal Ed Banger in 2 different wards'
function AchievementsHelper.unlockHealEdIn2WardsAchievement()
    game.bus.send({ 'achievement.healEdIn2Wards' }, nil, false)
end

--- 'Training Complete! | Play all the way through Wards 1 and 2'
function AchievementsHelper.unlockCompleteWards1And2Achievement()
    game.bus.send({ 'achievement.completeWards1And2' }, nil, false)
end

--- 'Reliable Volunteers | Play all the way through Ward 4'
function AchievementsHelper.unlockCompleteWard4Achievement()
    game.bus.send({ 'achievement.completeWard4' }, nil, false)
end

--- 'Hot Potato | Make 5 successful catches'
function AchievementsHelper.unlockCatch5TimesAchievement()
    game.bus.send({ 'achievement.catch5Times' }, nil, false)
end

--- 'The Defenestrator | Throw something or someone out of a window'
function AchievementsHelper.unlockDefenestrateAchievement()
    game.bus.send({ 'achievement.defenestrate' }, nil, false)
end

--- 'The Explorer | Bump into something'
function AchievementsHelper.unlockBumpIntoSomethingAchievement()
    game.bus.send({ 'achievement.bumpIntoSomething' }, nil, false)
end

--- 'You're in Safe(ish) Hands | Pick up a patient'
function AchievementsHelper.unlockCarryPatientAchievement()
    game.bus.send({ 'achievement.carryPatient' }, nil, false)
end

--- 'Expert at Waiting | Perform a special animation while waiting'
function AchievementsHelper.unlockSpecialWaitAchievement()
    game.bus.send({ 'achievement.specialWait' }, nil, false)
end

--- 'The Upgrader | Buy an item in the shop'
function AchievementsHelper.unlockPurchaseItemAchievement()
    game.bus.send({ 'achievement.purchaseItem' }, nil, false)
end

--- 'Great Shot! | Heal a patient who needs a syringe'
function AchievementsHelper.unlockHealWithSyringeAchievement()
    game.bus.send({ 'achievement.healWithSyringe' }, nil, false)
end

--- 'Red Pill or Blue Pill? | Heal a patient who needs pills'
function AchievementsHelper.unlockHealWithPillsAchievement()
    game.bus.send({ 'achievement.healWithPills' }, nil, false)
end

--- 'Firm but Fair | Push a player or patient into the next tile'
function AchievementsHelper.unlockPushPlayerOrPatientAchievement()
    game.bus.send({ 'achievement.pushPlayerOrPatient' }, nil, false)
end

--- 'Ice Ice Baby | Finish any ward in chilled mode'
function AchievementsHelper.unlockCompleteWardChilledAchievement()
    game.bus.send({ 'achievement.completeWardChilled' }, nil, false)
end

--- 'Efficiency Master | Throw, catch and heal all in the same round'
function AchievementsHelper.unlockCatchAndHealAchievement()
    game.bus.send({ 'achievement.catchAndHeal' }, nil, false)
end

--- 'I Like to Move It Move It! | Make your team walk over 200 tiles'
function AchievementsHelper.unlockWalkOver200TilesAchievement()
    game.bus.send({ 'achievement.walkOver200Tiles' }, nil, false)
end

--- 'Great Job! | Heal all the patients in Ward 5'
function AchievementsHelper.unlockHealAllWard5Achievement()
    game.bus.send({ 'achievement.healAllWard5' }, nil, false)
end

--- 'Cammy's Carer | Heal Cammy in 2 different wards'
function AchievementsHelper.unlockHealCammyIn2WardsAchievement()
    game.bus.send({ 'achievement.healCammyIn2Wards' }, nil, false)
end

--- 'Committed Volunteers | Play all the way through Ward 8'
function AchievementsHelper.unlockCompleteWard8Achievement()
    game.bus.send({ 'achievement.completeWard8' }, nil, false)
end

--- 'Really Hot Potato | Make 25 successful catches'
function AchievementsHelper.unlockCatch25TimesAchievement()
    game.bus.send({ 'achievement.catch25Times' }, nil, false)
end

--- 'Do You Even Lift? Yes, Yes You Do | Pick up patients 20 times'
function AchievementsHelper.unlockCarryPatient20TimesAchievement()
    game.bus.send({ 'achievement.carryPatient20Times' }, nil, false)
end

--- 'Big Spender | Withdraw a 100-coin from the ATM in the shop'
function AchievementsHelper.unlockWithdrawA100CoinAchievement()
    game.bus.send({ 'achievement.withdrawA100Coin' }, nil, false)
end

--- 'An Apple a Day... | Heal a patient who needs something healthy'
function AchievementsHelper.unlockHealWithAppleAchievement()
    game.bus.send({ 'achievement.healWithApple' }, nil, false)
end

--- 'The Teleporter | Get squashed by a falling patient'
function AchievementsHelper.unlockSquashedByPatientAchievement()
    game.bus.send({ 'achievement.squashedByPatient' }, nil, false)
end

--- 'Excellent Job! | Heal all the patients in Ward 9'
function AchievementsHelper.unlockHealAllWard9Achievement()
    game.bus.send({ 'achievement.healAllWard9' }, nil, false)
end

--- 'Olivia's Helper | Heal Olivia in 2 different wards'
function AchievementsHelper.unlockHealOliviaIn2WardsAchievement()
    game.bus.send({ 'achievement.healOliviaIn2Wards' }, nil, false)
end

--- 'Dedicated Volunteers | Play all the way through Ward 12'
function AchievementsHelper.unlockCompleteWard12Achievement()
    game.bus.send({ 'achievement.completeWard12' }, nil, false)
end

--- 'Honey I Shrunk the... | Shrink something with the Shrink-Prod'
function AchievementsHelper.unlockShrinkSomethingAchievement()
    game.bus.send({ 'achievement.shrinkSomething' }, nil, false)
end

--- 'World's Tallest Volunteer | Throw a shrunken item'
function AchievementsHelper.unlockThrowShrunkenItemAchievement()
    game.bus.send({ 'achievement.throwShrunkenItem' }, nil, false)
end

--- 'Master Tactician | Throw a bed after shrinking it with the Shrink-Prod'
function AchievementsHelper.unlockThrowShrunkenBedAchievement()
    game.bus.send({ 'achievement.throwShrunkenBed' }, nil, false)
end

--- 'The Absolute Hottest Potato | Make 50 successful catches'
function AchievementsHelper.unlockCatch50TimesAchievement()
    game.bus.send({ 'achievement.catch50Times' }, nil, false)
end

--- 'Master Upgrader | Buy 5 items from the shop'
function AchievementsHelper.unlockPurchase5TimesAchievement()
    game.bus.send({ 'achievement.purchase5Times' }, nil, false)
end

return AchievementsHelper