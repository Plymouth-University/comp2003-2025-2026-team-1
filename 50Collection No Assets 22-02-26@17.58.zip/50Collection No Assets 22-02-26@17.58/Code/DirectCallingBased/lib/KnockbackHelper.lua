local V2 = require('Vector')

---@class KnockbackHelper
local KnockbackHelper = {}

---@param objectBeingHit MapMobile
---@param direction DirectionName
---@param soundUtils SoundUtils
---@param achievementsHelper AchievementsHelper
---@return boolean --- Whether objectBeingHit was knocked into the next tile
function KnockbackHelper.hitObject(objectBeingHit, direction, soundUtils, achievementsHelper)
    if objectBeingHit == nil then
        return false
    end
    if not objectBeingHit.tags.hasTag('knockbackTarget') then
        return false
    end
    if owner.map.getFirstTagged(objectBeingHit.gridPosition, 'bed') ~= nil then
        -- Don't allow things in bed (patients, presumably) to be knocked
        return false
    end
    if objectBeingHit.tags.hasTag('patient') and owner.map.getFirstTagged(objectBeingHit.gridPosition, 'player') ~= nil then
        -- Don't knock patients in the same tile as a player (i.e. being carried) -
        --  only the player should be knocked, and the carried patient will follow
        return false
    end

    objectBeingHit.setFacing(direction)

    local nextTilePos = V2.new(objectBeingHit.gridPosition) + V2.directionNameToVector(direction)

    local mapObjsToKnockback = owner.map.getAllTagged(nextTilePos, 'knockbackTarget')
    for knockbackObject in mapObjsToKnockback do
        if knockbackObject.typeName == 'MapMobile' then
            objectBeingHit.bus.send({
                metadata = { 'knockback.knockedChained' },
                data = { direction = owner.facing }
            }, nil, false)
            KnockbackHelper.hitObject(knockbackObject--[[@as MapMobile]], owner.facing, soundUtils, achievementsHelper)
            return false
        end
    end

    -- An object cannot be knocked into something that blocksMove
	local noMoveBlocker = owner.map.getFirstTagged(nextTilePos, 'blocksMove') == nil
    -- An object cannot be knocked into something shrunk, UNLESES the object being knocked
    --  is a player, since players are allowed to occupy the same tile as something shrunk
	local noShrunkBlocker = (owner.map.getFirstTagged(nextTilePos, 'shrunk') == nil or objectBeingHit.tags.hasTag('player'))
    -- An object can only be knocked into a tile with floor
	local hasFloor = owner.map.getFirstTagged(nextTilePos, 'floor') ~= nil
	if noMoveBlocker and noShrunkBlocker and hasFloor then
        -- Knock object into next tile!
        soundUtils.playKnockbackSound()
        objectBeingHit.bus.send({
            metadata = { 'knockback.knockedIntoNextTile' },
            data = { direction = owner.facing }
        }, nil, false)
        objectBeingHit.repositionTo(nextTilePos)
        if objectBeingHit.tags.hasTag('patient') or objectBeingHit.tags.hasTag('player') then
            -- Unlock achievement! Push player or patient into next tile
            achievementsHelper.unlockPushPlayerOrPatientAchievement()
        end
        return true
	end

    -- Knocked but no tile to move into, and no other knockbackTarget to chain the knock forwards
    objectBeingHit.bus.send({
        metadata = { 'knockback.knockedAndBlocked' },
        data = { direction = owner.facing }
    }, nil, false)
    return false
end

return KnockbackHelper
