---@type Game
local game = LoadFacility('Game')['game']

---@class SoundUtils
local SoundUtils = {}

-- Players & movement
-- ==================

---@param doMultipleSteps boolean
function SoundUtils.playWalkingSound(doMultipleSteps)
    if doMultipleSteps then
        -- Play first sound immediately
        game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'Footstep_Wood_Run' }}, false)
        -- Schedule second sound with delay
        game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'Footstep_Wood_Run', delay = 0.25 }}, false)
        -- Schedule third sound with delay
        game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'Footstep_Wood_Run', delay = 0.5 }}, false)
    else
        game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'Footstep_Wood_Run' }}, false)
    end
end

function SoundUtils.playSquashSound()
    game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'Squash', delay = 0.75 } }, false)
end

function SoundUtils.playKnockbackSound()
    game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'PushedA' } }, false)
    game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'PushedB', delay = 0.05 } }, false)
end

---@param delay number|nil
function SoundUtils.playPickUpPillsSound(delay)
    if delay == nil then
        delay = 0
    end
    game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'PickUpPills', delay = delay } }, false)
end
---@param delay number|nil
function SoundUtils.playPickUpSyringeSound(delay)
    if delay == nil then
        delay = 0
    end
    game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'PickUpSyringe', delay = delay } }, false)
end
---@param delay number|nil
function SoundUtils.playPickUpAppleSound(delay)
    if delay == nil then
        delay = 0
    end
    game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'PickUpApple', delay = delay } }, false)
end

function SoundUtils.playDropPillsSound()
    game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'DropPills' } }, false)
end
function SoundUtils.playDropSyringeSound()
    game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'DropSyringe' } }, false)
end
function SoundUtils.playDropAppleSound()
    game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'DropApple' } }, false)
end
function SoundUtils.playDropPatientSound()
    game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'DropPatient' } }, false)
end

function SoundUtils.playThrowSound()
    game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'Throw' } }, false)
end

function SoundUtils.playSpringSound()
    game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'BushSpring' } }, false)
end

function SoundUtils.playInvalidActionSound()
    game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'InvalidAction' } }, false)
end

---@param characterName string
---@param carryable Carryable
function SoundUtils.playCarryingSound(characterName, carryable)
    if carryable.owner == nil then
        return
    end
    if carryable.owner.tags.hasTag('pills') then
        -- Play sound for picking up pills
        SoundUtils.playPickUpPillsSound()
    elseif carryable.owner.tags.hasTag('syringe') then
        -- Play sound for picking up syringes
        SoundUtils.playPickUpSyringeSound()
    elseif carryable.owner.tags.hasTag('apple') then
        -- Play sound for picking up apples
        SoundUtils.playPickUpAppleSound()
    elseif carryable.owner.tags.hasTag('coin') then
        -- Play sound for picking up coins
        SoundUtils.playCoinSound()
    elseif carryable.owner.tags.hasTag('patient') then
        -- Play sound for picking up patients
        -- Check if patient was in a bed
        local bed = carryable.owner.map.getFirstTagged(carryable.owner.gridPosition, 'Bed')
        if bed ~= nil then
            -- Play curtain sound when patient is picked up from bed
            SoundUtils.playCurtainsSound()
        else
            -- Only play character-specific sounds when picking up from floor
            if characterName == 'player_footballerJason' then
                game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'PickUpPatient_Jason' } }, false)
            elseif characterName == 'player_clownEthan' then
                game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'PickUpPatient_Ethan' } }, false)
            elseif characterName == 'player_athleteTamira' then
                game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'PickUpPatient_Tamira' } }, false)
            elseif characterName == 'player_chefPrisha' then
                game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'PickUpPatient_Prisha' } }, false)
            end
        end
    end
end

-- Patients & health
-- =================

function SoundUtils.playPatientSpawnSound()
    game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'PatientSpawn' } }, false)
end

function SoundUtils.playPatientHurtSound()
    -- Add random delay between 0 and 0.4 seconds to prevent sound overlap
    local randomDelay = math.random() * 0.4
    game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'PatientHurt', delay = randomDelay }}, nil, false)
end

function SoundUtils.playPatientHitWallSound()
    game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'PatientHitWall' } }, false)
end

---@param remedy string
function SoundUtils.playHealingSound(remedy)
    if remedy == 'apple' then
        game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'HealApple', delay = 0.25 }}, false)
    elseif remedy == 'syringe' then
        game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'HealSyringe', delay = 0.25 }}, false)
    elseif remedy == 'pill' then
        game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'HealPills', delay = 0.25 }}, false)
    end
end

function SoundUtils.playEndOfRoundSound()
    game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'EndOfRound' } }, nil, false)
end

function SoundUtils.playPatientExitSound()
    -- Play clock sound, then door close sound when patient dies/leaves
    game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'Clock' }}, false)
    game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'DoorClose', delay = 2.1 }}, false)
end

-- Beds & clipboards
-- =================

function SoundUtils.playBedSpawnSound()
    game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'BedSpawn' } }, false)
end

function SoundUtils.playInBedSound()
    game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'InBed', delay = 2 }}, false)
end

---@param delay number|nil
function SoundUtils.playCurtainsSound(delay)
    if delay == nil then
        delay = 0
    end
    game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'Curtains', delay = delay }}, false)
end

function SoundUtils.playClipboardSound()
    game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'Clipboard', delay = 0.9 }}, false)
end

-- Purchasing items/voting
-- =======================

function SoundUtils.playItemSpawnSound()
    game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'ItemSpawn', delay = 0.2 } }, false)
end

function SoundUtils.playBuySound()
    game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'Buy' } }, false)
    game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'BuyB', delay = 0.3 } }, false)
end
function SoundUtils.playBuyFastSound()
    game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'BuyFast', delay = 0.3 } }, false)
end

---@param delay number|nil
function SoundUtils.playCoinSound(delay)
    if delay == nil then
        delay = 0
    end
    game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'Coin', delay = delay } }, false)
end

function SoundUtils.playMoneySound()
    game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'Money', delay = 1 }}, false)
end

-- UI & misc.
-- ==========

function SoundUtils.playNotificationSound()
    game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'Notification' } }, false)
end

function SoundUtils.playShrinkProdZapSound()
    game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'ShrinkProdZap' } }, false)
end

return SoundUtils