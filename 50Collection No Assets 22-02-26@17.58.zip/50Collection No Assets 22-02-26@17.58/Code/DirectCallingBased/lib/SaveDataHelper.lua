---@type Game
local game = LoadFacility('Game')['game']

---@class SaveDataHelper
local SaveDataHelper = {}

---@return number
function SaveDataHelper.getSavedTurnsPerRoundOrDefault()
	local selectedTurnsPerRound = game.saveData.getNumber('turnsPerRound')
    if selectedTurnsPerRound <= 0 then
        selectedTurnsPerRound = 4
    end
    return selectedTurnsPerRound
end

return SaveDataHelper
