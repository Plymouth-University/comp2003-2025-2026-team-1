---@type Game
local game = LoadFacility('Game')['game']

---@class LevelStatsHelper
local LevelStatsHelper = {}

---@return string
function LevelStatsHelper.saveDataKey_rank()
    return 'levelStat_rank'
end

---@param patientName string
---@return string
function LevelStatsHelper.saveDataKey_uniquePatientCureForLevel(patientName)
    return 'levelStat_patientCured_' .. patientName .. '_level' .. game.levelNumber
end

---@param levelNumber number
---@return string
function LevelStatsHelper.saveDataKey_levelUnlocked(levelNumber)
    return 'levelStat_levelUnlocked_level' .. levelNumber
end

---@param rankNumber number
---@return string
function LevelStatsHelper.saveDataKey_uniqueCuresRequiredForRank(rankNumber)
    return 'levelStat_uniqueCuresRankRequirement_rank' .. rankNumber
end

---@return string
function LevelStatsHelper.saveDataKey_uniqueCuresForCurrentRank()
    return 'levelStat_uniqueCuresForCurrentRank'
end

---@param numPlayers number
---@return string
function LevelStatsHelper.saveDataKey_curedPatientScore(numPlayers)
    return 'levelStat_curedPatientScore_' .. numPlayers .. 'players_level' .. game.levelNumber
end
---@param numPlayers number
---@return string
function LevelStatsHelper.saveDataKey_patientsSeen(numPlayers)
    return 'levelStat_patientsSeen_' .. numPlayers .. 'players_level' .. game.levelNumber
end

---@return number
function LevelStatsHelper.getCurrentRank()
    local rank = game.saveData.getNumber(LevelStatsHelper.saveDataKey_rank())
    if rank <= 0 then
        rank = 1
    end
    return rank
end

---@param levelNumber number
---@return boolean
function LevelStatsHelper.isLevelAtEndOfWorld(levelNumber)
    return (
        levelNumber == 4
        or levelNumber == 8
        or levelNumber == 12
        or levelNumber == 16
    )
end

return LevelStatsHelper