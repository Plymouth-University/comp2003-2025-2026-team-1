﻿---Utilities for carrying
---
local Vector = require('Vector')

---@type DirectionUtils
local DirectionUtils = require('DirectionUtils')

local Log = require('Log')
local log = Log.new()

---@type Game
local game = LoadFacility('Game')['game']

---@type Loader
local loader = game.loader or error('No loader')

---@class CarryHelper
local CarryHelper = {}

---Check if space in front is clear for placing an item, without actually placing it.
---@param carryingOwner MapMobile
---@return boolean
function CarryHelper.isSpaceClearInFront(carryingOwner)
    -- If there is empty floor with nothing blocking us, space is clear
    local noMoveBlocker = carryingOwner.getFirstFacingObjectTagged('blocksMove') == nil
    -- (Shrunk things don't block movement, but do not allow things to be placed on top of them, to prevent e.g. multiple beds/cabinets in a single tile)
    local noShrunkObject = carryingOwner.getFirstFacingObjectTagged('shrunk') == nil
    local hasFloor = carryingOwner.getFirstFacingObjectTagged('floor') ~= nil
    return noMoveBlocker and noShrunkObject and hasFloor
end

---Place down the currently carried item in the direction and return whether succeeded.
---@param carryingOwner MapMobile
---@param carrier Carrier
---@param direction DirectionName
---@param alwaysAllowPos Vector|nil
---@return boolean
function CarryHelper.placeDownIfClearInFront(carryingOwner, carrier, direction, alwaysAllowPos)
	---@type Vector
	local dropPos = Vector.new(carryingOwner.gridPosition) + Vector.directionNameToVector(direction)
	if alwaysAllowPos ~= nil and (dropPos[1] == alwaysAllowPos[1] and dropPos[2] == alwaysAllowPos[2]) then
		return carrier.endCarry(dropPos) -- success or not
	end

	if CarryHelper.isSpaceClearInFront(carryingOwner) then
		return carrier.endCarry(dropPos) -- success or not
	end

	return false
end

---Place down the currently carried item on carrier's position and return whether succeeded.
---@param carrier Carrier
---@return boolean
function CarryHelper.endCarryWithoutPlacing(carrier)
	return carrier.endCarry()
end

---Attempt to get the carrier at the given position (or nil).
---@param position Pos
---@return Carrier|nil
function CarryHelper.getCarrierAtPosition(position)
	local carrierObjs = owner.map.getAllTagged(position, 'carrier')
	for carrierObj in carrierObjs do
		local carrierComp = carrierObj.getFirstComponentTagged('carrier')
		if carrierComp ~= nil then
			return carrierComp
		end
	end
	return nil
end

---Cease carrying by passing it to the supplied 'acceptor'.
---@param carrier Carrier
---@param acceptorMapObject MapObject @ Should have an acceptor component which accepts the item currently carried.
---@return boolean
function CarryHelper.endIntoAcceptorMapObject(carrier, acceptorMapObject)
	if acceptorMapObject.hasFunc('canAccept') then
		if not acceptorMapObject.callFunc('canAccept', owner) then
			return false
		end
	end
	if acceptorMapObject.tags.hasTag('player') and carrier.owner ~= nil then
		-- Turn receiving player to face the acting/carrying one
		local receiveDirection = DirectionUtils.opposite(carrier.owner.facing)
		acceptorMapObject.setFacing(receiveDirection)
	end
	local acceptor = acceptorMapObject.getFirstComponentTagged('acceptor')
	assert(nil ~= acceptor, "No acceptor on " .. tostring(acceptorMapObject))
	return carrier.endCarryInto(acceptor)
end

---For certain carryable objects, instantiates & returns a replacement with its
--- art3d position reset to (0, 0, 0) for better visual placement in the player's hand
---@param originalCarryable Carryable
---@return Carryable
function CarryHelper.cloneAndPositionForCarryingIfRequired(originalCarryable)
	if not originalCarryable.owner.tags.hasTag('medicine or shrinkRay or coin') then
		-- Only medicine, shrinkRay and coins are replaced/repositioned, other objects are
		--	left alone to preserve their state (e.g. patients, shrunk objects etc.)
        return originalCarryable
    end

	originalCarryable.owner.bus.send({ 'destroyingBeforeCloning' }, nil, false)

	if not loader.hasObject(originalCarryable.owner.name) then
		log:warn('No definition found for \'' .. originalCarryable.owner.name .. '\', returning original instead of cloning')
		return originalCarryable
	end
	-- Get the LevelObject definition of the MapObject to be carried, so we can make tweaks to it
	local levelObjToClone = loader.getDefinition(originalCarryable.owner.name)

	if levelObjToClone.art3d == nil or #levelObjToClone.art3d == 0 then
		-- LevelObject has no Art3d, so there are no adjustments needed
		return originalCarryable
	end

	levelObjToClone.name = originalCarryable.owner.name
	-- Reset position of the first Art3D on the object to (0, 0, 0),
	-- and use that offset to adjust the relative positions of any other Art3Ds
	local xOffset = 0; local yOffset = 0; local zOffset = 0;
	for i, art in ipairs(levelObjToClone.art3d) do
		if i == 1 then
			xOffset = art.pos.x or 0
			yOffset = art.pos.y or 0
			zOffset = art.pos.z or 0
		end
		if art.pos ~= nil then
			art.pos = {
				x = (art.pos.x or 0) - xOffset,
				y = (art.pos.y or 0) - yOffset,
				z = (art.pos.z or 0) - zOffset
			}
		end
		if art.rot ~= nil and levelObjToClone.name == 'shrinkRay' then
			-- shrinkRay: also reset z rotation
			art.rot = {
				x = (art.rot.x or 0),
				y = (art.rot.y or 0),
				z = 0
			}
		end
	end
	-- animationMappings cause error when instantiating, remove them as not needed when carrying
	-- TODO 2024-06-05: See why animationMappings cause an issue
	levelObjToClone.animationMappings = nil

	-- Instantiate the replacement, and destroy the original which is no longer needed
	local replacementObj = loader.instantiate(levelObjToClone, originalCarryable.owner.gridPosition)
	local replacementCarryable = replacementObj.getFirstComponentTagged('carryable')
	originalCarryable.owner.destroyObject()
	return replacementCarryable
end

return CarryHelper
