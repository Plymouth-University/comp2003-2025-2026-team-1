---@type Game
local game = LoadFacility('Game')['game']
---@type Loader
local loader = game.loader or error('No loader')

local Log = require('Log')
local log = Log.new()

---@class CameraTargetHelper
local CameraTargetHelper = {}

---@param mapObject MapObject -- Object tagged as 'cameraTarget' to enable as target.
function CameraTargetHelper.enableCameraTargetFor(mapObject)
    mapObject.bus.send({ ['cameraTarget.enabled'] = true }, nil, false)
end

---@param mapObject MapObject -- Object tagged as 'cameraTarget' to disable as target.
function CameraTargetHelper.disableCameraTargetFor(mapObject)
    mapObject.bus.send({ ['cameraTarget.enabled'] = false }, nil, false)
end

---@param gridPosition Pos -- Position to spawn the blank cameraTarget object.
function CameraTargetHelper.addPlaceholderCameraTarget(gridPosition)
    loader.instantiate('blankCameraTarget', gridPosition)
end

---@param gridPosition Pos -- Position to find and destroy a previouly added blank cameraTarget object.
---@return boolean
function CameraTargetHelper.tryRemovePlaceholderCameraTarget(gridPosition)
    ---@type MapObject|nil
    local targetAtPos = game.map.getFirstTagged(gridPosition, 'blankCameraTarget')
    if targetAtPos == nil then
        log:warn('No object tagged as "blankCameraTarget" to remove at (' .. gridPosition[1] .. ', ' .. gridPosition[2] .. ')')
        return false
    end
    targetAtPos.destroyObject()
    return true
end

return CameraTargetHelper
