-- Bring in the ability to subscribe to the GameManager's message bus for game phase changes
local game = LoadFacility('Game')['game']
---@type Loader
local loader = game.loader or error('No loader')

---@type LevelStatsHelper
local LevelStatsHelper = require('LevelStatsHelper')

local Log = require('Log')
local log = Log.new()

---@type number
local lastCompletedLevelNumber
---@type boolean
local shouldContinueToLevelSelect
---@type boolean
local firstPlanningPhaseDone

log:log('LevelResults lua script started')

-- Play 'Menu' music in results levels
game.bus.send({ metadata = { 'playMusic' }, data = { soundName = 'MenuMusic' } }, false)

-- Get saved values from the level that was just played
local patientsDied = game.saveData.getNumber('patientsDied')
local patientsCured = game.saveData.getNumber('patientsCured')
local totalPatients = patientsDied + patientsCured

-- Display some text in the UI letting players know the number of patients cured, and how to continue
game.bus.send({
	displayText = 'shop_patientStatsAndInfo',
	textArguments = { tostring(patientsCured), tostring(totalPatients) },
	displayType = 'messageDisplayUI.topLeft'
}, nil, false)

-- Also show some info on the 'ticker' that displays scrolling text
game.bus.send({displayText = '- Move to make your choice. Majority wins! -', displayType = 'ticker'}, nil, false)

local function continueToNextLevelOrReturnToLevelSelect()
	if shouldContinueToLevelSelect then
		-- End level and return to level selection
		game.bus.send({ 'level.exitToSelector' })
	else
		log:log('Loading next level')
		local nextLevelNumber = lastCompletedLevelNumber + 1
		game.bus.send({ metadata = { 'level.load' }, data = { levelNumber = nextLevelNumber } })
	end
end

local function replaceNextLevelDecalsWithStatsDecals()
	local nextLevelDecals = owner.map.getAllObjectsTagged('NextLevel')
	---@type MapObject[]
	local nextLevelDecalsArray = {}
	for decal in nextLevelDecals do
		table.insert(nextLevelDecalsArray, decal)
	end
	for _, nextLevelDecal in ipairs(nextLevelDecalsArray) do
		loader.instantiate('levelStatsDecal', nextLevelDecal.gridPosition)
		nextLevelDecal.destroyObject()
	end
end

---@param message Message
local function onGamePhaseChanged(message)
	local phase = message.data.gamePhase;
	if phase ~= 'planning' then
        return
    end

	if not firstPlanningPhaseDone then
		if shouldContinueToLevelSelect then
			-- Switch 'next level' decals with 'see stats' ones
			--	(doing here in the first planning phase rather than on start,
			--	so we don't try to destroy objects before they're initialised)
			replaceNextLevelDecalsWithStatsDecals()
		end
		firstPlanningPhaseDone = true
	end

	log:log('LevelResults - planning phase: Checking player positions')

	local nextLevelVotes = 0
	local replayLevelVotes = 0
	local players = owner.map.getAllObjectsTagged('player')

	for player in players do
		if owner.map.getFirstTagged(player.gridPosition, 'NextLevel') ~= nil then
			nextLevelVotes = nextLevelVotes + 1
		elseif owner.map.getFirstTagged(player.gridPosition, 'ReplayLevel') ~= nil then
			replayLevelVotes = replayLevelVotes + 1
		end
	end

	if nextLevelVotes > (game.characterPlayerCount / 2) then
		log:log('Majority of players want to continue to next level/level selection')
		continueToNextLevelOrReturnToLevelSelect()
	elseif replayLevelVotes > (game.characterPlayerCount / 2) then
		log:log('Majority of players want to replay - loading previous level')
		game.bus.send({ metadata = { 'level.load' }, data = { levelNumber = lastCompletedLevelNumber } })
	end
end

-- MAIN

lastCompletedLevelNumber = game.saveData.getNumber('lastCompletedLevelNumber')

local playedFinalLevel = lastCompletedLevelNumber >= (game.totalNumberOfLevels - 1)
local playedEndOfWorldLevel = LevelStatsHelper.isLevelAtEndOfWorld(lastCompletedLevelNumber)
shouldContinueToLevelSelect = (playedEndOfWorldLevel or playedFinalLevel)

-- subscribe to get informed when game rounds start
game.bus.subscribe('gamePhase', onGamePhaseChanged)
