Mod code in this directory.
Sub-directories as needed.
"DirectCallingBased" is one style of of Lua API we are considering.
In it, the Lua code makes simple-looking direct calls to the platform API and other mods and the framework handles using messaging or asynchronous calls transparently.
