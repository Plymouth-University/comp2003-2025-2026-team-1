local SharedNarrativeConditions = require('SharedNarrativeConditions')

local Log = require('Log')
local log = Log.new()

---@type MapMobile
local owner = owner or error('No owner')

-- FUNCTIONS REQUIRED BY NARRATIVECHARACTER
-- ========================================

--- Called externally by NarrativeCharacter
---@param levelNumber number
---@param specialCondition string
---@return table|nil
function getSpecialConditionLevelChapters(levelNumber, specialCondition)
    return nil
end

--- Called externally by NarrativeCharacter
---@return table|nil
function getAllNarrativeArcChapters()
    return nil
end

--- Name of the character, used in keys for character-related narrative save data
--- and for getting localized character name from string table
--- Called externally by NarrativeCharacter
---@return string
function getCharacterName()
    return 'player_athleteTamira'
end

--- Called externally by NarrativeCharacter
--- See: SharedNarrativeConditions.chapterWasAlreadyShown
---@param chapterId string
---@return boolean
function chapterWasAlreadyShown(chapterId)
    return SharedNarrativeConditions.chapterWasAlreadyShown(getCharacterName(), chapterId)
end

--- Called externally by NarrativeCharacter
--- See: SharedNarrativeConditions.setChapterAsShown
---@param chapterId string
function setChapterAsShown(chapterId)
    SharedNarrativeConditions.setChapterAsShown(getCharacterName(), chapterId)
end

-- FUNCTIONS REQUIRED BY NARRATIVEMANAGER
-- =======================================

--- Called externally by NarrativeManager
---@return boolean
function canPlayersWriteForCharacter()
    -- Yes, writer players can write text for me!
    return true
end

-- ========================================

tags.addTag('CharacterNarrativeConditions')
owner.tags.addTag('CharacterNarrativeConditions')

log:log('AthleteNarrativeConditions lua started')
