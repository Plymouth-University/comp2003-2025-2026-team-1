---@type Game
local game = LoadFacility('Game')['game']

local SharedNarrativeConditions = require('SharedNarrativeConditions')

local SaveDataKeys = SharedNarrativeConditions.saveDataKeys()

local Log = require('Log')
local log = Log.new()

---@type MapMobile
local owner = owner or error('No owner')

local character = character or error('Expected character data to be set for patient ' .. tostring(owner))

---@type boolean
local placedInBedThisRound = false
---@type boolean
local pickedUpThisRound = false
---@type number
local roundNumber = 0

-- GRACE ARC 1 (PEOPLE-PLEASER) SPEECH CONDITIONS
-- ==============================================

--- Given wrong medicine,
--- OR thrown but not caught,
--- OR thrown out of window,
--- OR hit by object,
--- OR not picked up & <60% health
---@return table
local function grace_arc1Chapter1Conditions()
    local chapterId = 'arc1_chapter1'
    local mostRecentAdministerWrongPatient = game.saveData.getString(SaveDataKeys.global_mostRecentAdministerWrongPatient())
    local mostRecentDroppedPatient = game.saveData.getString(SaveDataKeys.global_mostRecentDroppedPatient())
    local mostRecentDefenestratedPatient = game.saveData.getString(SaveDataKeys.global_mostRecentDefenestratedPatient())
    local mostRecentHitPatient = game.saveData.getString(SaveDataKeys.global_mostRecentHitPatient())

    if (SharedNarrativeConditions.playerAdministeredWrongInLastRound()) and (mostRecentAdministerWrongPatient == character) then
        -- Grace was given wrong medicine during the last round
        local administeringPlayer = game.saveData.getString(SaveDataKeys.global_mostRecentAdministerWrongPlayer())
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_grace_arc1_chapter1_option1_a', args = { administeringPlayer } },
                { text = 'speech_grace_arc1_chapter1_option2_a', args = { administeringPlayer } },
                { text = 'speech_grace_arc1_chapter1_option3_a', args = { administeringPlayer } },
                { text = 'speech_grace_arc1_chapter1_option4_a', args = { administeringPlayer } }
            }
        }
    elseif (SharedNarrativeConditions.playerDefenestratedPatientInLastRound()) and (mostRecentDefenestratedPatient == character) then
        -- Grace was thrown out of a window during the last round
        local throwingPlayer = game.saveData.getString(SaveDataKeys.global_mostRecentWindowThrowPlayer())
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_grace_arc1_chapter1_option1_c', args = { throwingPlayer } },
                { text = 'speech_grace_arc1_chapter1_option2_c', args = { throwingPlayer } },
                { text = 'speech_grace_arc1_chapter1_option3_c', args = { throwingPlayer } },
                { text = 'speech_grace_arc1_chapter1_option4_c', args = { throwingPlayer } }
            }
        }
    elseif (SharedNarrativeConditions.playerDroppedPatientInLastRound()) and (mostRecentDroppedPatient == character) then
        -- Grace was thrown but not caught during the last round
        local droppingPlayer = game.saveData.getString(SaveDataKeys.global_mostRecentPatientDropPlayer())
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_grace_arc1_chapter1_option1_b', args = { droppingPlayer } },
                { text = 'speech_grace_arc1_chapter1_option2_b', args = { droppingPlayer } },
                { text = 'speech_grace_arc1_chapter1_option3_b', args = { droppingPlayer } },
                { text = 'speech_grace_arc1_chapter1_option4_b', args = { droppingPlayer } }
            }
        }
    elseif (SharedNarrativeConditions.playerHitPatientWithThrownObjectInLastRound() and (mostRecentHitPatient == character)) then
        -- Grace was hit by a thrown object during the last round
        local throwingPlayer = game.saveData.getString(SaveDataKeys.global_mostRecentThrowAndHitPlayer())
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_grace_arc1_chapter1_option1_d', args = { throwingPlayer } },
                { text = 'speech_grace_arc1_chapter1_option2_d', args = { throwingPlayer } },
                { text = 'speech_grace_arc1_chapter1_option3_d', args = { throwingPlayer } },
                { text = 'speech_grace_arc1_chapter1_option4_d', args = { throwingPlayer } }
            }
        }
    elseif (not SharedNarrativeConditions.patientHasEverBeenCarried(owner)) and (SharedNarrativeConditions.patientHealthLessThanPercentage(owner, 0.6)) then
        -- Grace has not been attended to
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_grace_arc1_chapter1_option1_e' },
                { text = 'speech_grace_arc1_chapter1_option2_e' },
                { text = 'speech_grace_arc1_chapter1_option3_e' },
                { text = 'speech_grace_arc1_chapter1_option4_e' }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

--- Given wrong medicine,
--- OR thrown but not caught,
--- OR thrown out of window,
--- OR hit by object,
--- OR not picked up & <60% health
---@return table
local function grace_arc1Chapter2Conditions()
    local chapterId = 'arc1_chapter2'
    local mostRecentAdministerWrongPatient = game.saveData.getString(SaveDataKeys.global_mostRecentAdministerWrongPatient())
    local mostRecentDroppedPatient = game.saveData.getString(SaveDataKeys.global_mostRecentDroppedPatient())
    local mostRecentDefenestratedPatient = game.saveData.getString(SaveDataKeys.global_mostRecentDefenestratedPatient())
    local mostRecentHitPatient = game.saveData.getString(SaveDataKeys.global_mostRecentHitPatient())

    if (SharedNarrativeConditions.playerAdministeredWrongInLastRound()) and (mostRecentAdministerWrongPatient == character) then
        -- Grace was given wrong medicine during the last round
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_grace_arc1_chapter2_option1_a' },
                { text = 'speech_grace_arc1_chapter2_option2_a' },
                { text = 'speech_grace_arc1_chapter2_option3_a' },
                { text = 'speech_grace_arc1_chapter2_option4_a' }
            }
        }
    elseif (SharedNarrativeConditions.playerDefenestratedPatientInLastRound()) and (mostRecentDefenestratedPatient == character) then
        -- Grace was thrown out of a window during the last round
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_grace_arc1_chapter2_option1_c' },
                { text = 'speech_grace_arc1_chapter2_option2_c' },
                { text = 'speech_grace_arc1_chapter2_option3_c' },
                { text = 'speech_grace_arc1_chapter2_option4_c' }
            }
        }
    elseif (SharedNarrativeConditions.playerDroppedPatientInLastRound()) and (mostRecentDroppedPatient == character) then
        -- Grace was thrown but not caught during the last round
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_grace_arc1_chapter2_option1_b' },
                { text = 'speech_grace_arc1_chapter2_option2_b' },
                { text = 'speech_grace_arc1_chapter2_option3_b' },
                { text = 'speech_grace_arc1_chapter2_option4_b' }
            }
        }
    elseif (SharedNarrativeConditions.playerHitPatientWithThrownObjectInLastRound() and (mostRecentHitPatient == character)) then
        -- Grace was hit by a thrown object during the last round
        local objectThatHit = game.saveData.getString(SaveDataKeys.global_mostRecentPatientHittingObject())
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_grace_arc1_chapter2_option1_d', args = { objectThatHit } },
                { text = 'speech_grace_arc1_chapter2_option2_d', args = { objectThatHit } },
                { text = 'speech_grace_arc1_chapter2_option3_d', args = { objectThatHit } },
                { text = 'speech_grace_arc1_chapter2_option4_d', args = { objectThatHit } }
            }
        }
    elseif (not SharedNarrativeConditions.patientHasEverBeenCarried(owner)) and (SharedNarrativeConditions.patientHealthLessThanPercentage(owner, 0.6)) then
        -- Grace has not been attended to
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_grace_arc1_chapter2_option1_e' },
                { text = 'speech_grace_arc1_chapter2_option2_e' },
                { text = 'speech_grace_arc1_chapter2_option3_e' },
                { text = 'speech_grace_arc1_chapter2_option4_e' }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

--- Any character picked up,
--- OR any character thrown,
--- OR any object shrunk
---@return table
local function grace_arc1Chapter3Conditions()
    local chapterId = 'arc1_chapter3'
    if (SharedNarrativeConditions.patientPickedUpInLastRound()) or (SharedNarrativeConditions.patientThrownInLastRound()) or (SharedNarrativeConditions.objectShrunkInLastRound()) then
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_grace_arc1_chapter3_option1' },
                { text = 'speech_grace_arc1_chapter3_option2' },
                { text = 'speech_grace_arc1_chapter3_option3' },
                { text = 'speech_grace_arc1_chapter3_option4' }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

--- Given wrong medicine,
--- OR thrown but not caught,
--- OR thrown out of window,
--- OR hit by object,
--- OR not picked up & <60% health
---@return table
local function grace_arc1Chapter4Conditions()
    local chapterId = 'arc1_chapter4'
    local mostRecentAdministerWrongPatient = game.saveData.getString(SaveDataKeys.global_mostRecentAdministerWrongPatient())
    local mostRecentDroppedPatient = game.saveData.getString(SaveDataKeys.global_mostRecentDroppedPatient())
    local mostRecentDefenestratedPatient = game.saveData.getString(SaveDataKeys.global_mostRecentDefenestratedPatient())
    local mostRecentHitPatient = game.saveData.getString(SaveDataKeys.global_mostRecentHitPatient())

    if (SharedNarrativeConditions.playerAdministeredWrongInLastRound()) and (mostRecentAdministerWrongPatient == character) then
        -- Grace was given wrong medicine during the last round
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_grace_arc1_chapter4_option1_a' },
                { text = 'speech_grace_arc1_chapter4_option2_a' },
                { text = 'speech_grace_arc1_chapter4_option3_a' },
                { text = 'speech_grace_arc1_chapter4_option4_a' }
            }
        }
    elseif (SharedNarrativeConditions.playerDefenestratedPatientInLastRound()) and (mostRecentDefenestratedPatient == character) then
        -- Grace was thrown out of a window during the last round
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_grace_arc1_chapter4_option1_c' },
                { text = 'speech_grace_arc1_chapter4_option2_c' },
                { text = 'speech_grace_arc1_chapter4_option3_c' },
                { text = 'speech_grace_arc1_chapter4_option4_c' }
            }
        }
    elseif (SharedNarrativeConditions.playerDroppedPatientInLastRound()) and (mostRecentDroppedPatient == character) then
        -- Grace was thrown but not caught during the last round
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_grace_arc1_chapter4_option1_b' },
                { text = 'speech_grace_arc1_chapter4_option2_b' },
                { text = 'speech_grace_arc1_chapter4_option3_b' },
                { text = 'speech_grace_arc1_chapter4_option4_b' }
            }
        }
    elseif (SharedNarrativeConditions.playerHitPatientWithThrownObjectInLastRound() and (mostRecentHitPatient == character)) then
        -- Grace was hit by a thrown object during the last round
        local objectThatHit = game.saveData.getString(SaveDataKeys.global_mostRecentPatientHittingObject())
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_grace_arc1_chapter4_option1_d', args = { objectThatHit } },
                { text = 'speech_grace_arc1_chapter4_option2_d', args = { objectThatHit } },
                { text = 'speech_grace_arc1_chapter4_option3_d', args = { objectThatHit } },
                { text = 'speech_grace_arc1_chapter4_option4_d', args = { objectThatHit } }
            }
        }
    elseif (not SharedNarrativeConditions.patientHasEverBeenCarried(owner)) and (SharedNarrativeConditions.patientHealthLessThanPercentage(owner, 0.6)) then
        -- Grace has not been attended to
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_grace_arc1_chapter4_option1_e' },
                { text = 'speech_grace_arc1_chapter4_option2_e' },
                { text = 'speech_grace_arc1_chapter4_option3_e' },
                { text = 'speech_grace_arc1_chapter4_option4_e' }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

--- Any character picked up,
--- OR any character thrown,
--- OR any object shrunk
---@return table
local function grace_arc1Chapter5Conditions()
    local chapterId = 'arc1_chapter5'
    if (SharedNarrativeConditions.patientPickedUpInLastRound()) or (SharedNarrativeConditions.patientThrownInLastRound()) or (SharedNarrativeConditions.objectShrunkInLastRound()) then
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_grace_arc1_chapter5_option1' },
                { text = 'speech_grace_arc1_chapter5_option2' },
                { text = 'speech_grace_arc1_chapter5_option3' },
                { text = 'speech_grace_arc1_chapter5_option4' }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

-- GRACE ARC 2 (NO CAREER PATHWAY) SPEECH CONDITIONS
-- =================================================

--- Level 1 completed AND placed in bed
---@return table
local function grace_arc2Chapter1Conditions()
    local chapterId = 'arc2_chapter1'
    if (SharedNarrativeConditions.levelHasBeenPlayedThrough(1, game.levelNumber)) and placedInBedThisRound then
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_grace_arc2_chapter1_option1' },
                { text = 'speech_grace_arc2_chapter1_option2' },
                { text = 'speech_grace_arc2_chapter1_option3' },
                { text = 'speech_grace_arc2_chapter1_option4' }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

--- Level 1 completed AND placed in bed
---@return table
local function grace_arc2Chapter2Conditions()
    local chapterId = 'arc2_chapter2'
    if (SharedNarrativeConditions.levelHasBeenPlayedThrough(1, game.levelNumber)) and placedInBedThisRound then
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_grace_arc2_chapter2_option1' },
                { text = 'speech_grace_arc2_chapter2_option2' },
                { text = 'speech_grace_arc2_chapter2_option3' },
                { text = 'speech_grace_arc2_chapter2_option4' }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

--- Level 2 completed AND (placed in bed OR picked up)
---@return table
local function grace_arc2Chapter3Conditions()
    local chapterId = 'arc2_chapter3'
    if (SharedNarrativeConditions.levelHasBeenPlayedThrough(2, game.levelNumber)) and (placedInBedThisRound or pickedUpThisRound) then
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_grace_arc2_chapter3_option1' },
                { text = 'speech_grace_arc2_chapter3_option2' },
                { text = 'speech_grace_arc2_chapter3_option3' },
                { text = 'speech_grace_arc2_chapter3_option4' }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

--- Level 2 completed AND (placed in bed OR picked up)
---@return table
local function grace_arc2Chapter4Conditions()
    local chapterId = 'arc2_chapter4'
    if (SharedNarrativeConditions.levelHasBeenPlayedThrough(2, game.levelNumber)) and (placedInBedThisRound or pickedUpThisRound) then
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_grace_arc2_chapter4_option1' },
                { text = 'speech_grace_arc2_chapter4_option2' },
                { text = 'speech_grace_arc2_chapter4_option3' },
                { text = 'speech_grace_arc2_chapter4_option4' }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

--- Level 3 completed AND (placed in bed OR picked up)
---@return table
local function grace_arc2Chapter5Conditions()
    local chapterId = 'arc2_chapter5'
    if (SharedNarrativeConditions.levelHasBeenPlayedThrough(3, game.levelNumber)) and (placedInBedThisRound or pickedUpThisRound) then
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_grace_arc2_chapter5_option1' },
                { text = 'speech_grace_arc2_chapter5_option2' },
                { text = 'speech_grace_arc2_chapter5_option3' },
                { text = 'speech_grace_arc2_chapter5_option4' }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

-- SAMMI ARC 1 (NEED TO STUDY/REST) SPEECH CONDITIONS
-- ==================================================

--- Picked up OR placed in bed, AND level 1 played through
---@return table
local function sammi_arc1Chapter1Conditions()
    local chapterId = 'arc1_chapter1'
    local level1Played = SharedNarrativeConditions.levelHasBeenPlayedThrough(1, game.levelNumber)
    if (placedInBedThisRound or pickedUpThisRound) and level1Played then
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_sammi_arc1_chapter1_option1' },
                { text = 'speech_sammi_arc1_chapter1_option2' },
                { text = 'speech_sammi_arc1_chapter1_option3' },
                { text = 'speech_sammi_arc1_chapter1_option4' }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

--- Picked up OR placed in bed, AND level 2 played through
---@return table
local function sammi_arc1Chapter2Conditions()
    local chapterId = 'arc1_chapter2'
    local level2Played = SharedNarrativeConditions.levelHasBeenPlayedThrough(2, game.levelNumber)
    if (placedInBedThisRound or pickedUpThisRound) and level2Played then
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_sammi_arc1_chapter2_option1' },
                { text = 'speech_sammi_arc1_chapter2_option2' },
                { text = 'speech_sammi_arc1_chapter2_option3' },
                { text = 'speech_sammi_arc1_chapter2_option4' }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

--- Any player waited for at least 1 turn AND level 2 played through
---@return table
local function sammi_arc1Chapter3Conditions()
    local chapterId = 'arc1_chapter3'
    local level2Played = SharedNarrativeConditions.levelHasBeenPlayedThrough(2, game.levelNumber)
    if SharedNarrativeConditions.playerWaitedInLastRound() and level2Played then
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_sammi_arc1_chapter3_option1' },
                { text = 'speech_sammi_arc1_chapter3_option2' },
                { text = 'speech_sammi_arc1_chapter3_option3' },
                { text = 'speech_sammi_arc1_chapter3_option4' }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

--- Picked up OR placed in bed, AND level 3 played through
---@return table
local function sammi_arc1Chapter4Conditions()
    local chapterId = 'arc1_chapter4'
    local level3Played = SharedNarrativeConditions.levelHasBeenPlayedThrough(3, game.levelNumber)
    if (placedInBedThisRound or pickedUpThisRound) and level3Played then
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_sammi_arc1_chapter4_option1' },
                { text = 'speech_sammi_arc1_chapter4_option2' },
                { text = 'speech_sammi_arc1_chapter4_option3' },
                { text = 'speech_sammi_arc1_chapter4_option4' }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

--- Picked up OR placed in bed, AND level 3 played through
---@return table
local function sammi_arc1Chapter5Conditions()
    local chapterId = 'arc1_chapter5'
    local level3Played = SharedNarrativeConditions.levelHasBeenPlayedThrough(3, game.levelNumber)
    if (placedInBedThisRound or pickedUpThisRound) and level3Played then
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_sammi_arc1_chapter5_option1' },
                { text = 'speech_sammi_arc1_chapter5_option2' },
                { text = 'speech_sammi_arc1_chapter5_option3' },
                { text = 'speech_sammi_arc1_chapter5_option4' }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

-- SAMMI ARC 2 (CO OPERATION LOOKS FUN) SPEECH CONDITIONS
-- ======================================================

--- Picked up OR placed in bed, AND level 3 played through
---@return table
local function sammi_arc2Chapter1Conditions()
    local chapterId = 'arc2_chapter1'
    local level3Played = SharedNarrativeConditions.levelHasBeenPlayedThrough(3, game.levelNumber)
    if (placedInBedThisRound or pickedUpThisRound) and level3Played then
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_sammi_arc2_chapter1_option1' },
                { text = 'speech_sammi_arc2_chapter1_option2' },
                { text = 'speech_sammi_arc2_chapter1_option3' },
                { text = 'speech_sammi_arc2_chapter1_option4' }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

--- Picked up OR placed in bed, AND level 3 played through
---@return table
local function sammi_arc2Chapter2Conditions()
    local chapterId = 'arc2_chapter2'
    local level3Played = SharedNarrativeConditions.levelHasBeenPlayedThrough(3, game.levelNumber)
    if (placedInBedThisRound or pickedUpThisRound) and level3Played then
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_sammi_arc2_chapter2_option1' },
                { text = 'speech_sammi_arc2_chapter2_option2' },
                { text = 'speech_sammi_arc2_chapter2_option3' },
                { text = 'speech_sammi_arc2_chapter2_option4' }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

--- Any object caught, AND level 4 played through
---@return table
local function sammi_arc2Chapter3Conditions()
    local chapterId = 'arc2_chapter3'
    local level4Played = SharedNarrativeConditions.levelHasBeenPlayedThrough(4, game.levelNumber)
    if SharedNarrativeConditions.playerCaughtInLastRound() and level4Played then
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_sammi_arc2_chapter3_option1' },
                { text = 'speech_sammi_arc2_chapter3_option2' },
                { text = 'speech_sammi_arc2_chapter3_option3' },
                { text = 'speech_sammi_arc2_chapter3_option4' }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

--- Picked up OR placed in bed, AND level 4 played through
---@return table
local function sammi_arc2Chapter4Conditions()
    local chapterId = 'arc2_chapter4'
    local level4Played = SharedNarrativeConditions.levelHasBeenPlayedThrough(4, game.levelNumber)
    if (placedInBedThisRound or pickedUpThisRound) and level4Played then
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_sammi_arc2_chapter4_option1' },
                { text = 'speech_sammi_arc2_chapter4_option2' },
                { text = 'speech_sammi_arc2_chapter4_option3' },
                { text = 'speech_sammi_arc2_chapter4_option4' }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

--- Picked up OR placed in bed, AND level 5 played through
---@return table
local function sammi_arc2Chapter5Conditions()
    local chapterId = 'arc2_chapter5'
    local level5Played = SharedNarrativeConditions.levelHasBeenPlayedThrough(5, game.levelNumber)
    if (placedInBedThisRound or pickedUpThisRound) and level5Played then
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_sammi_arc2_chapter5_option1' },
                { text = 'speech_sammi_arc2_chapter5_option2' },
                { text = 'speech_sammi_arc2_chapter5_option3' },
                { text = 'speech_sammi_arc2_chapter5_option4' }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

-- SPAWN TEXT
-- ==========

local function spawnChapter1()
    return {
        conditionsMet = true,
        id = 'spawn_chapter1',
        speech = { { text = 'speech_' .. character .. '_spawn_chapter1' } }
    }
end
local function spawnChapter2()
    return {
        conditionsMet = true,
        id = 'spawn_chapter2',
        speech = { { text = 'speech_' .. character .. '_spawn_chapter2' } }
    }
end
local function spawnChapter3()
    return {
        conditionsMet = true,
        id = 'spawn_chapter3',
        speech = { { text = 'speech_' .. character .. '_spawn_chapter3' } }
    }
end
local function spawnChapter4()
    return {
        conditionsMet = true,
        id = 'spawn_chapter4',
        speech = { { text = 'speech_' .. character .. '_spawn_chapter4' } }
    }
end
local function spawnChapter5()
    return {
        conditionsMet = true,
        id = 'spawn_chapter5',
        speech = { { text = 'speech_' .. character .. '_spawn_chapter5' } }
    }
end
local function spawnChapter6()
    return {
        conditionsMet = true,
        id = 'spawn_chapter6',
        speech = { { text = 'speech_' .. character .. '_spawn_chapter6' } }
    }
end
local function spawnChapter7()
    return {
        conditionsMet = true,
        id = 'spawn_chapter7',
        speech = { { text = 'speech_' .. character .. '_spawn_chapter7' } }
    }
end
local function spawnChapter8()
    return {
        conditionsMet = true,
        id = 'spawn_chapter8',
        speech = { { text = 'speech_' .. character .. '_spawn_chapter8' } }
    }
end
local function spawnChapter9()
    return {
        conditionsMet = true,
        id = 'spawn_chapter9',
        speech = { { text = 'speech_' .. character .. '_spawn_chapter9' } }
    }
end
local function spawnChapter10()
    return {
        conditionsMet = true,
        id = 'spawn_chapter10',
        speech = { { text = 'speech_' .. character .. '_spawn_chapter10' } }
    }
end

-- CURE TEXT
-- =========

local function cureChapter1()
    return {
        conditionsMet = true,
        id = 'cure_chapter1',
        speech = { { text = 'speech_' .. character .. '_cure_chapter1' } }
    }
end
local function cureChapter2()
    return {
        conditionsMet = true,
        id = 'cure_chapter2',
        speech = { { text = 'speech_' .. character .. '_cure_chapter2' } }
    }
end
local function cureChapter3()
    return {
        conditionsMet = true,
        id = 'cure_chapter3',
        speech = { { text = 'speech_' .. character .. '_cure_chapter3' } }
    }
end
local function cureChapter4()
    return {
        conditionsMet = true,
        id = 'cure_chapter4',
        speech = { { text = 'speech_' .. character .. '_cure_chapter4' } }
    }
end
local function cureChapter5()
    return {
        conditionsMet = true,
        id = 'cure_chapter5',
        speech = { { text = 'speech_' .. character .. '_cure_chapter5' } }
    }
end
local function cureChapter6()
    return {
        conditionsMet = true,
        id = 'cure_chapter6',
        speech = { { text = 'speech_' .. character .. '_cure_chapter6' } }
    }
end
local function cureChapter7()
    return {
        conditionsMet = true,
        id = 'cure_chapter7',
        speech = { { text = 'speech_' .. character .. '_cure_chapter7' } }
    }
end
local function cureChapter8()
    return {
        conditionsMet = true,
        id = 'cure_chapter8',
        speech = { { text = 'speech_' .. character .. '_cure_chapter8' } }
    }
end
local function cureChapter9()
    return {
        conditionsMet = true,
        id = 'cure_chapter9',
        speech = { { text = 'speech_' .. character .. '_cure_chapter9' } }
    }
end
local function cureChapter10()
    return {
        conditionsMet = true,
        id = 'cure_chapter10',
        speech = { { text = 'speech_' .. character .. '_cure_chapter10' } }
    }
end

-- FUNCTIONS REQUIRED BY NARRATIVECHARACTER
-- ========================================

--- Called externally by NarrativeCharacter
---@param levelNumber number
---@param specialCondition string
---@return table|nil
function getSpecialConditionLevelChapters(levelNumber, specialCondition)
    if specialCondition == 'spawn' then
        return {
            spawnChapter1,
            spawnChapter2,
            spawnChapter3,
            spawnChapter4,
            spawnChapter5,
            spawnChapter6,
            spawnChapter7,
            spawnChapter8,
            spawnChapter9,
            spawnChapter10
        }
    elseif specialCondition == 'cure' then
        return {
            cureChapter1,
            cureChapter2,
            cureChapter3,
            cureChapter4,
            cureChapter5,
            cureChapter6,
            cureChapter7,
            cureChapter8,
            cureChapter9,
            cureChapter10
        }
    end
end

--- Called externally by NarrativeCharacter
---@return table|nil
function getAllNarrativeArcChapters()
    if character == 'grace' then
        return {
            -- Grace Arc 1
            {
                grace_arc1Chapter1Conditions,
                grace_arc1Chapter2Conditions,
                grace_arc1Chapter3Conditions,
                grace_arc1Chapter4Conditions,
                grace_arc1Chapter5Conditions
            },
            -- Grace Arc 2
            {
                grace_arc2Chapter1Conditions,
                grace_arc2Chapter2Conditions,
                grace_arc2Chapter3Conditions,
                grace_arc2Chapter4Conditions,
                grace_arc2Chapter5Conditions
            }
        }
    elseif character =='sammi' then
        return {
            -- Sammi Arc 1
            {
                sammi_arc1Chapter1Conditions,
                sammi_arc1Chapter2Conditions,
                sammi_arc1Chapter3Conditions,
                sammi_arc1Chapter4Conditions,
                sammi_arc1Chapter5Conditions
            },
            -- Sammi Arc 2
            {
                sammi_arc2Chapter1Conditions,
                sammi_arc2Chapter2Conditions,
                sammi_arc2Chapter3Conditions,
                sammi_arc2Chapter4Conditions,
                sammi_arc2Chapter5Conditions
            }
        }
    end
    return nil
end

--- Name of the character, used in keys for character-related narrative save data
--- and for getting localized character name from string table
--- Called externally by NarrativeCharacter
---@return string
function getCharacterName()
    return character
end

--- Called externally by NarrativeCharacter
--- See: SharedNarrativeConditions.chapterWasAlreadyShown
---@param chapterId string
---@return boolean
function chapterWasAlreadyShown(chapterId)
    return SharedNarrativeConditions.chapterWasAlreadyShown(getCharacterName(), chapterId)
end

--- Called externally by NarrativeCharacter
--- See: SharedNarrativeConditions.setChapterAsShown
---@param chapterId string
function setChapterAsShown(chapterId)
    SharedNarrativeConditions.setChapterAsShown(getCharacterName(), chapterId)
end

-- FUNCTIONS REQUIRED BY NARRATIVEMANAGER
-- =======================================

--- Called externally by NarrativeManager
---@return boolean
function canPlayersWriteForCharacter()
    -- Yes, writer players can write text for me!
    return true
end

-- ========================================

local function onGamePhaseChanged(message)
    local phase = message.data.gamePhase
    if phase == nil then
        error('no phase in gamePhase message')
    end
    if phase == 'acting' then
        placedInBedThisRound = false
        pickedUpThisRound = false
    elseif phase == 'planning' then
        roundNumber = roundNumber + 1
    end
end

---@param message Message
local function onPatientStateChanged(message)
    local newState = message.data['state.patient']
    if newState == nil then
        error('nil state in state.patient message')
    end
    if (newState == 'InBed') and (roundNumber > 1) then
        -- Patient was placed in bed, and this isn't the 1st round
        -- (To prevent conditional dialogue being valid on level start)
        placedInBedThisRound = true
    end
end

---@param _ Message
local function onCarried(_)
    pickedUpThisRound = true
end

tags.addTag('CharacterNarrativeConditions')
owner.tags.addTag('CharacterNarrativeConditions')

log:log('LegacyPatientNarrativeConditions lua started (character: ' .. tostring(character) .. '')

game.bus.subscribe('gamePhase', onGamePhaseChanged)
owner.bus.subscribe('state.patient', onPatientStateChanged)
owner.bus.subscribe('carried', onCarried)
