---@type Game
local game = LoadFacility('Game')['game']

---@type Time
local time = LoadFacility('Time')
local getTimeSeconds = time['getUnixTime']

---@type NarrativeSaveDataKeys
local NarrativeSaveDataKeys = require('NarrativeSaveDataKeys')
---@type SaveDataHelper
local SaveDataHelper = require('SaveDataHelper')
---@type SoundUtils
local SoundUtils = require('SoundUtils')

local Log = require('Log')
local log = Log.new()

---@type MapMobile
local owner = owner or error('No owner')

---@type number
local playerNarrativeTextCount = 0
---@type number
local mostRecentPlayerNarrativeMsgTime = -1
---@type number
local minPlayerMessageDisplayTime = minPlayerMessageDisplayTime or 0

--- Wait at least (value) rounds between showing narrative arc dialogue chapters
---@type number
local minSpeechInterval = minSpeechInterval or 1
---@type number
local roundsSinceSpeechDisplayed = 0

--- Earliest level number where narrative arc text can be displayed
---@type number
local firstNarrativeArcLevel = firstNarrativeArcLevel or 2

---@type boolean
local firstPlanningPhasePassed = false
---@type boolean
local checkedSpawnTextThisRound = false

local function clearRoundSpecificNarrativeSaveData()
    local keys = NarrativeSaveDataKeys.getAllKeysToClearOnNewRound()
    for key in keys do
        log:log('Deleting round-specific save data with key "' .. key .. '"')
        game.saveData.delete(key)
    end
end

local function clearLevelSpecificNarrativeSaveData()
    local keys = NarrativeSaveDataKeys.getAllKeysToClearOnNewLevel()
    for key in keys do
        log:log('Deleting level-specific save data with key "' .. key .. '"')
        game.saveData.delete(key)
    end
end

---@return MapObject[]
local function getActiveCharactersThatCanBeWrittenFor()
    local allNarrativeCharacters = owner.map.getAllObjectsTagged('NarrativeCharacter')
    local charactersArray = {}
    for narrativeCharacterObj in allNarrativeCharacters do
        if narrativeCharacterObj['canPlayersWriteForCharacter'] ~= nil then --narrativeCharacterObj.hasFunc('canPlayersWriteForCharacter')
            if narrativeCharacterObj['canPlayersWriteForCharacter']() then --narrativeCharacterObj.callFunc('canPlayersWriteForCharacter')
                local hasIsActiveFunc = (narrativeCharacterObj['isActive'] ~= nil) --narrativeCharacterObj.hasFunc('isActive')
                if (hasIsActiveFunc and narrativeCharacterObj['isActive']()) or (not hasIsActiveFunc) then -- narrativeCharacterObj.callFunc('isActive')
                    table.insert(charactersArray, narrativeCharacterObj)
                end
            else
                log:log('MapObject with NarrativeCharacter returned false for canPlayersWriteForCharacter(), so writer players cannot write for them: ' .. tostring(narrativeCharacterObj))
            end
        else
            log:error('MapObject tagged as NarrativeCharacter does not have expected canPlayersWriteForCharacter() function: ' .. tostring(narrativeCharacterObj))
        end
    end
    return charactersArray
end

---@param characterMapObjs MapObject[]
---@return string[]
local function getInternalCharacterNamesFromNarrativeCharacters(characterMapObjs)
    local characterNames = {}
    for narrativeCharacterObj in characterMapObjs do
        if narrativeCharacterObj['getCharacterName'] ~= nil then --narrativeCharacterObj.hasFunc('getCharacterName')
            table.insert(characterNames, narrativeCharacterObj['getCharacterName']()) --narrativeCharacterObj.callFunc('getCharacterName')
        else
            log:error('MapObject tagged as NarrativeCharacter does not have expected getCharacterName() function: ' .. tostring(narrativeCharacterObj))
        end
    end
    return characterNames
end

local function sendNarrativeCharactersDataToControllers()
    local activeNarrativeCharacters = getActiveCharactersThatCanBeWrittenFor()
    local characterNames = getInternalCharacterNamesFromNarrativeCharacters(activeNarrativeCharacters)

    game.bus.send({
        metadata = { 'narrativeCharacters.dataForControllers' },
        data = {
            characterInternalNames = characterNames
        }
    }, nil, false)
end

--- Find any characters who want to say something from one of their narrative arcs,
--- and randomly choose one (if any are found) to actually display their dialogue.
---@return boolean
local function displayRandomValidCharacterNarrativeArcChapter()
    if game.nonCharacterPlayerCount > 0 then
        -- Don't show default narrative arc text when writers have joined
        return false
    end
    if game.levelNumber < firstNarrativeArcLevel then
        -- No narrative arc text allowed in this level
        return false
    end
    local allNarrativeCharacters = owner.map.getAllObjectsTagged('NarrativeCharacter')
    local charactersWhoWantToSpeak = {}
    for narrativeCharacterObj in allNarrativeCharacters do
        if narrativeCharacterObj.callFunc('hasValidNarrativeArcChapterToDisplay') then
            table.insert(charactersWhoWantToSpeak, narrativeCharacterObj)
        end
    end
    if #charactersWhoWantToSpeak > 0 then
        local chosenCharacterToSpeak = charactersWhoWantToSpeak[math.random(#charactersWhoWantToSpeak)]
        chosenCharacterToSpeak.callFunc('displayChosenArcChapter')
        roundsSinceSpeechDisplayed = 0
        return true
    end
    return false
end

--- Find any characters who have just spawned and want to say something, and
--- randomly choose one or two (if any are found) to actually display their dialogue.
---@return boolean
local function displayRandomValidSpawnText()
    if not firstPlanningPhasePassed then
        -- Don't check for patient spawn text before the first planning
        --  phase, because patient scripts may not yet have started
        return false
    end
    if checkedSpawnTextThisRound then
        -- Only check for spawn text at most once per round
        return false
    end
    checkedSpawnTextThisRound = true

    if game.nonCharacterPlayerCount > 0 then
        -- Don't show default spawn text when writers have joined
        return false
    end
    if game.levelNumber <= 1 then
        -- No spawn text in lvl1, tutorial text takes priority
        return false
    end

    -- Find any characters that just spawned & have something to say, & randomly choose up to 2 to speak
    local allNarrativeCharacters = owner.map.getAllObjectsTagged('NarrativeCharacter')
    local charactersWithSpawnText = {}
    for narrativeCharacterObj in allNarrativeCharacters do
        if narrativeCharacterObj.callFunc('hasSpawnChapterToDisplay') then
            table.insert(charactersWithSpawnText, narrativeCharacterObj)
        end
    end
    if #charactersWithSpawnText == 0 then
        return false
    end
    local chosenCharactersToSpeak = {}
    local chosenRand = -1
    local recendRand = -1
    -- Pick up to two different random patients to say their spawn text
    for i = 1, math.min((#charactersWithSpawnText), 2), 1 do
        while chosenRand == recendRand do
            chosenRand = math.random(#charactersWithSpawnText)
        end
        table.insert(chosenCharactersToSpeak, charactersWithSpawnText[chosenRand])
        recendRand = chosenRand
    end
    for characterToSpeak in chosenCharactersToSpeak do
        characterToSpeak.callFunc('displayChosenSpawnChapter')
    end
    return true
end

---@param message Message
local function onControllerNarrativeCharacterText(message)
    log:log('Got narrative character text from controller')

    local characterInternalNameData = message.data['characterInternalName']
    if characterInternalNameData == nil then
        error('No characterInternalName data in controller.narrativeCharacterText message')
    end

    local characterDisplayNameData = message.data['characterDisplayName']
    if characterDisplayNameData == nil then
        error('No characterDisplayName data in controller.narrativeCharacterText message')
    end

    local mainTextData = message.data['mainText']
    if mainTextData == nil then
        error('No mainText data in controller.narrativeCharacterText message')
    end

    mostRecentPlayerNarrativeMsgTime = getTimeSeconds()

    game.bus.send({
        metadata = { 'textNotificationUI.createOrUpdate' },
        data = {
            id = 'playerNarrativeCharacterText_' .. playerNarrativeTextCount,
            titleTextLiteral = characterDisplayNameData,
            mainTextLiteral = mainTextData,
            iconName = 'Icon_Avatar_' .. characterInternalNameData
        }
    }, nil, false)
    playerNarrativeTextCount = playerNarrativeTextCount + 1
    SoundUtils.playNotificationSound()
end

--- Called externally by GameManager, to check how much time to wait before
--- proceeding to the acting phase due to a recently received writer message
---@return number
function getWriterPlanningDelay()
    -- When about to switch from planning phase, check if a player narrative message was received less
    --  than minPlayerMessageDisplayTime seconds ago, so GameManager wait/display a countdown if so
    if mostRecentPlayerNarrativeMsgTime == -1 then
        -- No player narrative messages have been received, no delay needed
        return 0
    end
    local timeNow = getTimeSeconds()
    local timeSinceLastMsg = timeNow - mostRecentPlayerNarrativeMsgTime
    if timeSinceLastMsg < minPlayerMessageDisplayTime then
        -- Less than the minimum required number of seconds has passed since
        --  the most recent player narrative message was received
        -- Wait/count down the remaining time so players get a chance to read all text
        local waitTime = minPlayerMessageDisplayTime - timeSinceLastMsg
        log:log(tostring(timeSinceLastMsg) .. ' seconds have passed since the most recent player narrative message')
        log:log('minPlayerMessageDisplayTime is ' .. tostring(minPlayerMessageDisplayTime) .. 's, so waiting for ' .. tostring(waitTime) .. ' more seconds')
        return waitTime
    end
    return 0
end

---@param message Message
local function onGamePhaseChanged(message)
    local phase = message.data.gamePhase
	if phase == nil then
		error('No phase data in gamePhase message!')
	end
    if phase == 'acting' then
        checkedSpawnTextThisRound = false
        clearRoundSpecificNarrativeSaveData()
        -- Destroy all text notification UI (used to display character speech)
        game.bus.send({ 'textNotificationUI.destroyAll' }, nil, false)
    elseif phase == 'planning' then
        -- Send data to controllers so they can display characters to write for
        sendNarrativeCharactersDataToControllers()

        if not firstPlanningPhasePassed then
            -- Check for/display spawn text in the first planning phase,
            --  in case any patients spawned before all scripts had started
            firstPlanningPhasePassed = true
            if displayRandomValidSpawnText() then
                -- Spawn text being displayed, no need to check for narrative arcs
                return
            else
                -- Allow spawn text to be chacked again this round,
                --  in case a patient spawns just after the above check
                checkedSpawnTextThisRound = false
            end
        end

        -- If enough rounds have passed, display a random character's
        --  narrative arc dialogue (if there's any to show)
        roundsSinceSpeechDisplayed = roundsSinceSpeechDisplayed + 1
        if roundsSinceSpeechDisplayed >= minSpeechInterval then
            displayRandomValidCharacterNarrativeArcChapter()
        end
    end
end

---@param _ Message
local function onPatientAppeared(_)
    displayRandomValidSpawnText()
end

-- MAIN

-- Configure text notification UI, ready to be used for displaying narrative text
-- (Sets the max. pieces of text that will be shown at once before scrolling, and the delay when scrolling between text)
game.bus.send({
    metadata = { 'textNotificationUI.configureDisplay' },
    data = {
        onScreenLimit = 2,
        replaceIfMaxExceeded = true,
        reverseDisplayOrder = false,
        scrollDelay = 4
    }
}, nil, false)

-- Adjust minSpeechInterval if there are fewer than the default of 4 turns per round
--  e.g. If rounds are half as long, wait for 2x as many before allowing narrative arc speech to be shown
turnsPerRound = SaveDataHelper.getSavedTurnsPerRoundOrDefault()
if turnsPerRound > 0 and turnsPerRound < 4 then
    local turnMultiplier = 4 / turnsPerRound
    minSpeechInterval = minSpeechInterval * turnMultiplier
end
-- Ensure first narrative arc dialogue can't trigger till at least round 2
roundsSinceSpeechDisplayed = minSpeechInterval - 2

-- Clear any leftover narrative-related save data from a previous level
clearRoundSpecificNarrativeSaveData()
clearLevelSpecificNarrativeSaveData()

tags.addTag('NarrativeManager')
owner.tags.addTag('NarrativeManager')

log:log('NarrativeManager lua started')

game.bus.subscribe('controller.narrativeCharacterText', onControllerNarrativeCharacterText)
game.bus.subscribe('gamePhase', onGamePhaseChanged)
game.bus.subscribe('patient.appeared', onPatientAppeared)
