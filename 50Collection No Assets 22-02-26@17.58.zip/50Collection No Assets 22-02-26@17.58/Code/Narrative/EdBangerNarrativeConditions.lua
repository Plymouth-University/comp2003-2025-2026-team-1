---@type Game
local game = LoadFacility('Game')['game']

local SharedNarrativeConditions = require('SharedNarrativeConditions')

local SaveDataKeys = SharedNarrativeConditions.saveDataKeys()

local Log = require('Log')
local log = Log.new()

---@type MapMobile
local owner = owner or error('No owner')

-- ---@type boolean
-- local invalidActionWithMeThisRound = false

-- ---@type string
-- local invalidActionPlayerName

-- > TUTORIAL (LEVEL 1)
-- ====================

--- Tutorial text shown when the patient first spawns, every time level 1 is played:
--- "I need medicine"
local function level1TutorialChapter1Conditions()
    local chapterId = 'level1_tutorial_chapter1'
    return {
        conditionsMet = true,
        id = chapterId,
        speech = {
            { text = 'speech_edBanger_level1_tutorial_chapter1_option1' },
            { text = 'speech_edBanger_level1_tutorial_chapter1_option2' },
            { text = 'speech_edBanger_level1_tutorial_chapter1_option3' },
            { text = 'speech_edBanger_level1_tutorial_chapter1_option4' }
        }
    }
end

--- Tutorial text shown when patient has 6 health, every time level 1 is played:
--- "Interact with the medicine"
---@return table
local function level1TutorialChapter2Conditions()
    local chapterId = 'level1_tutorial_chapter2'
    -- Check for health = 7, because patients lose 1 health at the beginning of the planning phase
    if SharedNarrativeConditions.patientHealthEquals(owner, 7) then
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_edBanger_level1_tutorial_chapter2_option1' },
                { text = 'speech_edBanger_level1_tutorial_chapter2_option2' },
                { text = 'speech_edBanger_level1_tutorial_chapter2_option3' },
                { text = 'speech_edBanger_level1_tutorial_chapter2_option4' }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

-- > CURED!
-- ========

--- I was cured!
---@return table
local function level1Cured()
    local chapterId = 'level1_curedy'
    return {
        conditionsMet = true,
        id = chapterId,
        speech = {
            { text = 'speech_edBanger_level1_cured_option1' },
            { text = 'speech_edBanger_level1_cured_option2' },
            { text = 'speech_edBanger_level1_cured_option3' },
            { text = 'speech_edBanger_level1_cured_option4' }
        }
    }
end

-- > OLD/UNUSED LEVEL-SPECIFIC DIALOGUE
-- ====================================

-- --- Health = 4
-- ---@return table
-- local function level1Speech3Conditions()
--     local chapterId = 'level1_tutorial1_chapter3'
--     -- Check for health = 5, because patients lose 1 health at the beginning of the planning phase
--     if SharedNarrativeConditions.patientHealthEquals(owner, 5) then
--         return {
--             conditionsMet = true,
--             id = chapterId,
--             speech = {
--                 { text = 'speech_edBanger_tutorial_chapter3_option1' },
--                 { text = 'speech_edBanger_tutorial_chapter3_option2' },
--                 { text = 'speech_edBanger_tutorial_chapter3_option3' },
--                 { text = 'speech_edBanger_tutorial_chapter3_option4' }
--             }
--         }
--     end
--     return { conditionsMet = false, id = chapterId }
-- end

-- --- Health = 2
-- ---@return table
-- local function level1Speech4Conditions()
--     local chapterId = 'level1_speech4'
--     -- Check for health = 3, because patients lose 1 health at the beginning of the planning phase
--     if SharedNarrativeConditions.patientHealthEquals(owner, 3) then
--         return {
--             conditionsMet = true,
--             id = chapterId,
--             speech = {
--                 { text = 'speech_edBanger_level1_speech4_option1' },
--                 { text = 'speech_edBanger_level1_speech4_option2' },
--                 { text = 'speech_edBanger_level1_speech4_option3' },
--                 { text = 'speech_edBanger_level1_speech4_option4' }
--             }
--         }
--     end
--     return { conditionsMet = false, id = chapterId }
-- end

-- --- Any player bumped in the last round (AND not already shown)
-- ---@return table
-- local function level1Speech5Conditions()
--     local chapterId = 'level1_speech5'
--     if SharedNarrativeConditions.playerBumpedInLastRound() and (not chapterWasAlreadyShown(chapterId)) then
--         return {
--             conditionsMet = true,
--             id = chapterId,
--             speech = {
--                 { text = 'speech_edBanger_level1_speech5_option1' },
--                 { text = 'speech_edBanger_level1_speech5_option2' },
--                 { text = 'speech_edBanger_level1_speech5_option3' },
--                 { text = 'speech_edBanger_level1_speech5_option4' }
--             }
--         }
--     end
--     return { conditionsMet = false, id = chapterId }
-- end

-- --- Pills were dropped (AND not already shown)
-- ---@return table
-- local function level1Speech6Conditions()
--     local chapterId = 'level1_speech6'
--     if (SharedNarrativeConditions.playerDroppedPillsInLastRound()) and (not chapterWasAlreadyShown(chapterId)) then
--         local mostRecentPillDropPlayer = game.saveData.getString(SaveDataKeys.global_mostRecentPillDropPlayer())
--         return {
--             conditionsMet = true,
--             id = chapterId,
--             speech = {
--                 { text = 'speech_edBanger_level1_speech6_option1', args = { mostRecentPillDropPlayer } },
--                 { text = 'speech_edBanger_level1_speech6_option2', args = { mostRecentPillDropPlayer } },
--                 { text = 'speech_edBanger_level1_speech6_option3', args = { mostRecentPillDropPlayer } },
--                 { text = 'speech_edBanger_level1_speech6_option4', args = { mostRecentPillDropPlayer } }
--             }
--         }
--     end
--     return { conditionsMet = false, id = chapterId }
-- end

-- --- Any patient left/lost all health (AND not already shown)
-- ---@return table
-- local function level1Speech7Conditions()
--     local chapterId = 'level1_speech7'
--     if (SharedNarrativeConditions.patientLeftInLastRound()) and (not chapterWasAlreadyShown(chapterId)) then
--         return {
--             conditionsMet = true,
--             id = chapterId,
--             speech = {
--                 { text = 'speech_edBanger_level1_speech7_option1' },
--                 { text = 'speech_edBanger_level1_speech7_option2' },
--                 { text = 'speech_edBanger_level1_speech7_option3' },
--                 { text = 'speech_edBanger_level1_speech7_option4' }
--             }
--         }
--     end
--     return { conditionsMet = false, id = chapterId }
-- end

-- --- Any player bumped in the last round (AND not already shown)
-- ---@return table
-- local function level1Speech8Conditions()
--     local chapterId = 'level1_speech8'
--     if SharedNarrativeConditions.playerBumpedInLastRound() and (not chapterWasAlreadyShown(chapterId)) then
--         local mostRecentBumpPlayer = game.saveData.getString(SaveDataKeys.global_mostRecentBumpPlayer())
--         return {
--             conditionsMet = true,
--             id = chapterId,
--             speech = {
--                 { text = 'speech_edBanger_level1_speech8_option1', args = { mostRecentBumpPlayer } },
--                 { text = 'speech_edBanger_level1_speech8_option2', args = { mostRecentBumpPlayer } },
--                 { text = 'speech_edBanger_level1_speech8_option3', args = { mostRecentBumpPlayer } },
--                 { text = 'speech_edBanger_level1_speech8_option4', args = { mostRecentBumpPlayer } }
--             }
--         }
--     end
--     return { conditionsMet = false, id = chapterId }
-- end

-- --- Shown as soon as patient spawns/becomes active (if not already shown)
-- ---@return table
-- local function level2Speech1Conditions()
--     local chapterId = 'level2_speech1'
--     if not chapterWasAlreadyShown(chapterId) then
--         return {
--             conditionsMet = true,
--             id = chapterId,
--             speech = {
--                 { text = 'speech_edBanger_level2_speech1_option1' },
--                 { text = 'speech_edBanger_level2_speech1_option2' },
--                 { text = 'speech_edBanger_level2_speech1_option3' },
--                 { text = 'speech_edBanger_level2_speech1_option4' }
--             }
--         }
--     end
--     return { conditionsMet = false, id = chapterId }
-- end

-- --- Health = 5
-- ---@return table
-- local function level2Speech2Conditions_UNFINISHED()
--     local chapterId = 'level2_speech2'
--     -- Check for health = 6, because patients lose 1 health at the beginning of the planning phase
--     if SharedNarrativeConditions.patientHealthEquals(owner, 6) then
--         return {
--             conditionsMet = true,
--             id = chapterId,
--             speech = {
--                 { text = 'speech_edBanger_level2_speech2_option1' },
--                 { text = 'speech_edBanger_level2_speech2_option2' },
--                 { text = 'speech_edBanger_level2_speech2_option3' },
--                 { text = 'speech_edBanger_level2_speech2_option4' }
--             }
--         }
--     end
--     return { conditionsMet = false, id = chapterId }
-- end

-- --- Health = 3
-- ---@return table
-- local function level2Speech3Conditions_UNFINISHED()
--     local chapterId = 'level2_speech3'
--     -- Check for health = 4, because patients lose 1 health at the beginning of the planning phase
--     if SharedNarrativeConditions.patientHealthEquals(owner, 4) then
--         return {
--             conditionsMet = true,
--             id = chapterId,
--             speech = {
--                 { text = 'speech_edBanger_level2_speech3_option1' },
--                 { text = 'speech_edBanger_level2_speech3_option2' },
--                 { text = 'speech_edBanger_level2_speech3_option3' },
--                 { text = 'speech_edBanger_level2_speech3_option4' }
--             }
--         }
--     end
--     return { conditionsMet = false, id = chapterId }
-- end

-- --- Health = 1
-- ---@return table
-- local function level2Speech4Conditions_UNFINISHED()
--     local chapterId = 'level2_speech4'
--     -- Check for health = 2, because patients lose 1 health at the beginning of the planning phase
--     if SharedNarrativeConditions.patientHealthEquals(owner, 6) then
--         return {
--             conditionsMet = true,
--             id = chapterId,
--             speech = {
--                 { text = 'speech_edBanger_level2_speech4_option1' },
--                 { text = 'speech_edBanger_level2_speech4_option2' },
--                 { text = 'speech_edBanger_level2_speech4_option3' },
--                 { text = 'speech_edBanger_level2_speech4_option4' }
--             }
--         }
--     end
--     return { conditionsMet = false, id = chapterId }
-- end

-- --- Invalid interaction with this patient (AND not already shown)
-- ---@return table
-- local function level2Speech5Conditions()
--     local chapterId = 'level2_speech5'
--     if invalidActionWithMeThisRound and (not chapterWasAlreadyShown(chapterId)) then
--         return {
--             conditionsMet = true,
--             id = chapterId,
--             speech = {
--                 { text = 'speech_edBanger_level2_speech5_option1', args = { invalidActionPlayerName } },
--                 { text = 'speech_edBanger_level2_speech5_option2', args = { invalidActionPlayerName } },
--                 { text = 'speech_edBanger_level2_speech5_option3', args = { invalidActionPlayerName } },
--                 { text = 'speech_edBanger_level2_speech5_option4' }
--             }
--         }
--     end
--     return { conditionsMet = false, id = chapterId }
-- end

-- --- Invalid interaction with this patient (AND not already shown)
-- ---@return table
-- local function level2Speech6Conditions()
--     local chapterId = 'level2_speech6'
--     if invalidActionWithMeThisRound and (not chapterWasAlreadyShown(chapterId)) then
--         return {
--             conditionsMet = true,
--             id = chapterId,
--             speech = {
--                 { text = 'speech_edBanger_level2_speech6_option1', args = { invalidActionPlayerName } },
--                 { text = 'speech_edBanger_level2_speech6_option2', args = { invalidActionPlayerName } },
--                 { text = 'speech_edBanger_level2_speech6_option3' },
--                 { text = 'speech_edBanger_level2_speech6_option4', args = { invalidActionPlayerName } }
--             }
--         }
--     end
--     return { conditionsMet = false, id = chapterId }
-- end

-- --- Invalid interaction with sofa (AND not already shown)
-- ---@return table
-- local function level2Speech7Conditions()
--     local chapterId = 'level2_speech7'
--     if SharedNarrativeConditions.playerActedAtSofaInLastRound() and (not chapterWasAlreadyShown(chapterId)) then
--         local mostRecentSofaActPlayer = game.saveData.getString(SaveDataKeys.global_mostRecentActedAtSofaPlayer())
--         return {
--             conditionsMet = true,
--             id = chapterId,
--             speech = {
--                 { text = 'speech_edBanger_level2_speech7_option1', args = { mostRecentSofaActPlayer } },
--                 { text = 'speech_edBanger_level2_speech7_option2', args = { mostRecentSofaActPlayer } },
--                 { text = 'speech_edBanger_level2_speech7_option3', args = { mostRecentSofaActPlayer } },
--                 { text = 'speech_edBanger_level2_speech7_option4', args = { mostRecentSofaActPlayer } }
--             }
--         }
--     end
--     return { conditionsMet = false, id = chapterId }
-- end

-- --- Any player bumped in the last round (AND not already shown)
-- ---@return table
-- local function level2Speech8Conditions()
--     local chapterId = 'level2_speech8'
--     if SharedNarrativeConditions.playerBumpedInLastRound() and (not chapterWasAlreadyShown(chapterId)) then
--         return {
--             conditionsMet = true,
--             id = chapterId,
--             speech = {
--                 { text = 'speech_edBanger_level2_speech8_option1' },
--                 { text = 'speech_edBanger_level2_speech8_option2' },
--                 { text = 'speech_edBanger_level2_speech8_option3' },
--                 { text = 'speech_edBanger_level2_speech8_option4' }
--             }
--         }
--     end
--     return { conditionsMet = false, id = chapterId }
-- end

-- ARC 1 (BUMPING/MOSHING) SPEECH CONDITIONS
-- =========================================

--- Any player bumped in the last round
---@return table
local function arc1Chapter1Conditions()
    local chapterId = 'arc1_chapter1'
    if SharedNarrativeConditions.playerBumpedInLastRound() then
        local mostRecentBumpPlayer = game.saveData.getString(SaveDataKeys.global_mostRecentBumpPlayer())
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_edBanger_arc1_chapter1_option1', args = { mostRecentBumpPlayer } },
                { text = 'speech_edBanger_arc1_chapter1_option2', args = { mostRecentBumpPlayer } },
                { text = 'speech_edBanger_arc1_chapter1_option3' },
                { text = 'speech_edBanger_arc1_chapter1_option4', args = { mostRecentBumpPlayer } }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

--- Any player bumped in the last round
--- AND level 1 has been played through
---@return table
local function arc1Chapter2Conditions()
    local chapterId = 'arc1_chapter2'
    local level1Played = SharedNarrativeConditions.levelHasBeenPlayedThrough(1, game.levelNumber)
    if SharedNarrativeConditions.playerBumpedInLastRound() and level1Played then
        local mostRecentBumpPlayer = game.saveData.getString(SaveDataKeys.global_mostRecentBumpPlayer())
        local mostRecentBumpedObject = game.saveData.getString(SaveDataKeys.global_mostRecentBumpedObject())
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_edBanger_arc1_chapter2_option1', args = { mostRecentBumpPlayer, mostRecentBumpedObject } },
                { text = 'speech_edBanger_arc1_chapter2_option2', args = { mostRecentBumpPlayer, mostRecentBumpedObject } },
                { text = 'speech_edBanger_arc1_chapter2_option3', args = { mostRecentBumpPlayer, mostRecentBumpedObject } },
                { text = 'speech_edBanger_arc1_chapter2_option4', args = { mostRecentBumpedObject, mostRecentBumpPlayer } }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

--- Any player bumped in the last round
--- AND level 1 has been played through
---@return table
local function arc1Chapter3Conditions()
    local chapterId = 'arc1_chapter3'
    local level1Played = SharedNarrativeConditions.levelHasBeenPlayedThrough(1, game.levelNumber)
    if SharedNarrativeConditions.playerBumpedInLastRound() and level1Played then
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_edBanger_arc1_chapter3_option1' },
                { text = 'speech_edBanger_arc1_chapter3_option2' },
                { text = 'speech_edBanger_arc1_chapter3_option3' },
                { text = 'speech_edBanger_arc1_chapter3_option4' }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

--- Any player bumped in the last round
--- AND level 2 has been played through
---@return table
local function arc1Chapter4Conditions()
    local chapterId = 'arc1_chapter4'
    local level2Played = SharedNarrativeConditions.levelHasBeenPlayedThrough(2, game.levelNumber)
    if SharedNarrativeConditions.playerBumpedInLastRound() and level2Played then
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_edBanger_arc1_chapter4_option1' },
                { text = 'speech_edBanger_arc1_chapter4_option2' },
                { text = 'speech_edBanger_arc1_chapter4_option3' },
                { text = 'speech_edBanger_arc1_chapter4_option4' }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

--- Any player bumped in the last round
--- AND level 2 has been played through
---@return table
local function arc1Chapter5Conditions()
    local chapterId = 'arc1_chapter5'
    local level2Played = SharedNarrativeConditions.levelHasBeenPlayedThrough(2, game.levelNumber)
    if SharedNarrativeConditions.playerBumpedInLastRound() and level2Played then
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_edBanger_arc1_chapter5_option1' },
                { text = 'speech_edBanger_arc1_chapter5_option2' },
                { text = 'speech_edBanger_arc1_chapter5_option3' },
                { text = 'speech_edBanger_arc1_chapter5_option4' }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

-- ARC 2 (ED REVEALS HE IS AN ACCOUNTANT) SPEECH CONDITIONS
-- ========================================================

--- Ed needs pills AND any player is holding pills AND current level > 1
---@return table
local function arc2Chapter1Conditions()
    local chapterId = 'arc2_chapter1'
    if (SharedNarrativeConditions.patientNeedsPills(owner)) and (SharedNarrativeConditions.playerIsHoldingPills()) and (game.levelNumber > 1) then
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_edBanger_arc2_chapter1_option1' },
                { text = 'speech_edBanger_arc2_chapter1_option2' },
                { text = 'speech_edBanger_arc2_chapter1_option3' },
                { text = 'speech_edBanger_arc2_chapter1_option4' }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

--- A patient was saved in the previous round AND level 2 played through
---@return table
local function arc2Chapter2Conditions()
    local chapterId = 'arc2_chapter2'
    local level2Played = SharedNarrativeConditions.levelHasBeenPlayedThrough(2, game.levelNumber)
    if SharedNarrativeConditions.patientCuredInLastRound() and level2Played then
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_edBanger_arc2_chapter2_option1' },
                { text = 'speech_edBanger_arc2_chapter2_option2' },
                { text = 'speech_edBanger_arc2_chapter2_option3' },
                { text = 'speech_edBanger_arc2_chapter2_option4' }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

--- A patient was saved in the previous round AND level 2 played through
---@return table
local function arc2Chapter3Conditions()
    local chapterId = 'arc2_chapter3'
    local level2Played = SharedNarrativeConditions.levelHasBeenPlayedThrough(2, game.levelNumber)
    if SharedNarrativeConditions.patientCuredInLastRound() and level2Played then
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_edBanger_arc2_chapter3_option1' },
                { text = 'speech_edBanger_arc2_chapter3_option2' },
                { text = 'speech_edBanger_arc2_chapter3_option3' },
                { text = 'speech_edBanger_arc2_chapter3_option4' }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

--- A thrown object is not caught OR a patient dies, AND level 3 played through
---@return table
local function arc2Chapter4Conditions()
    local chapterId = 'arc2_chapter4'
    local level3Played = SharedNarrativeConditions.levelHasBeenPlayedThrough(3, game.levelNumber)
    if (SharedNarrativeConditions.playerThrewToUncaughtInLastRound() or SharedNarrativeConditions.patientLeftInLastRound()) and level3Played then
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_edBanger_arc2_chapter4_option1' },
                { text = 'speech_edBanger_arc2_chapter4_option2' },
                { text = 'speech_edBanger_arc2_chapter4_option3' },
                { text = 'speech_edBanger_arc2_chapter4_option4' }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

--- A patient was saved in the previous round AND level 3 played through
---@return table
local function arc2Chapter5Conditions()
    local chapterId = 'arc2_chapter5'
    local level3Played = SharedNarrativeConditions.levelHasBeenPlayedThrough(3, game.levelNumber)
    if SharedNarrativeConditions.patientCuredInLastRound() and level3Played then
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_edBanger_arc2_chapter5_option1' },
                { text = 'speech_edBanger_arc2_chapter5_option2' },
                { text = 'speech_edBanger_arc2_chapter5_option3' },
                { text = 'speech_edBanger_arc2_chapter5_option4' }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

-- SPAWN TEXT
-- ==========

local function spawnChapter1()
    return {
        conditionsMet = true,
        id = 'spawn_chapter1',
        speech = { { text = 'speech_edBanger_spawn_chapter1' } }
    }
end
local function spawnChapter2()
    return {
        conditionsMet = true,
        id = 'spawn_chapter2',
        speech = { { text = 'speech_edBanger_spawn_chapter2' } }
    }
end
local function spawnChapter3()
    return {
        conditionsMet = true,
        id = 'spawn_chapter3',
        speech = { { text = 'speech_edBanger_spawn_chapter3' } }
    }
end
local function spawnChapter4()
    return {
        conditionsMet = true,
        id = 'spawn_chapter4',
        speech = { { text = 'speech_edBanger_spawn_chapter4' } }
    }
end
local function spawnChapter5()
    return {
        conditionsMet = true,
        id = 'spawn_chapter5',
        speech = { { text = 'speech_edBanger_spawn_chapter5' } }
    }
end
local function spawnChapter6()
    return {
        conditionsMet = true,
        id = 'spawn_chapter6',
        speech = { { text = 'speech_edBanger_spawn_chapter6' } }
    }
end
local function spawnChapter7()
    return {
        conditionsMet = true,
        id = 'spawn_chapter7',
        speech = { { text = 'speech_edBanger_spawn_chapter7' } }
    }
end
local function spawnChapter8()
    return {
        conditionsMet = true,
        id = 'spawn_chapter8',
        speech = { { text = 'speech_edBanger_spawn_chapter8' } }
    }
end
local function spawnChapter9()
    return {
        conditionsMet = true,
        id = 'spawn_chapter9',
        speech = { { text = 'speech_edBanger_spawn_chapter9' } }
    }
end
local function spawnChapter10()
    return {
        conditionsMet = true,
        id = 'spawn_chapter10',
        speech = { { text = 'speech_edBanger_spawn_chapter10' } }
    }
end

-- CURE TEXT
-- =========

local function cureChapter1()
    return {
        conditionsMet = true,
        id = 'cure_chapter1',
        speech = { { text = 'speech_edBanger_cure_chapter1' } }
    }
end
local function cureChapter2()
    return {
        conditionsMet = true,
        id = 'cure_chapter2',
        speech = { { text = 'speech_edBanger_cure_chapter2' } }
    }
end
local function cureChapter3()
    return {
        conditionsMet = true,
        id = 'cure_chapter3',
        speech = { { text = 'speech_edBanger_cure_chapter3' } }
    }
end
local function cureChapter4()
    return {
        conditionsMet = true,
        id = 'cure_chapter4',
        speech = { { text = 'speech_edBanger_cure_chapter4' } }
    }
end
local function cureChapter5()
    return {
        conditionsMet = true,
        id = 'cure_chapter5',
        speech = { { text = 'speech_edBanger_cure_chapter5' } }
    }
end
local function cureChapter6()
    return {
        conditionsMet = true,
        id = 'cure_chapter6',
        speech = { { text = 'speech_edBanger_cure_chapter6' } }
    }
end
local function cureChapter7()
    return {
        conditionsMet = true,
        id = 'cure_chapter7',
        speech = { { text = 'speech_edBanger_cure_chapter7' } }
    }
end
local function cureChapter8()
    return {
        conditionsMet = true,
        id = 'cure_chapter8',
        speech = { { text = 'speech_edBanger_cure_chapter8' } }
    }
end
local function cureChapter9()
    return {
        conditionsMet = true,
        id = 'cure_chapter9',
        speech = { { text = 'speech_edBanger_cure_chapter9' } }
    }
end
local function cureChapter10()
    return {
        conditionsMet = true,
        id = 'cure_chapter10',
        speech = { { text = 'speech_edBanger_cure_chapter10' } }
    }
end

-- FUNCTIONS REQUIRED BY NARRATIVECHARACTER
-- ========================================

--- Called externally by NarrativeCharacter
---@param levelNumber number
---@param specialCondition string
---@return table|nil
function getSpecialConditionLevelChapters(levelNumber, specialCondition)
    if specialCondition == 'spawn' then
        return {
            spawnChapter1,
            spawnChapter2,
            spawnChapter3,
            spawnChapter4,
            spawnChapter5,
            spawnChapter6,
            spawnChapter7,
            spawnChapter8,
            spawnChapter9,
            spawnChapter10
        }
    elseif specialCondition == 'cure' then
        return {
            cureChapter1,
            cureChapter2,
            cureChapter3,
            cureChapter4,
            cureChapter5,
            cureChapter6,
            cureChapter7,
            cureChapter8,
            cureChapter9,
            cureChapter10
        }
    elseif specialCondition == 'tutorial' then
        if levelNumber == 1 then
            return {
                level1TutorialChapter1Conditions,
                level1TutorialChapter2Conditions
            }
        end
    end
    return nil
end

--- Called externally by NarrativeCharacter
---@return table|nil
function getAllNarrativeArcChapters()
    return {
        -- Arc 1: Bumping/moshing
        {
            arc1Chapter1Conditions,
            arc1Chapter2Conditions,
            arc1Chapter3Conditions,
            arc1Chapter4Conditions,
            arc1Chapter5Conditions
        },
        -- Arc 2: Ed reveals he is an accountant
        {
            arc2Chapter1Conditions,
            arc2Chapter2Conditions,
            arc2Chapter3Conditions,
            arc2Chapter4Conditions,
            arc2Chapter5Conditions
        }
    }
end

--- Name of the character, used in keys for character-related narrative save data
--- and for getting localized character name from string table
--- Called externally by NarrativeCharacter
---@return string
function getCharacterName()
    return 'edBanger'
end

--- Called externally by NarrativeCharacter
--- See: SharedNarrativeConditions.chapterWasAlreadyShown
---@param chapterId string
---@return boolean
function chapterWasAlreadyShown(chapterId)
    return SharedNarrativeConditions.chapterWasAlreadyShown(getCharacterName(), chapterId)
end

--- Called externally by NarrativeCharacter
--- See: SharedNarrativeConditions.setChapterAsShown
---@param chapterId string
function setChapterAsShown(chapterId)
    SharedNarrativeConditions.setChapterAsShown(getCharacterName(), chapterId)
end

-- FUNCTIONS REQUIRED BY NARRATIVEMANAGER
-- =======================================

--- Called externally by NarrativeManager
---@return boolean
function canPlayersWriteForCharacter()
    -- Yes, writer players can write text for me!
    return true
end

-- ========================================

-- ---@param message Message
-- local function onHadInvalidInteraction(message)
--     if message.data.playerName == nil then
-- 		error('No playerName data in patient.hadInvalidInteraction message')
-- 	end
--     -- A player performed an invalid action in the direction of this patient
--     invalidActionWithMeThisRound = true
--     invalidActionPlayerName = message.data.playerName
-- end

-- ---@param message Message
-- local function onGamePhaseChanged(message)
--     local phase = message.data.gamePhase
-- 	if phase == nil then
-- 		error('No phase data in gamePhase message!')
-- 	end
--     if phase == 'acting' then
--         -- Reset for each round
--         invalidActionWithMeThisRound = false
--         invalidActionPlayerName = ''
--     end
-- end

tags.addTag('CharacterNarrativeConditions')
owner.tags.addTag('CharacterNarrativeConditions')

log:log('EdBangerNarrativeConditions lua started')

-- owner.bus.subscribe('patient.hadInvalidInteraction', onHadInvalidInteraction)
-- game.bus.subscribe('gamePhase', onGamePhaseChanged)