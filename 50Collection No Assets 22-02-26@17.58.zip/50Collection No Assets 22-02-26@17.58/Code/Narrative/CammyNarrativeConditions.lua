---@type Game
local game = LoadFacility('Game')['game']

local SharedNarrativeConditions = require('SharedNarrativeConditions')

local SaveDataKeys = SharedNarrativeConditions.saveDataKeys()

local Log = require('Log')
local log = Log.new()

---@type MapMobile
local owner = owner or error('No owner')

---@type boolean
local placedInBedThisRound = false
---@type boolean
local pickedUpThisRound = false
---@type number
local roundNumber = 0

-- ARC 1 (CONFUSION OVER SOCIAL EXPECTATIONS) SPEECH CONDITIONS
-- ============================================================

--- Any patient picked up in last round
---@return table
local function arc1Chapter1Conditions()
    local chapterId = 'arc1_chapter1'
    if SharedNarrativeConditions.patientPickedUpInLastRound() then
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_cammy_arc1_chapter1_option1' },
                { text = 'speech_cammy_arc1_chapter1_option2' },
                { text = 'speech_cammy_arc1_chapter1_option3' },
                { text = 'speech_cammy_arc1_chapter1_option4' }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

--- Any patient picked up in last round
---@return table
local function arc1Chapter2Conditions()
    local chapterId = 'arc1_chapter2'
    if SharedNarrativeConditions.patientPickedUpInLastRound() then
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_cammy_arc1_chapter2_option1' },
                { text = 'speech_cammy_arc1_chapter2_option2' },
                { text = 'speech_cammy_arc1_chapter2_option3' },
                { text = 'speech_cammy_arc1_chapter2_option4' }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

--- Picked up OR placed in bed, AND healed >0 times
---@return table
local function arc1Chapter3Conditions()
    local chapterId = 'arc1_chapter3'
    local cureCount = SharedNarrativeConditions.patientCureCount(getCharacterName())
    if (placedInBedThisRound or pickedUpThisRound) and (cureCount > 0) then
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_cammy_arc1_chapter3_option1' },
                { text = 'speech_cammy_arc1_chapter3_option2' },
                { text = 'speech_cammy_arc1_chapter3_option3' },
                { text = 'speech_cammy_arc1_chapter3_option4' }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

--- Health <60%, AND healed >1 time
---@return table
local function arc1Chapter4Conditions()
    local chapterId = 'arc1_chapter4'
    local cureCount = SharedNarrativeConditions.patientCureCount(getCharacterName())
    if (SharedNarrativeConditions.patientHealthLessThanPercentage(owner, 0.6)) and (cureCount > 1) then
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_cammy_arc1_chapter4_option1' },
                { text = 'speech_cammy_arc1_chapter4_option2' },
                { text = 'speech_cammy_arc1_chapter4_option3' },
                { text = 'speech_cammy_arc1_chapter4_option4' }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

--- Picked up OR placed in bed, AND healed >1 time
---@return table
local function arc1Chapter5Conditions()
    local chapterId = 'arc1_chapter5'
    local cureCount = SharedNarrativeConditions.patientCureCount(getCharacterName())
    if (placedInBedThisRound or pickedUpThisRound) and (cureCount > 1) then
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_cammy_arc1_chapter5_option1' },
                { text = 'speech_cammy_arc1_chapter5_option2' },
                { text = 'speech_cammy_arc1_chapter5_option3' },
                { text = 'speech_cammy_arc1_chapter5_option4' }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

-- ARC 2 (EYE CONTACT ISSUES) SPEECH CONDITIONS
-- ============================================

--- Anything was caught, AND healed >1 time
---@return table
local function arc2Chapter1Conditions()
    local chapterId = 'arc2_chapter1'
    local cureCount = SharedNarrativeConditions.patientCureCount(getCharacterName())
    if SharedNarrativeConditions.playerCaughtInLastRound() and (cureCount > 1) then
        local mostRecentThrower = game.saveData.getString(SaveDataKeys.global_mostRecentThrowToTeammatePlayer())
        local mostRecentCatcher = game.saveData.getString(SaveDataKeys.global_mostRecentCatchingPlayer())
        local mostRecentCaughtObject = game.saveData.getString(SaveDataKeys.global_mostRecentCaughtObject())
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_cammy_arc2_chapter1_option1', args = { mostRecentCatcher, mostRecentThrower, mostRecentCaughtObject } },
                { text = 'speech_cammy_arc2_chapter1_option2', args = { mostRecentCatcher, mostRecentThrower } },
                { text = 'speech_cammy_arc2_chapter1_option3', args = { mostRecentThrower, mostRecentCatcher } },
                { text = 'speech_cammy_arc2_chapter1_option4', args = { mostRecentThrower, mostRecentCatcher } }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

--- Anything was caught, AND healed >1 time
---@return table
local function arc2Chapter2Conditions()
    local chapterId = 'arc2_chapter2'
    local cureCount = SharedNarrativeConditions.patientCureCount(getCharacterName())
    if SharedNarrativeConditions.playerCaughtInLastRound() and (cureCount > 1) then
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_cammy_arc2_chapter2_option1' },
                { text = 'speech_cammy_arc2_chapter2_option2' },
                { text = 'speech_cammy_arc2_chapter2_option3' },
                { text = 'speech_cammy_arc2_chapter2_option4' }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

--- Anything was caught, AND healed >2 times
---@return table
local function arc2Chapter3Conditions()
    local chapterId = 'arc2_chapter3'
    local cureCount = SharedNarrativeConditions.patientCureCount(getCharacterName())
    if SharedNarrativeConditions.playerCaughtInLastRound() and (cureCount > 2) then
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_cammy_arc2_chapter3_option1' },
                { text = 'speech_cammy_arc2_chapter3_option2' },
                { text = 'speech_cammy_arc2_chapter3_option3' },
                { text = 'speech_cammy_arc2_chapter3_option4' }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

--- Anything was caught, AND healed >2 times
---@return table
local function arc2Chapter4Conditions()
    local chapterId = 'arc2_chapter4'
    local cureCount = SharedNarrativeConditions.patientCureCount(getCharacterName())
    if SharedNarrativeConditions.playerCaughtInLastRound() and (cureCount > 2) then
        local mostRecentThrower = game.saveData.getString(SaveDataKeys.global_mostRecentThrowToTeammatePlayer())
        local mostRecentCatcher = game.saveData.getString(SaveDataKeys.global_mostRecentCatchingPlayer())
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_cammy_arc2_chapter4_option1', args = { mostRecentCatcher } },
                { text = 'speech_cammy_arc2_chapter4_option2', args = { mostRecentThrower } },
                { text = 'speech_cammy_arc2_chapter4_option3', args = { mostRecentCatcher } },
                { text = 'speech_cammy_arc2_chapter4_option4', args = { mostRecentThrower } }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

--- Anything was caught, AND healed >3 times
---@return table
local function arc2Chapter5Conditions()
    local chapterId = 'arc2_chapter5'
    local cureCount = SharedNarrativeConditions.patientCureCount(getCharacterName())
    if SharedNarrativeConditions.playerCaughtInLastRound() and (cureCount > 3) then
        return {
            conditionsMet = true,
            id = chapterId,
            speech = {
                { text = 'speech_cammy_arc2_chapter5_option1' },
                { text = 'speech_cammy_arc2_chapter5_option2' },
                { text = 'speech_cammy_arc2_chapter5_option3' },
                { text = 'speech_cammy_arc2_chapter5_option4' }
            }
        }
    end
    return { conditionsMet = false, id = chapterId }
end

-- SPAWN TEXT
-- ==========

local function spawnChapter1()
    return {
        conditionsMet = true,
        id = 'spawn_chapter1',
        speech = { { text = 'speech_cammy_spawn_chapter1' } }
    }
end
local function spawnChapter2()
    return {
        conditionsMet = true,
        id = 'spawn_chapter2',
        speech = { { text = 'speech_cammy_spawn_chapter2' } }
    }
end
local function spawnChapter3()
    return {
        conditionsMet = true,
        id = 'spawn_chapter3',
        speech = { { text = 'speech_cammy_spawn_chapter3' } }
    }
end
local function spawnChapter4()
    return {
        conditionsMet = true,
        id = 'spawn_chapter4',
        speech = { { text = 'speech_cammy_spawn_chapter4' } }
    }
end
local function spawnChapter5()
    return {
        conditionsMet = true,
        id = 'spawn_chapter5',
        speech = { { text = 'speech_cammy_spawn_chapter5' } }
    }
end
local function spawnChapter6()
    return {
        conditionsMet = true,
        id = 'spawn_chapter6',
        speech = { { text = 'speech_cammy_spawn_chapter6' } }
    }
end
local function spawnChapter7()
    return {
        conditionsMet = true,
        id = 'spawn_chapter7',
        speech = { { text = 'speech_cammy_spawn_chapter7' } }
    }
end
local function spawnChapter8()
    return {
        conditionsMet = true,
        id = 'spawn_chapter8',
        speech = { { text = 'speech_cammy_spawn_chapter8' } }
    }
end
local function spawnChapter9()
    return {
        conditionsMet = true,
        id = 'spawn_chapter9',
        speech = { { text = 'speech_cammy_spawn_chapter9' } }
    }
end
local function spawnChapter10()
    return {
        conditionsMet = true,
        id = 'spawn_chapter10',
        speech = { { text = 'speech_cammy_spawn_chapter10' } }
    }
end

-- CURE TEXT
-- =========

local function cureChapter1()
    return {
        conditionsMet = true,
        id = 'cure_chapter1',
        speech = { { text = 'speech_cammy_cure_chapter1' } }
    }
end
local function cureChapter2()
    return {
        conditionsMet = true,
        id = 'cure_chapter2',
        speech = { { text = 'speech_cammy_cure_chapter2' } }
    }
end
local function cureChapter3()
    return {
        conditionsMet = true,
        id = 'cure_chapter3',
        speech = { { text = 'speech_cammy_cure_chapter3' } }
    }
end
local function cureChapter4()
    return {
        conditionsMet = true,
        id = 'cure_chapter4',
        speech = { { text = 'speech_cammy_cure_chapter4' } }
    }
end
local function cureChapter5()
    return {
        conditionsMet = true,
        id = 'cure_chapter5',
        speech = { { text = 'speech_cammy_cure_chapter5' } }
    }
end
local function cureChapter6()
    return {
        conditionsMet = true,
        id = 'cure_chapter6',
        speech = { { text = 'speech_cammy_cure_chapter6' } }
    }
end
local function cureChapter7()
    return {
        conditionsMet = true,
        id = 'cure_chapter7',
        speech = { { text = 'speech_cammy_cure_chapter7' } }
    }
end
local function cureChapter8()
    return {
        conditionsMet = true,
        id = 'cure_chapter8',
        speech = { { text = 'speech_cammy_cure_chapter8' } }
    }
end
local function cureChapter9()
    return {
        conditionsMet = true,
        id = 'cure_chapter9',
        speech = { { text = 'speech_cammy_cure_chapter9' } }
    }
end
local function cureChapter10()
    return {
        conditionsMet = true,
        id = 'cure_chapter10',
        speech = { { text = 'speech_cammy_cure_chapter10' } }
    }
end

-- FUNCTIONS REQUIRED BY NARRATIVECHARACTER
-- ========================================

--- Called externally by NarrativeCharacter
---@param levelNumber number
---@param specialCondition string
---@return table|nil
function getSpecialConditionLevelChapters(levelNumber, specialCondition)
    if specialCondition == 'spawn' then
        return {
            spawnChapter1,
            spawnChapter2,
            spawnChapter3,
            spawnChapter4,
            spawnChapter5,
            spawnChapter6,
            spawnChapter7,
            spawnChapter8,
            spawnChapter9,
            spawnChapter10
        }
    elseif specialCondition == 'cure' then
        return {
            cureChapter1,
            cureChapter2,
            cureChapter3,
            cureChapter4,
            cureChapter5,
            cureChapter6,
            cureChapter7,
            cureChapter8,
            cureChapter9,
            cureChapter10
        }
    end
end

--- Called externally by NarrativeCharacter
---@return table|nil
function getAllNarrativeArcChapters()
    return {
        -- Arc 1: Confusion over social expectations
        {
            arc1Chapter1Conditions,
            arc1Chapter2Conditions,
            arc1Chapter3Conditions,
            arc1Chapter4Conditions,
            arc1Chapter5Conditions
        },
        -- Arc 2: Eye contact issues
        {
            arc2Chapter1Conditions,
            arc2Chapter2Conditions,
            arc2Chapter3Conditions,
            arc2Chapter4Conditions,
            arc2Chapter5Conditions
        }
    }
end

--- Name of the character, used in keys for character-related narrative save data
--- and for getting localized character name from string table
--- Called externally by NarrativeCharacter
---@return string
function getCharacterName()
    return 'cammy'
end

--- Called externally by NarrativeCharacter
--- See: SharedNarrativeConditions.chapterWasAlreadyShown
---@param chapterId string
---@return boolean
function chapterWasAlreadyShown(chapterId)
    return SharedNarrativeConditions.chapterWasAlreadyShown(getCharacterName(), chapterId)
end

--- Called externally by NarrativeCharacter
--- See: SharedNarrativeConditions.setChapterAsShown
---@param chapterId string
function setChapterAsShown(chapterId)
    SharedNarrativeConditions.setChapterAsShown(getCharacterName(), chapterId)
end

-- FUNCTIONS REQUIRED BY NARRATIVEMANAGER
-- =======================================

--- Called externally by NarrativeManager
---@return boolean
function canPlayersWriteForCharacter()
    -- Yes, writer players can write text for me!
    return true
end

-- ========================================

local function onGamePhaseChanged(message)
    local phase = message.data.gamePhase
    if phase == nil then
        error('no phase in gamePhase message')
    end
    if phase == 'acting' then
        placedInBedThisRound = false
        pickedUpThisRound = false
    elseif phase == 'planning' then
        roundNumber = roundNumber + 1
    end
end

---@param message Message
local function onPatientStateChanged(message)
    local newState = message.data['state.patient']
    if newState == nil then
        error('nil state in state.patient message')
    end
    if (newState == 'InBed') and (roundNumber > 1) then
        -- Patient was placed in bed, and this isn't the 1st round
        -- (To prevent conditional dialogue being valid on level start)
        placedInBedThisRound = true
    end
end

---@param _ Message
local function onCarried(_)
    pickedUpThisRound = true
end

tags.addTag('CharacterNarrativeConditions')
owner.tags.addTag('CharacterNarrativeConditions')

log:log('ChameleonNarrativeConditions lua started')

game.bus.subscribe('gamePhase', onGamePhaseChanged)
owner.bus.subscribe('state.patient', onPatientStateChanged)
owner.bus.subscribe('carried', onCarried)
