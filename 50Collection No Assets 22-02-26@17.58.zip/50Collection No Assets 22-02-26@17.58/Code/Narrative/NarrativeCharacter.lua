---@type Game
local game = LoadFacility('Game')['game']

local Log = require('Log')
local log = Log.new()

---@type MapMobile
local owner = owner or error('No owner')

---@type SoundUtils
local SoundUtils = require('SoundUtils')

---@type boolean
local destroyed = false

-- Small delay to avoid the odd occasion where CharacterNarrativeConditions script has not started when trying to get the component
waitMilliSeconds(10)
---@type Mod
local characterConditions = owner.getFirstComponentTagged('CharacterNarrativeConditions') or error('No mod tagged CharacterNarrativeConditions on NarrativeCharacter owner')

---@type string
local arcsChaptersFuncName = 'getAllNarrativeArcChapters';
if not characterConditions.hasFunc(arcsChaptersFuncName) then
    error('Script tagged as "CharacterNarrativeConditions" should have function: ' .. arcsChaptersFuncName)
end
---@type string
local levelSpecialConditionChaptersFuncName = 'getSpecialConditionLevelChapters';
if not characterConditions.hasFunc(levelSpecialConditionChaptersFuncName) then
    error('Script tagged as "CharacterNarrativeConditions" should have function: ' .. levelSpecialConditionChaptersFuncName)
end

---@type string
local getChapterShownFuncName = 'chapterWasAlreadyShown';
if not characterConditions.hasFunc(getChapterShownFuncName) then
    error('Script tagged as "CharacterNarrativeConditions" should have function: ' .. getChapterShownFuncName)
end
---@type string
local setChapterShownFuncName = 'setChapterAsShown';
if not characterConditions.hasFunc(setChapterShownFuncName) then
    error('Script tagged as "CharacterNarrativeConditions" should have function: ' .. setChapterShownFuncName)
end

---@type string
local characterNameFunc = 'getCharacterName';
if not characterConditions.hasFunc(characterNameFunc) then
    error('Script tagged as "CharacterNarrativeConditions" should have function: ' .. characterNameFunc)
end
---@type string
local characterName = characterConditions.callFunc(characterNameFunc)

---@type boolean
local showingSpeech = false

---@type table<boolean>
local chaptersShownThisLevelForIds = {}

---@type table | nil
local chosenArcChapter
---@type table | nil
local chosenSpawnChapter

---@param textKey string
---@return string
local function getTextAlreadyShownKey(textKey)
    return 'narrative_textShown_' .. textKey
end

--- Randomly selects speech from the chapter, prioritising dialogue that has never been shown
---@param chapter table
---@return table
local function chooseRandomSpeechFromChapter(chapter)
    local unshownSpeech = {}
    local shownSpeech = {}

    if chapter.speech == nil then
        error('Missing character dialogue: chapter table with id "' .. chapter.id .. '" does not contain speech when trying to display narrative text for ' .. characterName)
    end
    if #chapter.speech == 0 then
        error('Missing character dialogue: chapter table with id "' .. chapter.id .. '" has an empty speech table when trying to display narrative text for ' .. characterName)
    end
    for textAndArgs in chapter.speech do
        if (textAndArgs.text == nil) or (#textAndArgs.text == 0) then
            error('chapter.speech table does not contain text when trying to display narrative text for ' .. characterName .. '(chapter.id: "' .. chapter.id .. '")')
        end
        if game.saveData.getNumber(getTextAlreadyShownKey(textAndArgs.text)) == 0 then
            -- Text has never been shown before
            table.insert(unshownSpeech, textAndArgs)
        elseif #unshownSpeech == 0 then
            -- Text has previously been shown (in this save slot)
            -- (Only bother adding shown text to the table if no unshown text was found yet)
            table.insert(shownSpeech, textAndArgs)
        end
    end

    if #unshownSpeech > 0 then
        return unshownSpeech[math.random(#unshownSpeech)]
    else
        return shownSpeech[math.random(#shownSpeech)]
    end
end

--- Returns true if the dialogue text was displayed
---@param chapter table
---@param isCureChapter boolean
local function displaySpeechFromChapter(chapter, isCureChapter)
    if chapter.id == nil then
        error('chapter table does not contain id field when trying to display narrative text for ' .. characterName)
    end

    local textAndArgsToShow = chooseRandomSpeechFromChapter(chapter)
    if textAndArgsToShow == nil then
        return
    end

    -- Mark chapter as shown in package save data (using key: chapter.id)
    characterConditions.callFunc(setChapterShownFuncName, chapter.id)
    -- Mark chapter as shown for this current level
    chaptersShownThisLevelForIds[chapter.id] = true

    -- Mark the specific dialogue line being displayed as shown in save data
    game.saveData.setNumber(getTextAlreadyShownKey(textAndArgsToShow.text), 1)
    game.saveData.save()

    local avatarIconName = 'Icon_Avatar_' .. characterName
    if isCureChapter then
        avatarIconName = 'Icon_Avatar_' .. characterName .. '_cure'
    end

    game.bus.send({
        metadata = { 'textNotificationUI.createOrUpdate' },
        data = {
            id = tostring(owner.id),
            titleTextKey = 'characterName_' .. characterName,
            mainTextKey = textAndArgsToShow.text,
            mainTextArgs = textAndArgsToShow.args,
            iconName = avatarIconName
        }
    }, nil, false)
    SoundUtils.playNotificationSound()
    showingSpeech = true
end

---@param allArcsWithChapters table
---@return table|nil
local function getHighestPriorityValidChapterFromNarrativeArcs(allArcsWithChapters)
    local highestValidChapterNumber = -1
    local chosenChapter = nil
    for arcWithChapters in allArcsWithChapters do
        for chapterNumber, chapterConditionsFunc in pairs(arcWithChapters) do
            local chapter = chapterConditionsFunc()
            if chapter.id == nil then
                error('chapter table for chapter number ' .. tostring(chapterNumber) .. ' does not contain id field on character ' .. characterName)
            end
            local chapterCanRepeat = false
            if chapter.canRepeat ~= nil then
                chapterCanRepeat = chapter.canRepeat
            end
            local chapterAlreadyShown = characterConditions.callFunc(getChapterShownFuncName, chapter.id)
            if (chapter.conditionsMet) and (chapterNumber > highestValidChapterNumber) and ((not chapterAlreadyShown) or chapterCanRepeat) then
                -- Conditions for showing this chapter were passed,
                -- AND it has a higher index in its narrative arc (i.e. chapter number) then the current highest,
                -- (Higher chapter numbers take priority to increase likelihood of finishing arcs before showing new ones)
                -- AND: EITHER this chapter has not already been shown OR it can be shown multiple times
                -- So it's in the running to be shown!
                highestValidChapterNumber = chapterNumber
                chosenChapter = chapter
                break
            elseif not chapterAlreadyShown then
                -- This chapter hasn't been shown yet, so no subsequent chapters in the same arc should be checked
                -- (We don't want to e.g. show chapter 2 before chapter 1, even if chapter 2's conditions are met)
                break
            end
        end
    end
    return chosenChapter
end

--- Check if there's any valid tutorial text, and display it if so
local function checkForTutorialText()
    if owner.hasFunc('canShowNarrativeText') and (not owner.callFunc('canShowNarrativeText')) then
        -- Another script on this object is stopping us from showing text
        return
    end

    -- Get all chapters containing tutorial text (if any)
    local tutorialChapterFuncs = characterConditions.callFunc(levelSpecialConditionChaptersFuncName, game.levelNumber, 'tutorial')
    if (tutorialChapterFuncs == nil) or (#tutorialChapterFuncs == 0) then
        return
    end
    -- Try to find any value tutorial chapters that haven't been shown this level,
    -- and show if any are found (picking randomly if multiple are valid)
    local validTutorialChapters = {}
    for chapterConditionsFunc in tutorialChapterFuncs do
        local chapter = chapterConditionsFunc()
        if chapter.id == nil then
            error('chapter with no id when checking for tutorial text on ' .. characterName)
        end
        local shownThisLevel = chaptersShownThisLevelForIds[chapter.id]
        if (chapter.conditionsMet) and (not shownThisLevel) then
            table.insert(validTutorialChapters, chapter)
        end
    end
    if (validTutorialChapters ~= nil) and (#validTutorialChapters > 0) then
        local chosenTutorialChapter = validTutorialChapters[math.random(#validTutorialChapters)]
        displaySpeechFromChapter(chosenTutorialChapter, false)
    end
end

local function hideSpeechUI()
    if not showingSpeech then
        return
    end
    showingSpeech = false

    game.bus.send({
        metadata = { 'textNotificationUI.destroy' },
        data = {
            id = tostring(owner.id),
            delay = 1.0
        }
    }, nil, false)
end

---@param message Message
local function onMapObjectStateChanged(message)
	if message.data['state.MapObject'] ~= 'Destroyed' then
		return
	end
	destroyed = true
    -- Ensure speech UI goes away when owner is destroyed
    if showingSpeech then
        hideSpeechUI()
    end
end

---@param message Message
local function onPatientStateChanged(message)
	if message.data['state.patient'] ~= 'Cured' then
        return
	end

    -- Patient was cured! Get all chapters with cure dialogue
    local cureChapterFuncs = characterConditions.callFunc(levelSpecialConditionChaptersFuncName, game.levelNumber, 'cure')

    -- Randomly choose cure text, prioritising chapters that haven't been shown before
    local shownCureChapters = {}
    local unshownCureChapters = {}
    for cureChapterFunc in cureChapterFuncs do
        local chapter = cureChapterFunc()
        local chapterShown = characterConditions.callFunc(getChapterShownFuncName, chapter.id)
        if chapterShown then
            table.insert(shownCureChapters, chapter)
        else
            table.insert(unshownCureChapters, chapter)
        end
    end
    local chosenCureChapter
    if (#unshownCureChapters > 0) then
        chosenCureChapter = unshownCureChapters[math.random(#unshownCureChapters)]
    else
        chosenCureChapter = shownCureChapters[math.random(#shownCureChapters)]
    end
    displaySpeechFromChapter(chosenCureChapter, true)
end

---@param message Message
local function onGamePhaseChanged(message)
    if destroyed then
        return
    end

    local phase = message.data.gamePhase
	if phase == nil then
		error('No phase data in gamePhase message!')
	end

    if phase == 'planning' then
        -- Check each round if there is any tutorial text to be displayed
        checkForTutorialText()
    elseif phase == 'acting' then
        -- NarrativeManager destroys all text notification UI in the acting phase,
        --  so no longer showing speech, but no need to actually do hideSpeechUI()
        showingSpeech = false
    end
end

---@return boolean
function hasSpawnChapterToDisplay()
    chosenSpawnChapter = nil

    if showingSpeech then
        -- Already showing text
        return false
    end
    local hasDidSpawnThisRoundFunc = owner.hasFunc('didSpawnThisRound')
    if (not hasDidSpawnThisRoundFunc) or (hasDidSpawnThisRoundFunc and (not owner.callFunc('didSpawnThisRound'))) then
        -- Didn't spawn this round, no reason to show spawn text
        return false
    end
    if owner.hasFunc('canShowNarrativeText') and (not owner.callFunc('canShowNarrativeText')) then
        -- Another script on this object is stopping us from showing text
        return false
    end

    -- Get all chapters with spawn dialogue
    local spawnChapterFuncs = characterConditions.callFunc(levelSpecialConditionChaptersFuncName, game.levelNumber, 'spawn')
    if (spawnChapterFuncs == nil) or (#spawnChapterFuncs == 0) then
        return false
    end

    -- Always pick the first/default chapter if it hasn't been shown before
    local firstSpawnChapter = spawnChapterFuncs[1]()
    local firstSpawnChapterShown = characterConditions.callFunc(getChapterShownFuncName, firstSpawnChapter.id)
    if not firstSpawnChapterShown then
        chosenSpawnChapter = firstSpawnChapter
        return true
    end

    -- If a spawn chapter has already been shown for this character in the current level, re-show it
    local spawnChapterIndexForLevel = game.saveData.getNumber('narrative_spawnChapterForLevel_' .. game.levelNumber .. '_' .. characterName)
    if (spawnChapterIndexForLevel > 1) and (spawnChapterIndexForLevel <= #spawnChapterFuncs) then
        chosenSpawnChapter = spawnChapterFuncs[spawnChapterIndexForLevel]()
        return true
    end

    -- This character has not shown spawn text before in the current level (except for the first/default chapter)
    -- Pick a chapter randomly, excluding the first one, prioritising chapters that haven't been shown in any level
    local shownSpawnChapters = {}
    local unshownSpawnChapters = {}
    for i, spawnChapterFunc in ipairs(spawnChapterFuncs) do
        if i > 1 then
            local chapter = spawnChapterFunc()
            local chapterShown = characterConditions.callFunc(getChapterShownFuncName, chapter.id)
            if chapterShown then
                table.insert(shownSpawnChapters, { chapter = chapter, index = i })
            else
                table.insert(unshownSpawnChapters, { chapter = chapter, index = i })
            end
        end
    end
    local chosenChapterAndIndex
    if (#unshownSpawnChapters > 0) then
        chosenChapterAndIndex = unshownSpawnChapters[math.random(#unshownSpawnChapters)]
    else
        chosenChapterAndIndex = shownSpawnChapters[math.random(#shownSpawnChapters)]
    end

    -- Save the chapter that was chosen for the current level, so it can be re-shown if the level is replayed
    chosenSpawnChapter = chosenChapterAndIndex.chapter
    game.saveData.setNumber('narrative_spawnChapterForLevel_' .. game.levelNumber .. '_' .. characterName, chosenChapterAndIndex.index)
    game.saveData.save()
    return true
end

function displayChosenSpawnChapter()
    if chosenSpawnChapter == nil then
        error('displaySpawnChapter() with no chosenSpawnChapter set on NarrativeCharacter ' .. characterName)
    end
    displaySpeechFromChapter(chosenSpawnChapter, false)
end

--- Called externally by NarrativeManager.
--- Returns true if a valid narrative arc chapter is found
--- (i.e. this character has some narrative text they'd like to say)
---@return boolean
function hasValidNarrativeArcChapterToDisplay()
    chosenArcChapter = nil

    if destroyed then
        return false
    end
    if showingSpeech then
        -- Already showing text
        return false
    end
    if owner.hasFunc('canShowNarrativeText') and (not owner.callFunc('canShowNarrativeText')) then
        -- Another script on this object is stopping us from showing text
        return false
    end

    -- Check for valid dialogue from narrative arcs
    local allArcsWithChapters = characterConditions.callFunc(arcsChaptersFuncName)
    local chosenChapterFromArcs = nil
    if allArcsWithChapters ~= nil then
        chosenChapterFromArcs = getHighestPriorityValidChapterFromNarrativeArcs(allArcsWithChapters)
    end
    if chosenChapterFromArcs ~= nil then
        -- Got valid speech from one of this character's narrative arcs!
        chosenArcChapter = chosenChapterFromArcs
        return true
    end

    -- This character currently has nothing to say from their narrative arcs
    return false
end

--- Called externally by NarrativeManager when hasValidNarrativeArcChapterToDisplay()
--- returned true, and this character was chosen to have their narrative text displayed.
function displayChosenArcChapter()
    if chosenArcChapter == nil then
        error('displayMostRecentValidChapter() with no chosenArcChapter set on NarrativeCharacter ' .. characterName)
    end
    displaySpeechFromChapter(chosenArcChapter, false)
end

log:log('NarrativeCharacter lua started with character conditions: ' .. tostring(characterConditions))

tags.addTag('NarrativeCharacter')
owner.tags.addTag('NarrativeCharacter')

owner.bus.subscribe('state.MapObject', onMapObjectStateChanged)
owner.bus.subscribe('state.patient', onPatientStateChanged)
game.bus.subscribe('gamePhase', onGamePhaseChanged)
