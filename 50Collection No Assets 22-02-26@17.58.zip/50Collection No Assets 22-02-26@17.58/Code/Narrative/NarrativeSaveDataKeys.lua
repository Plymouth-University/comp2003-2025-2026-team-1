---@class NarrativeSaveDataKeys
local NarrativeSaveDataKeys = {}

-- Global narrative save data (used across all levels)
-- ===================================================

--- Whether the given level was ever completed (i.e. played till the end, regardless of outcome) for this save.
---@param levelNumber number
---@return string
function NarrativeSaveDataKeys.global_levelXCompleted(levelNumber)
    return 'narrative_global_level' .. tostring(levelNumber) .. 'Completed'
end

--- Whether all patients were cured in any playthrough of the given level.
---@param levelNumber number
---@return string
function NarrativeSaveDataKeys.global_levelXAllCured(levelNumber)
    return 'narrative_global_level' .. tostring(levelNumber) .. 'AllCured'
end

--- Total number of times a patient character was cured
---@param characterName string
---@return string
function NarrativeSaveDataKeys.global_patientCureCount(characterName)
    return 'narrative_global_patientCureCount_' .. characterName
end

--- Total number of times players have bumped into things for this save.
---@return string
function NarrativeSaveDataKeys.global_playerBumpCount()
    return 'narrative_global_playerBumpCount'
end

-- Name of the player who most recently bumped into something.
---@return string
function NarrativeSaveDataKeys.global_mostRecentBumpPlayer()
    return 'narrative_global_mostRecentBumpPlayer'
end

-- Name (key for localisation table) of the object that was most recently bumped into.
---@return string
function NarrativeSaveDataKeys.global_mostRecentBumpedObject()
    return 'narrative_global_mostRecentBumpedObject'
end

--- Total number of catches for this save.
---@return string
function NarrativeSaveDataKeys.global_playerCatchCount()
    return 'narrative_global_playerCatchCount'
end

--- Name (key for localisation table) of the object that was caught most recently.
---@return string
function NarrativeSaveDataKeys.global_mostRecentCaughtObject()
    return 'narrative_global_mostRecentCaughtObject'
end

--- Name of the player who was most recently threw and dropped pills.
---@return string
function NarrativeSaveDataKeys.global_mostRecentPillDropPlayer()
    return 'narrative_global_mostRecentPillDropPlayer'
end

--- Name of the player who was most recently threw and dropped a patient.
---@return string
function NarrativeSaveDataKeys.global_mostRecentPatientDropPlayer()
    return 'narrative_global_mostRecentPatientDropPlayer'
end

--- Name of the patient who was most recently dropped after being thrown.
---@return string
function NarrativeSaveDataKeys.global_mostRecentDroppedPatient()
    return 'narrative_global_mostRecentDroppedPatient'
end

--- Name of the player who most recently threw a patient out of a window.
---@return string
function NarrativeSaveDataKeys.global_mostRecentWindowThrowPlayer()
    return 'narrative_global_mostRecentWindowThrowPlayer'
end

--- Name of the patient who was most recently thrown out of a window.
---@return string
function NarrativeSaveDataKeys.global_mostRecentDefenestratedPatient()
    return 'narrative_global_mostRecentDefenestratedPatient'
end

--- Name of the player who most recently threw an object that hit a patient.
---@return string
function NarrativeSaveDataKeys.global_mostRecentThrowAndHitPlayer()
    return 'narrative_global_mostRecentThrowAndHitPlayer'
end

--- Name of the player who most recently threw an object to another player.
---@return string
function NarrativeSaveDataKeys.global_mostRecentThrowToTeammatePlayer()
    return 'narrative_global_mostRecentThrowToTeammatePlayer'
end

--- Name of the player who most recently caught an object.
---@return string
function NarrativeSaveDataKeys.global_mostRecentCatchingPlayer()
    return 'narrative_global_mostRecentCatchingPlayer'
end

--- Name of the patient who was most recently hit by an object that a player threw.
---@return string
function NarrativeSaveDataKeys.global_mostRecentHitPatient()
    return 'narrative_global_mostRecentHitPatient'
end

--- Name (key for localisation table) of the object that most recently hit a patient.
---@return string
function NarrativeSaveDataKeys.global_mostRecentPatientHittingObject()
    return 'narrative_global_mostRecentPatientHittingObject'
end

--- Name of the player who most recently gave a patient the wrong medicine
---@return string
function NarrativeSaveDataKeys.global_mostRecentAdministerWrongPlayer()
    return 'narrative_global_mostRecentAdministerWrongPlayer'
end

--- Name of the patient who most recently received the wrong medicine
---@return string
function NarrativeSaveDataKeys.global_mostRecentAdministerWrongPatient()
    return 'narrative_global_mostRecentAdministerWrongPatient'
end

--- Name of the player who most recently tried to interact with a sofa
---@return string
function NarrativeSaveDataKeys.global_mostRecentActedAtSofaPlayer()
    return 'narrative_global_mostRecentActedAtSofaPlayer'
end

-- Round-specific narrative save data
-- IMPORTANT: When adding a new key, also add it to getAllKeysToClearOnNewRound() below
-- ====================================================================================

---@return string
function NarrativeSaveDataKeys.thisRound_didPlayerBump()
    return 'narrative_thisRound_didPlayerBump'
end

---@return string
function NarrativeSaveDataKeys.thisRound_didPlayerThrowToUncaught()
    return 'narrative_thisRound_didPlayerThrowToUncaught'
end
---@return string
function NarrativeSaveDataKeys.thisRound_didPlayerCatch()
    return 'narrative_thisRound_didPlayerCatch'
end

---@return string
function NarrativeSaveDataKeys.thisRound_didPlayerThrowPatient()
    return 'narrative_thisRound_didPlayerThrowPatient'
end

---@return string
function NarrativeSaveDataKeys.thisRound_wasPatientPickedUp()
    return 'narrative_thisRound_wasPatientPickedUp'
end

---@return string
function NarrativeSaveDataKeys.thisRound_didPlayerDropPills()
    return 'narrative_thisRound_didPlayerDropPills'
end

---@return string
function NarrativeSaveDataKeys.thisRound_didPlayerDropPatient()
    return 'narrative_thisRound_didPlayerDropPatient'
end

---@return string
function NarrativeSaveDataKeys.thisRound_didPlayerDefenestratePatient()
    return 'narrative_thisRound_didPlayerDefenestratePatient'
end

---@return string
function NarrativeSaveDataKeys.thisRound_didPlayerThrowHitPatient()
    return 'narrative_thisRound_didPlayerThrowHitPatient'
end

---@return string
function NarrativeSaveDataKeys.thisRound_didPlayerAdministerWrong()
    return 'narrative_thisRound_didPlayerAdministerWrong'
end

---@return string
function NarrativeSaveDataKeys.thisRound_didPlayerWait()
    return 'narrative_thisRound_didPlayerWait'
end

---@return string
function NarrativeSaveDataKeys.thisRound_didPlayerDoSpecialWait()
    return 'narrative_thisRound_didPlayerDoSpecialWait'
end

---@return string
function NarrativeSaveDataKeys.thisRound_playerActedAtSofa()
    return 'narrative_thisRound_playerActedAtSofa'
end

---@return string
function NarrativeSaveDataKeys.thisRound_wasPatientCured()
    return 'narrative_thisRound_wasPatientCured'
end
---@return string
function NarrativeSaveDataKeys.thisRound_didPatientLeave()
    return 'narrative_thisRound_didPatientLeave'
end

---@return string
function NarrativeSaveDataKeys.thisRound_wasAnyObjectShrunk()
    return 'narrative_thisRound_wasAnyObjectShrunk'
end

--- Keys for any narrative-related save data that should be cleared at the start of each acting phase
--- (See: NarrativeManager.clearRoundSpecificNarrativeSaveData())
---@return string[]
function NarrativeSaveDataKeys.getAllKeysToClearOnNewRound()
    return {
        NarrativeSaveDataKeys.thisRound_didPlayerBump(),
        NarrativeSaveDataKeys.thisRound_didPlayerThrowToUncaught(),
        NarrativeSaveDataKeys.thisRound_didPlayerCatch(),
        NarrativeSaveDataKeys.thisRound_didPlayerThrowPatient(),
        NarrativeSaveDataKeys.thisRound_wasPatientPickedUp(),
        NarrativeSaveDataKeys.thisRound_didPlayerDropPills(),
        NarrativeSaveDataKeys.thisRound_didPlayerDropPatient(),
        NarrativeSaveDataKeys.thisRound_didPlayerDefenestratePatient(),
        NarrativeSaveDataKeys.thisRound_didPlayerThrowHitPatient(),
        NarrativeSaveDataKeys.thisRound_didPlayerAdministerWrong(),
        NarrativeSaveDataKeys.thisRound_didPlayerWait(),
        NarrativeSaveDataKeys.thisRound_didPlayerDoSpecialWait(),
        NarrativeSaveDataKeys.thisRound_playerActedAtSofa(),
        NarrativeSaveDataKeys.thisRound_wasPatientCured(),
        NarrativeSaveDataKeys.thisRound_didPatientLeave(),
        NarrativeSaveDataKeys.thisRound_wasAnyObjectShrunk()
    }
end

--- Keys for any narrative-related save data that should be cleared at the start of each level
--- (See: NarrativeManager.clearLevelSpecificNarrativeSaveData())
---@return string[]
function NarrativeSaveDataKeys.getAllKeysToClearOnNewLevel()
    return {
    }
end

-- Localization helper functions
-- =============================

---@param tags Tags
---@return string
function NarrativeSaveDataKeys.getStringTableKeyForNameOfObjectFromTags(tags)
    if tags.hasTag('Player') then
        return 'objectName_teammate'
    elseif tags.hasTag('Patient') then
        return 'objectName_patient'
    elseif tags.hasTag('pills') then
        return 'objectName_pill'
    elseif tags.hasTag('syringe') then
        return 'objectName_syringe'
    elseif tags.hasTag('apple') then
        return 'objectName_apple'
    end
    return 'objectName_furniture'
end

---@param mapObject MapObject
---@return string
function NarrativeSaveDataKeys.getStringTableKeyForNameOfObject(mapObject)
    return NarrativeSaveDataKeys.getStringTableKeyForNameOfObjectFromTags(mapObject.tags)
end

return NarrativeSaveDataKeys
