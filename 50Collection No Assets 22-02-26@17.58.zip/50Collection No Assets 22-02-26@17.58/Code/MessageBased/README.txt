Mod code in this directory.
Sub-directories as needed.
"MessageBased" is one style of of Lua API we are considering.
In it, the Lua code creates objects and 'sends' them then awaits responses.  This style of code makes it obvious that things are asynchronous and recorded.
