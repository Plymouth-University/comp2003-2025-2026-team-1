﻿local CarryHelper = require('CarryHelper')

local Log = require('Log')
local log = Log.new()

---External function called when acting with carried item by `Act.lua`
function actWhenCarried(carrierOwner, carrier, actDirection)
	assert(nil ~= carrierOwner, 'No carrierOwner')
	assert(nil ~= carrier, 'No carrier')
	assert(nil ~= actDirection, 'No actDirection')

	---- If there is empty floor with nothing blocking us, place the patient down
	if CarryHelper.placeDownIfClearInFront(carrierOwner, carrier, actDirection) then
		return true
	end

	-- No return value since we're a subscriber
	return false
end
