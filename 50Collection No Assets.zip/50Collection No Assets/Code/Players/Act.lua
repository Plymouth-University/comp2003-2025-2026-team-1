-- Act
local game = LoadFacility('Game')['game']

---@type MapMobile
local owner = owner or error('No owner')

--- Complex/more-complete act version
--- Includes interacting with external objects (which the more simple one in `Act-simple.lua` does not).

local Log = require('Log')
local log = Log.new()

local DirectionUtils = require('DirectionUtils')

-- Check whether carrying
local carrier = owner.getFirstComponentTagged('carrier');
assert(nil ~= carrier and 'Carrier' == carrier.typeName, 'Player lacks carrier component')

---Check tile in-front for an `Interact`-tagged object and
---attempt to call an `interact()` method on it.
---Result of that function is either `false`/`nil` (for failure) or `true`/a `MapObject` to carry on success.
---When a `MapObject` is returned, it's checked for `carryable` flag and carried if present.
---@param actDirection Direction
---@return boolean @ Whether successfully interacted.
local function interactInDirection(actDirection)
    log:log('Trying to interact in ', actDirection)
    local interactable = owner.getFirstFacingObjectTagged('Interact')
    if nil == interactable then
        log:log('No interactable')
        return false
    end

    if not interactable.hasFunc('interact') then
        log:log('No interact function on ', interactable)
        return false
    end

    -- Interact with the target.
    -- false = failure, nil = fine, mapObject = do something with it (carry it)
    local result = interactable.callFunc('interact')
    log:debug('Interacted with', interactable, 'result:', result, 'type:', type(result))
    if false == result then
        -- false result means failure
        log:log('Interacted with ', interactable, ' but failed')
        return false
    end
    if nil == result or true == result then
        -- nil result is fine, just means all done (as does true)
        log:log('Successfully interacted with ', interactable)
        return true
    end

    -- Cast result to remove boolean and nil types
    local resultMapObject = (--[[---@not boolean|nil]] result)

    local resultantCarryable = resultMapObject.getFirstComponentTagged('carryable')
    if nil ~= resultantCarryable then
        -- carry it!
        local success = carrier.carry(resultantCarryable)
        if not success then
            log:log('Got ', resultantCarryable, ' but failed to carry it')
        else
            log:log('Successfully picked-up ', resultantCarryable)
        end
        return true
    end

    -- not a carryable result = TODO
    return true
end

---Attempt to carry in the direction facing.
local function carry()
    local mapObject = owner.getFirstFacingObjectTagged('carryable')
    if nil == mapObject then
        return false
    end

    local resultantCarryable = mapObject.getFirstComponentTagged('carryable')
    if nil == resultantCarryable then
        return false
    end

    -- carry it!
    local success = carrier.carry(resultantCarryable)
    log:log('Carrying ', mapObject, (success and ' succeeded' or ' failed'))
    return success
end

---Act (interact) code for player character.
---Called externally (from framework).
---If not carrying, tries to pick something up.
---If carrying something, asks it to resolve interaction with object in-front (e.g. patient tries to place themself in bed).
function act(actDirection)
    log:log('acting in direction:', actDirection)

    if nil == actDirection or not DirectionUtils.isDirection(actDirection) then
        log:error('Invalid direction supplied: ', actDirection)
        return false
    end

    -- Face in direction of action
    owner.setFacing(actDirection)

    local isCarrying = carrier.isCarrying
    log:log('Lua isCarrying:', isCarrying)

    local success = false

    if isCarrying then
        local carried = carrier.getCurrentlyCarried() -- gives us a Carryable component
        log:log('current carried:', carried)

        ---Ask what we're carrying to act for us (medicine, patient etc)
        if carried.owner.hasFunc('actWhenCarried') then
            log:log('Calling actWhenCarried on carried object')
            success = carried.owner.callFunc('actWhenCarried', owner, carrier, actDirection)
        else
            log:log("No 'actWhenCarried' on ", carried.owner, " so cannot act with it!")
            success = false
        end
    else
        if interactInDirection(actDirection) then
            success = true
        else
            -- Not carrying, look for something to pick up
            success = carry()
        end
    end

    if not success then
        -- Acting failed/we did nothing
        log:log('Failed to act in direction ', actDirection)
        game.bus.send({ metadata = { 'player.actionFailed' }, data = { position = owner.gridPosition, direction = actDirection } }, false)
        game.bus.send({ metadata = { 'playSound' }, data = { soundName = 'InvalidAction' } }, false)
        owner.bus.send({ 'player.actionFailed' }, false)
    end

    return success
end

log:log('Act mod (COMPLEX) ready for ', owner)
