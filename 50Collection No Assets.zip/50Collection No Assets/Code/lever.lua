---Operates a lever that moves between 3 positions when the player interacts with it.
---Starts in the middle position.
---On progressive interactions, moves lever:
--- * pos1 to pos2
--- * pos2 to pos3 <-- first interaction
--- * pos3 to pos2
--- * pos2 to pos1
---Topic-to-animation name mapping is in LevelsShared.lua
---E.g. message bus topic name "p1-p2" is mapped to animation name "pos1-pos2" (which appears in the GLB).

local positions = {1,2,3,2}
local pos = 2 -- 1-indexed but start in middle (pos 2)
local previousPosName = 'p2' -- correlates with `animationMappings` in LevelsShared.lua

---Move lever to next position.
---Done by sending a message with a topic to the message bus.
---Look in the LevelsShared.lua for the mapping of the topic to the animation name.
local function moveLever()
    setLogDebug(true)
	pos = pos + 1
	if pos > #positions then
		pos = 1
	end
	local nextPosNum = positions[pos]
	local newPosName = 'p' .. tostring(nextPosNum)
	local topic = previousPosName .. '-' .. newPosName
	print('Sending topic: ' .. topic)
	previousPosName = newPosName
	owner.bus.send({ topic })
end

---MAIN

--Mark self as able to be interacted with.  This is checked in Act.lua.
owner.tags.addTag('interact')

---Allow player to interact with this.
---Externally called by Act.lua.
---@return boolean @ Returns true to indicate interaction was successful.
function interact()
	print('Interacted with lever')
	moveLever()
	return true
end
